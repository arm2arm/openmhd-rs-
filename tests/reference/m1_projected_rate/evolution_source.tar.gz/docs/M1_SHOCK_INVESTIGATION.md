# Jittered-shock closure investigation

## Current development loop: short tests first

At the user's request on 2026-11-08, all four long original/candidate/spline/
physics workflows are stopped. Preserve their partial records and raw remote
workspaces. Hold new long submissions during this development phase.

Use the bounded four-case runner for each proposed fix:

```sh
python3 scripts/run_shock_repro.py --output-dir results/shock_short_fresh
```

It runs nx256 x ny4 to t=.01 on regular/jittered meshes, each base and jointly
boosted. The default cap is 30 wall seconds per case, at most four serial
workers. Timeouts and aborted evolutions fail the screen. It saves exact
source/binary hashes, a source archive, commands, timings, snapshots, logs,
positivity/budget checks, the unchanged short-time Brio diagnostics and boost
comparisons. Add `--trace-energy` only when an accepted-step energy trace is
needed; `--dt` supports a separate smaller-step check. A fresh directory is
required each time.

The first four-case screen took **0.87 wall seconds** after a cached build:
both regular cases completed; both jittered cases reproduced the t=.0034298
failure. This is an expected failed screen, not a successful stability test.
Source and measurements are under `results/shock_short_screen_20261108/`.
Small algebra/unit checks and this reproduction form the immediate iteration
loop. Candidates that fail it do not justify another full matrix.

A passing short screen is only the first development check. Medium-duration
shock/refinement controls and the original full-time M1 matrix are still
required before acceptance or merging. The short runner never submits jobs
or marks full M1 acceptance. Report a passing candidate before considering
resumption of longer validation.

The registered spline physics study failed all six jittered Brio evolutions.
The unchanged M0 thresholds, historical profiles and raw failures are retained.
No pressure floor, entropy switch, energy reset or explicit resistivity is
authorized as a substitute for passing that conservative packet.

## Observations before a numerical change

### Prospective compatibility probe

Before adding another evolution profile, test whether the initial finite-volume
induction rate can be represented by the existing raw neighbour curl. On the
fixed Brio meshes, v=u=0 and phi=0 initially, so the baseline Az rate is exactly
the face-area average of the numerical EMF. Assemble that rate and the
conservative induction rate from the same reconstructed Riemann problems;
check agreement with `Simulation::energy_rates()` before interpreting results.

For the planar rate operator `C a = (Dy a, -Dx a)`, minimize the volume-weighted
residual `sum_i V_i |C(a_dot_baseline + delta)_i - B_dot_FV_i|²` by solving
the normal equations with conjugate gradients, starting delta=0. Report
convergence/residuals and the implied initial pressure rate; do not evolve,
overwrite B or adjust energy. Test the true transpose against the exact
implemented constant-baseline derivative, including its target subtraction,
and recover a known compatible manufactured rate up to curl accuracy. Compare
regular/jittered nx64/128/256 controls. A reduced initial mismatch alone is not
a stability result, a fix, a new physical gate, or permission for long runs.

The six initial-state probes complete in .73 seconds. At nx256 the regular
rate residual falls from .5714 to 6.59e-14, but the jittered residual only
falls from .8007 to .4718. The independently recomputed normal-equation
relative residual is 9.54e-12; operator assembly agrees with the production
energy diagnostic to 1.53e-15. Thus the remaining residual is not an unfinished
iterative solve. In cell 253 the projected initial pressure rate improves
from -34.8807 to -15.0369; it remains negative.

### Prospective projected-rate evolution trial

Test `bulk-frame-heun-projected-v1`, retaining the spline Heun algorithm and
all gas fluxes, stored energies, raw curl, diagnostic operators and thresholds.
After forming the baseline A rate at each stage, add a correction minimizing
`sum_i V_i |curl(A_dot + delta)_i - target_i|²`. Use the full planar 3-component
curl and its exact weighted transpose. The target is the oriented divergence
of the Riemann induction flux in the rigid mesh frame: add `Bn*w` to the
existing ALE induction flux before summation. This explicit engineering
choice removes the boost-dependent `w*div_face(B)` term in the target when
the face sum is nonzero. It is not a Powell source in the fluid equations,
an overwrite of B, or a total-energy reset. The default method is unchanged.

The 3-component boost control caught an incomplete frame definition in the
first draft (w_z=0): density agreement failed at the unchanged 1e-10 tolerance.
For the 2.5D target use `w=(mesh_wx,mesh_wy,Vref_z)`, with the same fixed initial
mass-weighted reference velocity as the bulk-frame gauge. The z component
adds no positional motion; it removes the out-of-plane boost times the
discrete normal-field divergence. Preserve the first draft and failure record.

Use diagonal-preconditioned conjugate gradients with relative normal residual
1e-11, independently checked at 1e-9 and capped at 8 times the scalar unknown
count. Never silently accept a failed solve. Validate transpose, manufactured
compatible/incompatible targets and bounded uniform/boost/permutation/time
controls before the four-case short shock screen, capped at 30 seconds per
case. Reject if it cannot complete this screen; do not launch long runs.

The nx256, ny4, jitter=.15 case stops near t=.00343 in cell 253, adjacent to
the periodic seam, although the requested final time is .1. All five existing
profiles fail. Reducing the spline timestep cap to 1e-5 and 1e-6 yields failure
times .00343412 and .00343445. This is not resolved by timestep refinement.

An observational energy-rate diagnostic evaluates, on fixed/rigid geometry,
`dK=v dot d(momentum)-|v|² d(rho)/2`, `dM=B dot curl(dA)`, and
`dp=(gamma-1)*(dE-dK-dM)`. For comparison it also computes `B dot dB_FV`
from the same oriented Riemann induction fluxes, without evolving that field.
At initialization in cell 253, dE=-42.28159, dM=-7.40085 and dK=0,
so dp=-34.88074. The independent finite-volume magnetic rate is -39.76889.
Thermal energy subsequently approaches zero. Tracing leaves every physical
snapshot, history, summary and timestep identical to the frozen baseline.
This demonstrates a discrete fluid/curl energy mismatch in that cell; it is
not a proof that the gradient stencil alone causes all instabilities.

## Prospective reconstruction comparator

Test `bulk-frame-heun-centered-v1` separately. Retain the spline auxiliary
projection, Heun stages, fluxes, primitive gradients, limiter, budgets and
failure policy. Change only the A/phi derivative fit used for the raw curl,
potential extrapolation, div(A) and grad(phi): minimize the face-area-weighted
residuals `A_j-A_i-G dot (c_j-c_i)` with the intercept anchored to the target
cell. Use the same scaled conditioning rejection. Cache the stencil on the
fixed/rigid geometry. The paper profile remains its prescribed free-intercept,
target-excluding fit. The new comparator is an engineering amendment, not a
correction attributed to the paper.

Before larger runs: verify affine reproduction, constant annihilation,
periodic manufactured convergence, observer passivity, analytic energy-rate
identities and temporal finite differences; reproduce the failing short
shock with baseline and comparator, plus regular and joint-boost controls.
If the short case improves, run the registered shock ladder on REANA and
report all existing profile/state/diagnostic/boost gates. A stable evolution
alone does not resolve the strict Bx diagnostic or the full M1 wave gates.
Reject an unsuccessful comparator rather than changing acceptance thresholds.

The centered comparator passes affine/constant/convergence and bounded
uniform/boost/time-order tests, but the short jittered shock still fails near
t=.00334879. It is rejected as the shock fix; exact source and results are
retained under `results/shock_diagnosis_20261108/`.

## Second prospective comparator: face-source location

The historical area-weighted face-source average does not generally reproduce
an affine electric field at a skewed cell centroid: its first spatial moment
is nonzero. Test `bulk-frame-heun-facefit-v1`, retaining the historical raw
curl and spline Heun choices. Replace only the face-source average by the
free-intercept least-squares value evaluated at the cell centroid. If
`m=sum_f(a_f/perimeter)*(f-c)` and `D_f` are the existing face derivative
coefficients, use source weights `a_f/perimeter - m dot D_f`. They sum to one
and have zero first moment. Apply them to the whole `EMF_f-u_i cross B_f`
source; keep advection, mean-field and gauge terms unchanged. This is another
explicit engineering comparator, not a claim about the published method.

First verify affine-source reproduction and uniform/boost/time-order
regressions, then repeat the same regular/jittered nx256 short shock controls.
Preserve all failures. The original M1 gates and resistivity/energy policy
remain unchanged.

## Disposition and retained development

### Prospective shared face-normal field experiment

Next test `bulk-frame-heun-vertex-v1` as a separate engineering comparator.
The current Riemann solver takes the arithmetic common normal component of
two independently reconstructed cell fields. This shared normal field need
not have zero oriented face sum in each cell. Construct instead one Az value
at each geometrically shared Voronoi vertex, using an affine-exact unweighted
least-squares intercept from its incident cell-centre values. For a face with
tangent `t=(-n_y,n_x)` and endpoints `v_minus,v_plus`, use
`Bn = mean_B dot n + (Az(v_plus)-Az(v_minus))/area`. The vertex differences
telescope around a cell. This identity applies only to this face-sum operator,
not to the historical cell-centred curl or its independent divergence tests.
Preserve gas pressure and tangential B when supplying the common Bn to both
Riemann states. Keep all other spline/Heun choices, conservative exchanges,
curl-based recovery and original acceptance gates unchanged.

Recover vertex topology by joining consecutive oriented face endpoints around
each cell, validating their geometric coincidence including periodic images.
Do not independently interpolate an endpoint for every face. First test
constant/affine reproduction, periodic telescoping, smooth convergence,
uniform states, boost/permutation and time order. Then use the four-case short
screen. Reject and archive a failed candidate; do not launch a full matrix.
This prospective description is recorded before candidate measurements.

Measured disposition: all three operator tests and four uniform/boost/
permutation/time-order controls pass. Initial maximum absolute divergence of
the actual Riemann face-normal field falls from **23.6786 to 2.22e-13**; in
cell 253 it falls from 1.07469 to -3.91e-14. Nevertheless that cell's initial
pressure rate remains -34.8306 (baseline -34.8807), with dE=-42.4052 and
B dot curl(dA)=-7.57460. Both jittered cases fail at t=.0033337193, slightly
earlier than the baseline t=.0034298036. Both regular cases complete t=.01
and pass their boost comparison. The four-case screen takes .85 seconds.

The candidate is rejected and removed; its exact source, seven tests, all
four traced runs and initial-state measurements are preserved in the
[shared-vertex probe archive](../tests/reference/m1_face_normal_probe/README.md).
This shows that making this face-normal flux sum cancel is insufficient to
repair the observed fluid/curl energy mismatch. It does not rule out other
coupling treatments or establish cell-curl solenoidality. Long jobs remain
stopped; the next numerical work concerns the compatibility of the discrete
curl evolution with the spatial energy flux, not a rerun of these long cases.
After removing the candidate, the four touched solver/driver/test files match
their pre-trial bytes exactly. Format, strict Clippy, all 107 Rust tests,
38 Python tests, the 13 M0 algebra checks and pinned reference verification
pass. The new evidence archive is excluded from minimal REANA source uploads.

The face-source comparator passes affine reproduction and bounded
uniform/boost/time-order checks, but still fails the jittered shock at
t=.00350419. Both alternative reconstructions are rejected as fixes and
removed from the working solver. Their exact source, tests and failed runs
are preserved in the [investigation archive](../tests/reference/m1_shock_diagnosis/README.md).
No new scientific gate is claimed.

![Measured failing-cell energy traces](images/m1_completion/shock_energy_failure.png)

At initialization, the failing cell itself has exactly B=(.75,-1,0) and
p=.1. Its pressure collapse cannot be attributed solely to an incorrect
initial B in that cell. The incompatible spatial transfer of magnetic and
total energy remains the demonstrated failure mechanism. The FV induction
curve is an independent comparison, not a separately accepted solution or
a proposal to overwrite the curl-derived field.

Retained changes are observational: `--trace-energy` writes every accepted
cell's thermal/kinetic/magnetic energies and instantaneous rates, without
introducing checkpoint times; `advance_to_observed` exposes accepted states;
closure errors identify the cell, location and Heun stage. Fixed/rigid meshes
only are supported for energy-rate interpretation. The trace can be reproduced:

```sh
cargo run --release --locked -p openmhd --bin vector-potential -- \
  --case brio-wu --profile bulk-frame-heun-spline-v1 --n 256 --jitter .15 \
  --time .005 --trace-energy --output results/shock_trace
```

This command is expected to fail with the preserved positivity error.
All five historical profiles retain byte-identical initial/final CSVs,
histories and summaries in ten boosted jittered wave/loop comparisons with
tracing enabled. The traced failing shock also matches its frozen baseline.
Format, Clippy, all 107 Rust tests, 36 Python tests and both M0 checks pass.
The new rate tests check uniform zero rates, temporal finite differences,
joint boosts, integrated energy conservation and observer passivity.

The remaining work is a justified coupling treatment that keeps the
curl-derived magnetic energy and conservative fluid fluxes compatible on
irregular shocks, followed by the unchanged full M1 gates. The current
investigation does not establish such a treatment. M1 remains unmerged.
