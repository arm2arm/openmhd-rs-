"""Run one built Rust selection or check the documented CLI on its five-site fixture."""
import csv, hashlib, io, json, math, subprocess, time
from pathlib import Path
def digest(raw):return hashlib.sha256(raw).hexdigest()
def require(value,why):
    if not value:raise ValueError(why)
case=json.loads(Path('case.json').read_bytes())
binary=Path(case['binary'])
require(digest(binary.read_bytes())==case['sha256'],'wrong executable')
binary.chmod(0o755)
demo=case['binary']=='moving-voronoi3'
if demo:
    require(digest(Path('catalog.txt').read_bytes())==case['catalog_sha256'],'wrong fixture')
    args=['--sweeps','catalog.txt','0.5','0.5']
else:
    args=['--exact',case['selector'],'--include-ignored','--nocapture','--test-threads=1']
t=time.monotonic()
try:
    child=subprocess.run([str(binary.resolve()),*args],capture_output=True,timeout=600)
except subprocess.TimeoutExpired as failure:
    stdout=failure.output or b'';stderr=failure.stderr or b''
    Path('stdout.txt').write_bytes(stdout);Path('stderr.txt').write_bytes(stderr)
    Path('result.json').write_text(json.dumps(dict(passed=False,outcome='timeout',
        source_revision=case['parent']['source_revision'],parent=case['parent'],selector=case['selector'],
        elapsed_seconds=time.monotonic()-t,binary=case['binary'],binary_sha256=case['sha256'],args=args,
        returncode=None,stdout_sha256=digest(stdout),stderr_sha256=digest(stderr)), indent=2)+'\n')
    raise
elapsed=time.monotonic()-t
out=child.stdout.decode()
Path('stdout.txt').write_bytes(child.stdout)
Path('stderr.txt').write_bytes(child.stderr)
if demo:Path('mesh.csv').write_bytes(child.stdout)
report=dict(source_revision=case['parent']['source_revision'],parent=case['parent'],selector=case['selector'],binary=case['binary'],binary_sha256=case['sha256'],args=args,elapsed_seconds=elapsed,returncode=child.returncode,stdout_sha256=digest(child.stdout),stderr_sha256=digest(child.stderr),passed=False)
def save():Path('result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
save()
require(child.returncode==0,'native exit '+str(child.returncode))
if demo:
    import re
    measurements=re.findall(r'^sweeps step=(\d+) rule=(Euler|Heun) raw_relative=(\S+) corrected_relative=(\S+) max_abs_correction=(\S+)$',child.stderr.decode(),re.M)
    require(sorted((int(i),r) for i,r,*rest in measurements)==[(1,'Euler'),(1,'Heun'),(2,'Euler'),(2,'Heun')],'exact sweep ledger coverage')
    require(all(float(closed)<=1e-12 and math.isfinite(float(raw)) and math.isfinite(float(change)) for i,r,raw,closed,change in measurements),'verified sweep residuals')
    report['sweeps']=measurements
    from collections import defaultdict
    rows=defaultdict(list)
    owners=set()
    for row in csv.DictReader(io.StringIO(out)):
        step=int(row['step']); i=int(row['owner'],16)&((1<<64)-1)
        require(step in (0,1,2) and float(row['time'])==0.5*step,'incorrect clock')
        owners.add((step,i))
        if row['neighbour']:
            j=int(row['neighbour'],16)&((1<<64)-1)
            if {i,j}=={3,4}:rows[(step,i)].append(row)
    require(owners=={(i,j) for i in range(3) for j in range(5)},'missing cell or step')
    require(set(rows)=={(2,3),(2,4)},'wrong contact/birth epoch')
    poly={}
    for (step,i),verts in rows.items():
        require(len(verts)==3,'triangle count')
        sign=1 if i==3 else -1
        require(all(int(r['sign'])==sign and abs(float(r['area'])-1/192)<1e-13 and float(r['nz'])==sign for r in verts),'side or area')
        pts=[tuple(float(r[a])+float(r['d'+a]) for a in 'xyz') for r in verts]
        expected=[(-1/32,-1/16,-1/32),(-1/32,1/16,-1/32),(5/96,0,-1/32)]
        for pt in pts:require(any(max(abs(a-b) for a,b in zip(pt,q))<1e-12 for q in expected),'vertex against independent oracle')
        a,b,c=pts
        signed=((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
        require(abs(signed-sign/192)<1e-13,'signed area from exported vertices')
        poly[i]=pts
    for a,b in zip(poly[3],[poly[4][j] for j in (0,2,1)]):require(max(abs(x-y) for x,y in zip(a,b))<1e-12,'paired chart winding')
    report['metrics']=dict(area=1/192,signed_area=[1/192,-1/192],steps=3,positions=15,vertices=poly[3])
else:
    expected=f"test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; {case['count']-1} filtered out;"
    require('running 1 test\n' in out and expected in out and 'test '+case['selector']+' ...' in out,'incorrect exact leaf')
    report['observations']=[l for l in out.splitlines() if any(k in l for k in ('SMOOTH ','RIGID ','FLIP ','dimensionless_rms'))]
report['passed']=True
save()
