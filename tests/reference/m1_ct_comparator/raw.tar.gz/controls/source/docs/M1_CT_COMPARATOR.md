# Bounded fixed/rigid Voronoi CT comparator

This is a separately named `voronoi-ct-heun-v1` engineering comparator for
issue #7, authorized on 2026-11-09. It tests a complete alternative magnetic
coupling. It does not replace or implement the Springel–Mayer–Pakmor (2026)
cell-centred vector-potential method, and cannot establish that method's M1
acceptance. The default profiles, physical configurations and gates remain.

## Source and prospective contract

The magnetic discretization follows Mocz, Vogelsberger & Hernquist (2014),
[section 2.3, equations 25–32](https://arxiv.org/html/1402.5963v2#S2.SS3).
The fluid update reuses our independently implemented moving-face HLLD/ALE
kernels (Springel's moving finite-volume formalism). Public AREPO's
direct-B/Powell implementation is a source reference, not this CT algorithm
or the 2026 paper implementation. See the [pinned source audit](provenance/m1_literature_review_20261109.json).
No external source code is imported (public AREPO is GPL-3.0).

- Units mu0=1, f64, ideal gas; periodic 2.5D geometry; all three physical
  field/velocity components. Fixed or rigidly translating mesh only, stored
  in comoving coordinates. No topology changes, cleaning, Powell sources,
  pressure floors, entropy fallback or energy resets.
- One oriented magnetic flux Phi per shared face, oriented left to right.
  With t=(-ny,nx), endpoints minus/plus are centroid +/- length*t/2.
  Initialize Phi=Az(plus)-Az(minus)+length*(mean_B dot n), evaluating the
  periodic analytic potential once per shared vertex. Bz is a cell integral,
  initialized separately from the analytic physical Bz and evolved by FV.
- Recover cell Bxy by equation 30's weighted least squares of Phi/length
  against face normals, with w=1/distance(cell centroid,face centroid).
  Use this recovered field for pressure closure and primitive reconstruction.
  Riemann Bn remains the average of the two limited reconstructed states
  (equation 20), as in the published Voronoi CT method. It is not in general
  identical to Phi/length. Report CT and independent cell-field divergences.
- Interpolate face Riemann EMFs in the rigid-mesh rest frame to each vertex
  with affine-exact barycentric weights (equation 31). For four or more
  incident faces at a degenerate vertex, use the minimum-norm affine-exact
  extension; this is an explicit engineering choice. No upwind weight change.
  Update Phi_dot=EMF(plus)-EMF(minus). Shared vertex incidence must telescope
  exactly at the integer topology level; only floating-point accumulation
  remains in the signed cell flux sum. Degenerate/ill-conditioned fits fail.
- Heun method of lines, with full primitive/B/flux recomputation at each
  stage; this differs from the published endpoint predictor. Fluid and Bz
  face exchanges are equal and opposite. The existing limited neighbour-LS
  reconstruction, HLL fallback and cfl=.3 are retained. Both trial stages
  must be positive and satisfy their CFL bounds, otherwise halve dt (16
  attempts) from immutable old data. Count accepted and attempted fallbacks.

## Bounded checks, declared before execution

First test periodic vertex incidence (regular and jittered), affine EMF
interpolation, constant-field recovery, a manufactured Faraday sign/update,
uniform states, conservation, failed-step immutability and joint rigid boosts.
Audit frozen pressure rates via dp=(gamma-1)*(dE-v dot dm+v^2 drho/2-B dot dB).

Then run original Brio nx256/512, ny4, jitter0/.15, base and fluid/grid boost
(2,-1,0), to t=.01 and .02. Keep gamma2 and box [0,2]x[0,.125]. Retain
max |Bx-.75| <=1e-8, positive states, budgets <=1e-10 and boost comparison
<=1e-8; execution completion is distinct from passing those gates.
Run short Alfvén N8/16/32 regular/jittered travelling/standing t=.02,
dt<=.00025, measuring B/v spatial order (development screen >=1.8), plus
N16 boosts. These short controls do not replace the full M1 wave ladder.

At most three serial simulations at once; 30 wall seconds per case. Archive
failures and initial/final physical fields, accepted-step minima/budgets,
CT/LS/arithmetic-face divergence, frozen rates, run commands and revision.
Do not resume long REANA jobs or promote the comparator from these tests.

## Results

Pending implementation and bounded measurements.
