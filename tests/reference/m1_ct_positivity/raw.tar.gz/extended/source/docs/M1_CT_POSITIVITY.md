# Coupled admissibility experiment

Prospective contract, 2026-11-09, issue #7. Continue the separately named
[CT comparator](M1_CT_COMPARATOR.md); do not change the paper A profiles.

## Mathematical basis and limits

For fixed geometry, the recovered B is linear in stored face fluxes and
the cell Bz integral. The set rho>0, E-|m|²/(2rho)-|B|²/2>0 is convex
([Wu & Shu, lemma 2.2](https://arxiv.org/html/1807.11467v1#S2)). Therefore a
single convex coefficient applied to **all fluid integrals, magnetic face
fluxes and Bz integrals together** can limit a high-order update toward an
admissible low-order one. Shared-face conservation and the CT incidence
identity are retained. Limiting gas fluxes alone would not give this result.

The literature does not prove that our low-order CT update is positive.
[Pang & Wu (2024)](https://arxiv.org/html/2410.05173v1) instead construct a
different split Cartesian method; their theorem is not inherited here.
First measure the frozen original CT failure with reconstructed HLLD,
cell-constant HLLD and cell-constant Rusanov fluxes. Rusanov uses the existing
moving-face transformation and common normal B, with symmetric speed
a=max(|sL|,|sR|); its flux is (FL+FR-a*(UR-UL))/2 in the face frame.
No arbitrary diffusion multiplier, energy reset or pressure floor.

If the lower-order full Euler update is admissible, test a separately named
global convex limiter. For each forward-Euler leg of SSP Heun, form both
coupled updates and search theta in [0,1] for the largest admissible blend.
Require density and internal energy at least 1e-10 of their positive
low-order values as a relative roundoff margin (engineering choice, not a
physical floor or source). If high order passes use theta=1 unchanged.
If low order fails, halve dt; never label it a positivity guarantee.
Apply the final SSP convex average, check positivity again, and count all
limited legs, minimum theta and low-order failures. A scalar shared by the
whole domain is deliberately simple and potentially over-diffusive; do not
claim locality, general accuracy, or the original paper algorithm.

## Bounded tests

Keep the original nx256/512, ny4 Brio geometry, regular/jitter .15, base and
joint boost, t=.01/.02. Keep Bx<=1e-8, fluid budgets<=1e-10 and the existing
short-wave order screen>=1.8. Add uniform/boost, analytical Rusanov flux,
joint convexity and conservation/divergence tests, and baseline output parity.
At most three serial cases, 30 wall seconds per case. No long REANA runs.
Retain failures; a stable evolution is not full M1 acceptance.

After the primary packet completes, additional short robustness controls are
declared: nx256 jittered t=.02 with dt caps .0001/.00005/.000025, each base
and boost; nx256/512 jittered t=.04 base and boost. These ten cases check
step-size sensitivity and whether stability extends beyond the original
failure, without changing any accuracy gate or starting the full M1 matrix.
