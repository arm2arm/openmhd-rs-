from pathlib import Path
import numpy as np,json
out=Path('/tmp/openmhd_compact_ai');results=[]
for kind,j,clean in [('Q','0',False),('Q','0.15',True),('C','0.15',True)]:
 p=out/f'alfven_{kind}_n8_j{j}_clean{str(clean).lower()}_e0.0000001.csv';M=np.loadtxt(p,delimiter=',');e,V=np.linalg.eig(M);k=int(np.argmax(e.real));v=V[:,k];v/=max(abs(v));res=float(max(abs(np.sum(M*v[None,:],axis=1)-e[k]*v)));peaks={}
 for component,label in enumerate(['Ax','Ay','vz','phi']):
  z=v[64*component:64*(component+1)].reshape(8,8);power=abs(np.fft.fft2(z))**2;idx=np.argsort(power.ravel())[-4:][::-1]
  peaks[label]={'amplitude_max':float(max(abs(z).ravel())),'index_modes':[(int(round(np.fft.fftfreq(8)[i%8]*8)),int(round(np.fft.fftfreq(8)[i//8]*8)),float(power.ravel()[i]/power.sum())) for i in idx] if power.sum() else []}
 r={'gradient':kind,'jitter':float(j),'cleaning':clean,'growth_eigenvalue':[float(e[k].real),float(e[k].imag)],'eigenpair_residual':res,'peaks':peaks};results.append(r);print(r)
(out/'dominant_modes.json').write_text(json.dumps(results,indent=2)+'\n')
