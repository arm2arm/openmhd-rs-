import json,hashlib
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');base=root/'results/m1_matched_probe';out=Path('/tmp/openmhd_compact_ai')
prov=json.loads((base/'provenance.json').read_text())
for name,digest in prov['result_sha256'].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest
runs=json.loads((base/'runs.json').read_text());result={}
for n in (64,128,256):
 r=runs[f'n{n}'];stages={}
 for stage in ('initial','checkpoint_0.25000000','final'):
  p=base/f'n{n}'/(stage+'.csv');assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'][p.name]
  a=np.genfromtxt(p,delimiter=',',names=True);assert len(a)==n*n and np.array_equal(a['id'],np.arange(n*n));w=a['volume']/sum(a['volume']);t=a['time'][0];assert (a['time']==t).all();phase=2*np.pi*(a['x']+t)
  exact={'bx':np.ones(len(a)),'by':.1*np.sin(phase),'bz':.1*np.cos(phase),'vx':np.zeros(len(a)),'vy':.1*np.sin(phase),'vz':.1*np.cos(phase),'rho':np.ones(len(a)),'p':np.ones(len(a))*.1};err={k:a[k]-v for k,v in exact.items()};norm=lambda v:dict(L1=float(sum(w*abs(v))),RMS=float(np.sqrt(sum(w*v*v))),max=float(max(abs(v))))
  X=np.column_stack([np.ones(len(a)),np.sin(phase),np.cos(phase)]);fits={}
  for k in ('bx','by','bz','vx','vy','vz'):
   coeff=np.linalg.lstsq(X*np.sqrt(w[:,None]),a[k]*np.sqrt(w),rcond=None)[0];rem=a[k]-np.sum(X*coeff,axis=1);F=np.fft.fft2(err[k].reshape(n,n));power=np.abs(F)**2;inds=np.argsort(power.ravel())[-4:][::-1]
   fits[k]={'coefficients_const_sin_cos':coeff.tolist(),'beyond_fundamental':norm(rem),'error_energy_fraction_beyond_fundamental':float(sum(w*rem*rem)/(sum(w*err[k]*err[k])+1e-99)),'largest_index_modes':[(int(round(np.fft.fftfreq(n)[i%n]*n)),int(round(np.fft.fftfreq(n)[i//n]*n)),float(power.ravel()[i]/sum(power.ravel()))) for i in inds] if power.sum() else []}
  rec={'t':float(t),'errors':{k:norm(v) for k,v in err.items()},'B':norm(np.sqrt(sum(err[k]**2 for k in ('bx','by','bz')))),'fits':fits,'raw_sha256':r['sha256'][p.name]};stages[stage]=rec
  print(n,stage,'B',rec['B'],'RMS',{k:float(f'{v["RMS"]:.7g}') for k,v in rec['errors'].items()})
 result[str(n)]={'stages':stages,'summary':{k:r['summary'][k] for k in ['profile','steps','quadratic_condition','rejected_state','rejected_cfl','hll_fallbacks']},'final':r['summary']['final']}
 print(n,'final component fits',json.dumps({k:stages['final']['fits'][k] for k in ('by','bz','vz')}))
order=-float(np.polyfit(np.log([64,128,256]),np.log([result[str(n)]['stages']['final']['B']['L1'] for n in (64,128,256)]),1)[0]);result['finest_three_order']=order;result['order_gate']='FAIL';print('finest-three order',order)
(out/'matched_failure.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
