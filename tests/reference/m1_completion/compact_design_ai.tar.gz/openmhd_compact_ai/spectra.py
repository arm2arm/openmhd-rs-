from pathlib import Path
import json,numpy as np
out=Path('/tmp/openmhd_compact_ai');results=[]
for n in (8,16):
 for j in ('0','0.15'):
  for kind in ('L','Q','C'):
   L=np.loadtxt(out/f'lap_{kind}_n{n}_j{j}.csv',delimiter=',');curl=np.loadtxt(out/f'curl_{kind}_n{n}_j{j}.csv',delimiter=',');e=np.linalg.eigvals(L)
   rec=dict(operator='cleaning_laplacian',n=n,jitter=float(j),gradient=kind,max_real_eigenvalue=float(max(e.real)),positive_modes=int(sum(e.real>1e-8)),curl_infinity_norm=float(max(np.sum(abs(curl),axis=1))));results.append(rec);print(rec)
   if n==8:
    for clean in (False,True):
     matrices=[]
     for eps in ('0.000001','0.0000001'):
      M=np.loadtxt(out/f'alfven_{kind}_n{n}_j{j}_clean{str(clean).lower()}_e{eps}.csv',delimiter=',');matrices.append(M);e=np.linalg.eigvals(M)
      rec=dict(operator='unlimited_uniform_alfven_semidiscrete',n=n,jitter=float(j),gradient=kind,cleaning=clean,perturbation=float(eps),max_real_eigenvalue=float(max(e.real)),positive_modes=int(sum(e.real>1e-7)),max_imag=float(max(abs(e.imag))));results.append(rec);print(rec)
     print('epsilon matrix difference',kind,j,clean,float(max(abs(matrices[0]-matrices[1]).ravel())))
(out/'spectra.json').write_text(json.dumps(results,indent=2)+'\n')
