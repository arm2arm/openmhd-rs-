# Separate AI design review: moment-corrected linear derivatives

Read-only diagnostics, 2026-11-05. No production solver code was modified and no compact-profile physical simulation was run. The proposed correction was reviewed before implementation. Existing matched-profile failed evidence remains unchanged.

## Reproduction and source

The Rust probe uses the existing moving-mesh derivative methods and actual mhd-core `riemann_with_completion(..., SymmetricHll)` from scientific revision `f9a11f04d7de943920a0be07b3033df328796e0d`. Repository documentation and archival commits advanced independently; these scientific library methods were unchanged when the probe was built. `operators.rs` contains the entire independent operator/linearization driver, including the proposed correction; it does not replace or edit a solver module. `provenance.json` records source hashes, compiler and raw execution-provenance digest.

Use a checkout with those library methods and the pinned compiler. The exact build/run orchestration is saved in `reproduce.py`:

```sh
python3 /tmp/openmhd_compact_ai/reproduce.py --repo /Users/arm2arm/orca/workspaces/openmhd-rs-/M0
```

This calls `cargo build --locked -p moving-mesh -p mhd-core`, then `rustc --edition=2024 -O operators.rs -L dependency=REPO/target/debug/deps --extern moving_mesh=RLIB --extern mhd_core=RLIB -o operators`. It runs the binary and the three Python diagnostics with OPENBLAS_NUM_THREADS=1, VECLIB_MAXIMUM_THREADS=1 and OMP_NUM_THREADS=1. The scripts retain the original absolute repository/results and `/tmp/openmhd_compact_ai` paths. All linear algebra in this review used one BLAS thread.

## Proposed operator

With existing linear derivative coefficients w_ij and actual periodic-image neighbour offsets d_ij, compute moments

```
M_i[k,:] = sum_j w_ij[k] * [dx²/2, dy²/2, dx*dy]
Gc f_i = GL f_i - M_i H_Q(f)_i.
```

H_Q is the unchanged quadratic-fit Hessian. The probe obtains offsets by zipping the original face-ordered samples with the original cell-face list and checking each neighbour ID. It never reconstructs periodic offsets solely from IDs. Exact quadratics give GL f=grad f+M H, so the correction reproduces their gradient. The N16 regular and jitter .15 interior quadratic fixtures have maximum error 1.33e-15. Regular moments are zero at N8 and at most 5.20e-18 at N16; Gc then reduces to GL up to roundoff. This is a narrow derivative backbone with a two-ring Hessian correction, not a strictly nearest-neighbour operator or a claim of a published-paper algorithm.

## Matched N256 failure

`matched_failure.py` validates the completed execution's manifest/runs seals and every inspected raw CSV digest. It reads N64/128/256 at t=0,.25,1, computes volume-weighted component/vector errors, and fits constant/sin/cos using actual physical cell x coordinates. It also records index-grid FFT peaks; on jittered samples these are a diagnostic, not exact physical-space Fourier modes.

The final matched B L1 values are .001334652308, .000345468325, .000457423573. The finest-three order is .772430666, failing the unchanged 1.8 requirement. N256 final RMS errors are Bx=3.72e-5, By=6.96e-5, Bz=5.84e-4, vz=5.27e-4, rho=5.36e-3. Approximately 97.9% of Bz/vz error energy is outside the fundamental. Dominant index peaks are around (±97,±6–7). The failure therefore again contains a short-wavelength out-of-plane perturbation, not only phase/amplitude error. These snapshots do not uniquely identify its cause.

## Small cleaning spectra

`lap_*` and `curl_*` are basis-vector matrices for N8/16, regular/jitter .15. L means linear, Q broad quadratic, C the proposed correction; each case uses the same derivative for divergence, curl and scalar gradient. No cleaning Laplacian has a positive-real eigenvalue above 1e-8 in these samples. Arbitrary irregular cancellation is not obtained: the C curl-grad infinity norm is about 51.53 at jitter N8 and 223.43 at jitter N16. These norms scale with differentiation and are not physical divergence acceptance metrics.

## Coupled uniform-Alfvén diagnostic

`alfven_*` matrices are symmetric finite-difference Jacobians at uniform rho=1, p=.1, gamma=5/3, B=(1,0,0), v=0, A=phi=0, fixed periodic geometry. Variables are (Ax,Ay,vz,phi). This subsystem contains the linear out-of-plane Alfvén and cleaning perturbations. The probe uses:

- Bz=Dx Ay-Dy Ax with L/Q/C.
- Unlimited existing linear primitive reconstruction at faces.
- Actual FV momentum-z flux and symmetric-HLL numerical EMF completion.
- Positive centroid-triangle source weights.
- The matching scalar gradient and div(A), alpha=1, beta=.15, cs²=1/6, actual cell radii when cleaning is enabled.
- The volume-mean vz subtraction for the fixed bulk reference gauge. Uniform auxiliary terms cancel to first order about this background; distortion is second order in the perturbations and xy advection vanishes in this restricted subsystem.

Both cleaning-enabled and disabled matrices are saved. The latter isolates coupling from cleaning. The matrices are semidiscrete and unlimited: they are neither the nonlinear limited travelling-wave Jacobian nor the full frozen-C1/endpoint timestep map.

At N8, Q has a positive real eigenvalue .797914621 on the regular mesh with or without cleaning. The dominant eigenvector has Ay/vz Fourier support at (±2,-4), and eigenpair residual 4.61e-14. This is a concrete broad-derivative/FV coupling defect even when cleaning is absent. On jitter .15, Q maxima are .491427748 without cleaning and .484097895 with cleaning.

C reproduces L on the regular mesh. With cleaning disabled, C has no positive eigenvalue above 1e-7 in either mesh. With cleaning enabled, the jitter C matrix still has a weak real growing mode .00443182667 (L gives .00634368056); its eigenpair residual is 1.91e-13. Therefore no unconditional stability claim is justified. The Q and jitter-C findings persist at perturbations 1e-6 and 1e-7. Regular L/C finite-difference matrices differ by up to 1.06e-4 between these perturbations because the actual Riemann implementation is sampled near a degenerate uniform fan; the largest small positive no-cleaning eigenvalue is 7.99e-8. Treat those near-zero results as numerical controls, not exact sign proofs.

The positive broad-Q modes support the separate corrected-derivative experiment, but their existence does not prove they alone cause the particular N256 nonlinear failure. In particular the observed fine-grid index peaks are not simply the regular N8 dominant mode rescaled.

## Review boundary

Bounded design approval: use Gc consistently for raw A/curl/div and unlimited phi gradients; use Gc and H_Q together in limited donor polynomials, with the existing common per-component limiter factor. Preserve initial magnetic-energy consistency, periodic sample geometry, historical profiles and failed results. No new coefficient, timestep setting or acceptance threshold is introduced. The existing CFL remains an experimental bound, not a proven bound for all corrected irregular stencils. Require polynomial/constant identities, regular reduction, periodic-image/ID permutation checks, smooth refinement, limiter bounds, boosts and the unchanged complete physical packet. No M1 acceptance is given here.
