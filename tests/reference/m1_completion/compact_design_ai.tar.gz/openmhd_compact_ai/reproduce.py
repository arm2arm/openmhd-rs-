from pathlib import Path
import argparse,subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--python',type=Path,default=Path('/Users/arm2arm/.venvs/openmhd-plot/bin/python'));a=p.parse_args();root=a.repo.resolve();out=Path(__file__).resolve().parent
cargo=Path.home()/'.cargo/bin/cargo';subprocess.run([str(cargo),'build','--locked','-p','moving-mesh','-p','mhd-core'],cwd=root,check=True);deps=root/'target/debug/deps'
cmd=[str(cargo.with_name('rustc')),'--edition=2024','-O',str(out/'operators.rs'),'-L','dependency='+str(deps)]
for name in ['moving_mesh','mhd_core']:cmd+=['--extern',name+'='+str(max(deps.glob('lib'+name+'-*.rlib'),key=lambda p:p.stat().st_mtime))]
cmd+=['-o',str(out/'operators')];subprocess.run(cmd,check=True)
with (out/'operators.txt').open('w') as f:subprocess.run([str(out/'operators')],stdout=f,check=True)
import os
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'}
for script in ['spectra','dominant_modes','matched_failure']:
 with (out/(script+'.txt')).open('w') as f:subprocess.run([str(a.python),str(out/(script+'.py'))],stdout=f,check=True,env=env)
