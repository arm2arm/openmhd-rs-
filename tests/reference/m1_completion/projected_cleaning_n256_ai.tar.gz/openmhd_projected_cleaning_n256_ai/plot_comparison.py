from pathlib import Path
import json,hashlib
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;previous=p.parent/'openmhd_projected_cleaning_control_ai';sha=lambda b:hashlib.sha256(b).hexdigest();old=json.loads((previous/'checksums.json').read_text());assert sha((previous/'analysis.json').read_bytes())==old['analysis.json'];a=json.loads((previous/'analysis.json').read_text());b=json.loads((p/'analysis.json').read_text());N=[64,128,256]
rows={}
for name,key in [('projected baseline','baseline'),('no phi forcing diagnostic','no_phi_forcing')]:
 rr=[a['cases'][f'n{n}'][key] for n in N[:2]]+[b['cases']['baseline_interim' if key=='baseline' else key]];rows[name]=dict(B_L1=[x['errors']['B']['L1'] for x in rr],Bz_noise_RMS=[x['beyond_fundamental']['bz']['RMS'] for x in rr])
fig,axes=plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
for ax,key,label in zip(axes,['B_L1','Bz_noise_RMS'],['Magnetic vector L1 error','Bz beyond-fundamental RMS']):
 for name,v in rows.items():ax.loglog(N,v[key],'-o',label=name)
 anchor=rows['no phi forcing diagnostic'][key][0];ax.loglog(N,[anchor*(64/n)**2 for n in N],':',color='gray',label='N^-2 guide (not fit)');ax.set_xticks(N,[str(n) for n in N]);ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator());ax.set_xlabel('N (N × N cells)');ax.set_ylabel(label);ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.suptitle('Quarter-time isolation: disabling only phi divergence forcing\nN256 baseline is an interim captured checkpoint; no acceptance claim');fig.savefig(p/'quarter_comparison.png',dpi=170);plt.close(fig)
(p/'plot_inputs.json').write_text(json.dumps(dict(previous_analysis_sha256=sha((previous/'analysis.json').read_bytes()),current_analysis_sha256=sha((p/'analysis.json').read_bytes()),data=rows),indent=2)+'\n')
