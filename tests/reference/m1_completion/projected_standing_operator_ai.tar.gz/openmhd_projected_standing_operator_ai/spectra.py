from pathlib import Path
import json,hashlib
import numpy as np
p=Path(__file__).resolve().parent;out={}
for limited in ['false','true']:
 for mode in ['rate','step']:
  file=p/f'{mode}_limited{limited}.csv';a=np.loadtxt(file,delimiter=',');val,vec=np.linalg.eig(a);score=val.real if mode=='rate' else abs(val);order=np.argsort(score)[::-1];records=[]
  for k in order[:12]:
   v=vec[:,k];records.append(dict(eigenvalue_real=float(val[k].real),eigenvalue_imag=float(val[k].imag),magnitude=float(abs(val[k])),eigen_residual=float(np.linalg.norm(np.sum(a*v[None,:],axis=1)-val[k]*v)/np.linalg.norm(v))))
  # Validate all strong positive modes, one representative per conjugate pair; unlimited leading control.
  modes=[]
  for k in order:
   if val[k].imag < -1e-10:continue
   if limited=='true' and not (val[k].real>1e-3 if mode=='rate' else abs(val[k])>1+1e-7):continue
   v=vec[:,k];phase=np.angle(v[np.argmax(abs(v))]);v*=np.exp(-1j*phase);index=len(modes);name=f'{mode}_limited{limited}_mode{index}';np.savetxt(p/(name+'.csv'),np.column_stack([v.real,v.imag]),delimiter=',',fmt='%.17e');modes.append(dict(name=name,real=float(val[k].real),imag=float(val[k].imag),score=float(score[k]),real_norm=float(np.linalg.norm(v.real)),imag_norm=float(np.linalg.norm(v.imag))))
   if limited=='false' and len(modes)==1:break
  key=f'{mode}_limited{limited}';out[key]=dict(matrix_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),top12=records,modes=modes,positive_count_above_1e_3=int(np.count_nonzero(val.real>1e-3)) if mode=='rate' else None,gain_count_above_1_plus_1e_7=int(np.count_nonzero(abs(val)>1+1e-7)) if mode=='step' else None)
  print(key,'top',[(r['eigenvalue_real'],r['eigenvalue_imag'],r['magnitude']) for r in records[:3]],flush=True)
  if limited=='false':
   old=p.parent/'openmhd_standing_ai'/f'full_{mode}_n8_v1_limitedfalse_e0.0000001.csv';b=np.loadtxt(old,delimiter=',');out[key]['old_compact_unlimited_max_difference']=float(np.max(abs(a-b)));out[key]['old_compact_unlimited_bit_identical']=bool(np.array_equal(a,b));print('unlimited old maximum difference',np.max(abs(a-b)),flush=True)
(p/'spectra.json').write_text(json.dumps(out,indent=2)+'\n')
