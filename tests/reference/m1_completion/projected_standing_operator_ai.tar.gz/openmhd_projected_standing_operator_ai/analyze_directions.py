from pathlib import Path
import csv,json
import numpy as np
p=Path(__file__).resolve().parent;r=list(csv.DictReader((p/'directional.csv').open()));norm=np.linalg.norm;matrix={f'{m}_{l}':np.loadtxt(p/f'{m}_limited{l}.csv',delimiter=',') for m in ['rate','step'] for l in ['false','true']};records=[];checks=0;maxerr=0.;maxproduct=0.
for row in r:
 eps=float(row['amplitude']);files=list(p.glob('response_'+row['direction']+'_e*.csv'));file=next(x for x in files if float(x.stem.split('_e')[-1])==eps);a=np.genfromtxt(file,delimiter=',',names=True);assert len(a)==576 and np.array_equal(a['coordinate'],np.arange(576));v=a['mode'];pr=a['predicted_rate'];ps=a['predicted_step'];rp=a['plus_rate'];rm=a['minus_rate'];sp=a['plus_step'];sm=a['minus_step'];rs=.5*(rp+rm);ss=.5*(sp+sm);dt=1e-4;rn=max(norm(pr),1e-30);inc=(ps-v)/dt;incn=max(norm(inc),1e-30);vn=norm(v)
 if eps==1e-7:
  for label,value in [('rate',pr),('step',ps)]:
   direct=np.sum(matrix[label+'_'+row['limited']]*v[None,:],axis=1);err=float(np.max(abs(direct-value)));maxproduct=max(maxproduct,err);assert err<1e-11
 values={'predicted_rate_projection':np.sum(v*pr)/np.sum(v*v),'rate_plus_projection':np.sum(v*rp)/np.sum(v*v),'rate_minus_projection':np.sum(v*rm)/np.sum(v*v),'rate_symmetric_projection':np.sum(v*rs)/np.sum(v*v),'rate_plus_relative_mismatch':norm(rp-pr)/rn,'rate_minus_relative_mismatch':norm(rm-pr)/rn,'rate_symmetric_relative_mismatch':norm(rs-pr)/rn,'rate_onesided_disagreement':norm(rp-rm)/rn,'predicted_step_gain':norm(ps)/vn,'step_plus_gain':norm(sp)/vn,'step_minus_gain':norm(sm)/vn,'step_symmetric_gain':norm(ss)/vn,'step_plus_increment_mismatch':norm((sp-v)/dt-inc)/incn,'step_minus_increment_mismatch':norm((sm-v)/dt-inc)/incn,'step_symmetric_increment_mismatch':norm((ss-v)/dt-inc)/incn,'step_onesided_increment_disagreement':norm((sp-sm)/dt)/incn}
 for k,value in values.items():err=abs(float(row[k])-value)/max(1,abs(value),abs(float(row[k])));checks+=1;maxerr=max(maxerr,float(err));assert err<1e-10
 q=dict(row)
 for sign in ['plus','minus']:
  num=sum(float(row[f'{sign}_{k}_end_rms'])**2 for k in ['B','v']);den=sum(float(row[f'{sign}_{k}_initial_rms'])**2 for k in ['B','v']);q[sign+'_physical_Bv_gain']=(num/den)**.5
 records.append(q)
selected=[q for q in records if float(q['amplitude'])==1e-7];limited=[q for q in selected if q['limited']=='true'];out=dict(scope='Actual directions; coordinate spectra are not assumed Frechet Jacobians',directions=len(selected),amplitude_cases=len(records),scalar_checks=checks,maximum_scaled_statistic_difference=maxerr,maximum_matrix_product_difference=maxproduct,limited_directions_with_actual_plus_physical_gain_above_one=sum(q['plus_physical_Bv_gain']>1 for q in limited),limited_direction_count=len(limited),maximum_actual_physical_gain=max(q['plus_physical_Bv_gain'] for q in limited),selected_amplitude_1e_7=selected,all_rows=records)
(p/'directional_analysis.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['selected_amplitude_1e_7','all_rows']})
