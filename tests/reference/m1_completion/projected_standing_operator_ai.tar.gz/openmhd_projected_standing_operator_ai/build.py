from pathlib import Path
import subprocess,json,hashlib,sys
p=Path(__file__).resolve().parent;prov=json.loads((p/'provenance.json').read_text());stage=sys.argv[1];source=''
for m in ['gauge','auxiliary','operators','general']:
 code=(p/(m+'_frozen.rs')).read_text().replace('//!','//')
 if m=='general':code+='\n'+(p/'initial_and_rates.rs').read_text()+'\n'+(p/(stage+'_extra.rs')).read_text()
 source+='mod '+m+' {\n'+code+'\n}\n'
source+='fn main(){general::audit_'+('jac' if stage=='jacobian' else 'directions' if stage=='directions' else 'evolution')+'("'+str(p)+'");}\n';(p/(stage+'.rs')).write_text(source)
cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-O','-Awarnings',str(p/(stage+'.rs')),'-L','dependency='+str(Path(next(iter(prov['library_sha256']))).parent)]
for file,digest in prov['library_sha256'].items():
 assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==digest;name=Path(file).name.split('-')[0][3:];cmd+=['--extern',name+'='+file]
cmd+=['-o',str(p/stage)];subprocess.run(cmd,check=True)
with (p/(stage+'.log')).open('w') as f:subprocess.run([str(p/stage)],stdout=f,stderr=subprocess.STDOUT,check=True)
prov[stage]=dict(compile_command=cmd,run_command=[str(p/stage)],source_sha256=hashlib.sha256(source.encode()).hexdigest(),binary_sha256=hashlib.sha256((p/stage).read_bytes()).hexdigest());(p/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n');print((p/(stage+'.log')).read_text())
