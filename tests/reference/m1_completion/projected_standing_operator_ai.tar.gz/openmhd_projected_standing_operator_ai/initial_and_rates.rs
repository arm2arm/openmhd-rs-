use std::fmt::Write as _;
fn review_sim(n:usize,parallel:f64,boost:[f64;3],limited:bool)->Simulation{
 let config=Config{profile:Profile::BulkFrameHllProjectedV1,mean_magnetic:[1.,0.,0.],motion:Motion::Rigid([boost[0],boost[1]]),limited,..Config::default()};
 Simulation::new(Mesh::lattice(n,n,[1.;2],0.).unwrap(),config,|p|{let x=std::f64::consts::TAU*p[0];Initial{density:1.,pressure:0.1,velocity:[parallel+boost[0],0.1*x.sin()+boost[1],0.1*x.cos()+boost[2]],potential:[0.,0.1/std::f64::consts::TAU*x.sin(),0.1/std::f64::consts::TAU*x.cos()],phi:0.}}).unwrap()
}
fn review_flat(state:&State)->Vec<f64>{let n=state.mesh.cells.len();let mut x=vec![0.;9*n];for i in 0..n{for k in 0..5{x[k*n+i]=state.conserved[i][k]/state.mesh.cells[i].volume;}for k in 0..3{x[(5+k)*n+i]=state.potential[i][k];}x[8*n+i]=state.phi[i];}x}
fn review_rate(s:&Simulation,p:&Prepared)->Vec<f64>{let n=s.state.mesh.cells.len();let mut x=vec![0.;9*n];for i in 0..n{for k in 0..5{x[k*n+i]=p.fluid.q[i][k]/s.state.mesh.cells[i].volume;}for k in 0..3{x[(5+k)*n+i]=p.potential_rate[i][k];}x[8*n+i]=p.cleaning[i].initial_rate();}x}
