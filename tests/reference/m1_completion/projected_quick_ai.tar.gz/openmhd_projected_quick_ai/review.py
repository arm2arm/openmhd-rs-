from pathlib import Path
import json,hashlib,gzip,csv,io,math,subprocess,itertools
p=Path(__file__).resolve().parent;root=p.parents[2];study=root/'results/m1_projected_quick';archive=root/'tests/reference/m1_completion/projected_quick';sha=lambda b:hashlib.sha256(b).hexdigest();metadata={k:(study/k).read_bytes() for k in ['provenance.json','summary.json','manifest.json','runs.json']}
for k,b in metadata.items():(p/k).write_bytes(b)
prov,summary,manifest,runs=[json.loads(metadata[k]) for k in ['provenance.json','summary.json','manifest.json','runs.json']];assert prov['revision']=='fb8bb14bf362a9eb42c2f32d6ec8c1252482790d' and not prov['dirty_status'];assert len(manifest)==len(runs)==len(summary['runs'])==48;assert set(manifest)==set(runs)==set(summary['runs'])
for file,h in prov['result_sha256'].items():assert sha(metadata[file])==h
for file,h in prov['source_sha256'].items():assert sha(subprocess.check_output(['git','show',prov['revision']+':'+file],cwd=root))==h,file
binary=Path('/tmp/openmhd-m1-projected-v2/target/release/vector-potential');assert sha(binary.read_bytes())==prov['binary_sha256']
for c in prov['mesh_caches'].values():assert sha(Path(c['path']).read_bytes())==c['sha256']
archive_meta=json.loads((archive/'archive_provenance.json').read_bytes());assert archive_meta['run_outcomes']=={'wave':{'completed':48}};assert sha((root/'scripts/archive_m1_completion.py').read_bytes())==archive_meta['script_sha256']
for file,h in archive_meta['archive_sha256'].items():assert sha((archive/file).read_bytes())==h;unzip=gzip.decompress((archive/file).read_bytes());assert sha(unzip)==archive_meta['uncompressed_sha256'][file];assert unzip==metadata[Path(file).name[:-3]]
(p/'archive_provenance.json').write_bytes((archive/'archive_provenance.json').read_bytes());rawhashes={};final={};budget=0.;rho=math.inf;pressure=math.inf
for name,r in runs.items():
 assert r['status']=='completed' and r['returncode']==0 and r['config']==manifest[name]
 assert summary['runs'][name]==r
 for file,h in r['sha256'].items():
  b=(study/name/file).read_bytes();assert sha(b)==h;(rawhashes.update({name+'/'+file:h}))
  if file=='final.csv':
   rows=[{k:float(v) for k,v in row.items()} for row in csv.DictReader(io.StringIO(b.decode()))];assert all(all(math.isfinite(v) for v in row.values()) for row in rows);assert [int(row['id']) for row in rows]==list(range(r['config']['n']**2));assert all(row['time']==1 for row in rows);final[name]=rows
 s=r['summary'];assert s['profile']=='bulk-frame-hll-projected-v1' and s['time']==1 and s['completed'] and s['limited'] and s['nx']==s['ny']==r['config']['n']
 for h in r['history']:
  d=h['diagnostics'];budget=max(budget,max(abs(x) for x in d['normalized_budget']));rho=min(rho,d['rho_min']);pressure=min(pressure,d['p_min']);assert d['rho_min']>0 and d['p_min']>0 and max(abs(x) for x in d['normalized_budget'])<=1e-10
 assert r['positive_and_conservative']
fields=['rho','p','vx','vy','vz','bx','by','bz','energy'];checks=0;maxnormdiff=0.;pairs=[];seen=[]
for pair in summary['pairs']:
 assert pair['profile']=='bulk-frame-hll-projected-v1' and pair['pairing_valid'] and pair['positive_and_conservative'];seen+=pair['names'];left,right=[final[n] for n in pair['names']];assert len(left)==len(right);differences={k:[] for k in fields+['B','v']};position=0.;volume=0.;weights=[]
 for a,b in zip(left,right):
  assert a['id']==b['id'];weights.append(a['volume']);dv=[b[k]-shift-a[k] for k,shift in zip(['vx','vy','vz'],[2,-1,0])];dB=[b[k]-a[k] for k in ['bx','by','bz']];de=b['energy']-b['rho']*(2*b['vx']-b['vy'])+2.5*b['rho']-a['energy'];v={k:b[k]-a[k] for k in fields};v.update(vx=dv[0],vy=dv[1],vz=dv[2],energy=de,B=math.sqrt(sum(x*x for x in dB)),v=math.sqrt(sum(x*x for x in dv)))
  for k in differences:differences[k].append(v[k])
  position=max(position,abs((b['x']-a['x']-2+.5)%1-.5),abs((b['y']-a['y']+1+.5)%1-.5));volume=max(volume,abs(a['volume']-b['volume'])/a['volume'])
 assert position<=1e-11 and volume<=1e-11;total=math.fsum(weights);norms={k:{'L1':math.fsum(w*abs(x) for w,x in zip(weights,d))/total,'L2':math.sqrt(math.fsum(w*x*x for w,x in zip(weights,d))/total),'max':max(abs(x) for x in d)} for k,d in differences.items()}
 for k,ns in norms.items():
  for kind,value in ns.items():
   diff=abs(value-pair['errors'][k][kind]);maxnormdiff=max(maxnormdiff,diff);checks+=1;assert diff<=3e-14,(pair['names'],k,kind,value,pair['errors'][k][kind])
 if pair['case']=='alfven':
  scales={'rho':1,'p':.1,'energy':.66+.5*pair['parallel']**2,'B':.1,'v':.1};rel={k:norms[k]['L1']/scale for k,scale in scales.items()};maxerr=max(rel.values());assert maxerr<=1e-8 and pair['acceptance_status']=='pass' and pair['primary_normalization']=='wave_amplitude';pairs.append(dict(case=pair['case'],names=pair['names'],maximum_primary_L1=maxerr,relative=rel,position_max=position,volume_relative_max=volume))
 else:
  assert pair['case']=='loop';rel=norms['B']['L1']/(.001/math.sqrt(4*math.pi));assert rel<=.001 and pair['status']=='pass';pairs.append(dict(case='loop',names=pair['names'],relative_B_L1=rel,position_max=position,volume_relative_max=volume))
assert len(summary['pairs'])==24 and len(seen)==len(set(seen))==48 and set(seen)==set(runs)
actual={(v['case'],v['n'],v['jitter'],v['parallel'],v['motion']) for v in summary['pairs']};expected={('alfven',n,j,v,m) for n,j,v,m in itertools.product([32,64],[0,.15],[0,1],['fixed','comoving'])}|{('loop',n,j,0,m) for n,j,m in itertools.product([32,64],[0,.15],['fixed','comoving'])};assert actual==expected
assert summary['temporal']=='unexecuted' and all(x['gate'].startswith('unexecuted') for x in summary['alfven_convergence']);assert summary['kinematic_loop'].startswith('unexecuted')
wave=[x for x in pairs if x['case']=='alfven'];loop=[x for x in pairs if x['case']=='loop'];result=dict(label='Separate AI evidence review; bounded N32/64 quick subset only',revision=prov['revision'],metadata_sha256={k:sha(b) for k,b in metadata.items()},archive_provenance_sha256=sha((archive/'archive_provenance.json').read_bytes()),source_hashes_verified=len(prov['source_sha256']),raw_hashes_verified=len(rawhashes),compressed_and_uncompressed_artifacts_verified=len(archive_meta['archive_sha256']),completed_runs=48,wave_passes=len(wave),loop_passes=len(loop),independent_norm_checks=checks,max_absolute_norm_difference=maxnormdiff,wave_max_primary=max(x['maximum_primary_L1'] for x in wave),loop_max_relative_B=max(x['relative_B_L1'] for x in loop),normalized_budget_max=budget,rho_min=rho,p_min=pressure,pairs=pairs,raw_sha256=rawhashes,verdict='Approve bounded subset reporting; full spatial/temporal/prescribed-flow/remaining candidate gates are not accepted')
(p/'review.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:result[k] for k in ['completed_runs','source_hashes_verified','raw_hashes_verified','wave_passes','loop_passes','independent_norm_checks','max_absolute_norm_difference','wave_max_primary','loop_max_relative_B','normalized_budget_max']},indent=2))
