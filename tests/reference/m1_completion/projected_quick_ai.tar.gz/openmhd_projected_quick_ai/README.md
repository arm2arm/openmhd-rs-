# Separate AI evidence review — projected N32/64 quick subset

Execution revision `fb8bb14bf362a9eb42c2f32d6ec8c1252482790d`. The review approves reporting this bounded subset, not full M1 acceptance.

Independent checks verify39 committed source hashes, the frozen binary and mesh caches,336 raw artifact digests, the execution metadata seals, and4 compressed/uncompressed archive metadata artifacts. All48 expected cases complete; the24 pairs cover exactly the prescribed N32/N64, regular/jitter, travelling/standing and fixed/comoving combinations, with each run used once.

792 independently recomputed scalar/vector boost norms agree with recorded values within5.63e-25 absolute. Velocity and energy are transformed back to the base frame; paired IDs, times, periodic positions and volumes are checked. All16 wave pairs pass the registered wave-amplitude normalization, maximum9.09213358e-11. All8 coupled-loop pairs pass, maximum relative B L1=1.27328027e-7. The loop result is a bounded pass, not described as roundoff-level. All runs remain positive; maximum recorded normalized budget is5.36621e-14.

The full spatial ladders, temporal gate and prescribed-flow packet are correctly retained as unexecuted by this quick runner. No subset result substitutes for those gates or for the old failed profiles. `review.py` performs the read-only independent audit; `review.json` contains measurements and the full raw hash inventory. Captured execution and archive metadata are included. An initial local reporting-variable error occurred after checks; its traceback is preserved, and the corrected complete audit is recorded in `review.txt`. No solver evolution was run here.
