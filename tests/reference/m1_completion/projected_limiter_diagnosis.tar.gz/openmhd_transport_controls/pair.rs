pub fn control_pair() {
    let args: Vec<String> = std::env::args().collect();
    let n: usize = args[1].parse().unwrap();
    let dt: f64 = args[2].parse().unwrap();
    let jitter: f64 = args[3].parse().unwrap();
    let parallel: f64 = args[4].parse().unwrap();
    let boost = [2., -1., 0.];
    let mesh = Mesh::lattice(n,n,[1.;2],jitter).unwrap();
    let make = |b: Vec3| {
        let config = Config {profile: Profile::BulkFrameHllCompactV1,
            mean_magnetic:[1.,0.,0.], motion: Motion::Rigid([b[0],b[1]]),
            max_dt:dt, limited:true, ..Config::default()};
        Simulation::new(mesh.clone(),config,|p|{
            let x=2.*PI*p[0];
            Initial {density:1.,pressure:0.1,
                velocity:[parallel+b[0],0.1*x.sin()+b[1],0.1*x.cos()+b[2]],
                potential:[0.,0.1/(2.*PI)*x.sin(),0.1/(2.*PI)*x.cos()],phi:0.}
        }).unwrap()
    };
    let mut a=make([0.;3]); let mut b=make(boost);
    for t in [0.,0.25,1.] {
        a.advance_to(t).unwrap(); b.advance_to(t).unwrap();
        let qa=a.primitives().unwrap(); let qb=b.primitives().unwrap();
        let mut e=[0_f64;5]; let mut exact=[0_f64;2];
        for (i,(l,r)) in qa.iter().zip(&qb).enumerate() {
            let v=a.state.mesh.cells[i].volume;
            e[0]+=v*(l.density-r.density).abs();
            e[1]+=v*(l.pressure-r.pressure).abs()/0.1;
            e[2]+=v*(0..3).map(|k|(l.velocity[k]-(r.velocity[k]-boost[k])).powi(2)).sum::<f64>().sqrt()/0.1;
            e[3]+=v*(0..3).map(|k|(l.magnetic[k]-r.magnetic[k]).powi(2)).sum::<f64>().sqrt()/0.1;
            let ub=b.state.conserved[i];
            let eb=ub[4]-(0..3).map(|k|boost[k]*ub[k+1]).sum::<f64>()+0.5*ub[0]*boost.iter().map(|x|x*x).sum::<f64>();
            e[4]+=(a.state.conserved[i][4]-eb).abs()/(0.66+0.5*parallel*parallel);
            let x=2.*PI*(a.state.mesh.cells[i].centroid[0]+(1.-parallel)*t);
            let target_b=[1.,0.1*x.sin(),0.1*x.cos()];
            let target_v=[parallel,0.1*x.sin(),0.1*x.cos()];
            exact[0]+=v*(0..3).map(|k|(l.magnetic[k]-target_b[k]).powi(2)).sum::<f64>().sqrt();
            exact[1]+=v*(0..3).map(|k|(l.velocity[k]-target_v[k]).powi(2)).sum::<f64>().sqrt();
        }
        let budget=|s:&Simulation|{let mut sum=[0_f64;5];for q in &s.state.conserved{for k in 0..5{sum[k]+=q[k];}}(0..5).map(|k|(sum[k]-s.initial_totals[k]).abs()/s.budget_scales[k]).fold(0.,f64::max)};
        let c=&a.counters; let d=&b.counters;
        let minrho=qa.iter().chain(&qb).map(|q|q.density).fold(f64::INFINITY,f64::min);
        let minp=qa.iter().chain(&qb).map(|q|q.pressure).fold(f64::INFINITY,f64::min);
        println!("{{\"n\":{n},\"dt\":{dt},\"jitter\":{jitter},\"parallel\":{parallel},\"time\":{t},\"normalized_boost_l1\":{e:?},\"exact_b_v_l1\":{exact:?},\"steps\":[{},{}],\"rejected_cfl\":[{},{}],\"rejected_state\":[{},{}],\"max_budget\":{},\"min_rho\":{minrho},\"min_p\":{minp}}}",c.steps,d.steps,c.rejected_cfl,d.rejected_cfl,c.rejected_state,d.rejected_state,budget(&a).max(budget(&b)));
    }
}
