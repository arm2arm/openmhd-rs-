fn trace_fit(s:&Simulation)->MagneticFit{s.magnetic_fit().unwrap()}
fn trace_factors(s:&Simulation)->Vec<Vec<f64>> {
    let d=&s.geometry.neighbours;let q=s.geometry.quadratic.as_ref().unwrap();let c=s.geometry.compact.as_ref().unwrap();
    (0..3).map(|k|{
        let a:Vec<_>=s.state.potential.iter().map(|a|a[k]).collect();
        let jets=c.jets(d,q,&a).unwrap();
        s.state.mesh.reconstruction().unwrap().quadratic_factors(&a,&jets.iter().map(|j|j.gradient).collect::<Vec<_>>(),&jets.iter().map(|j|j.hessian).collect::<Vec<_>>()).unwrap()
    }).collect()
}
pub fn trace_pair(){
    let n=32; let dt=0.0002; let boost=[2.,-1.,0.];
    let mesh=Mesh::lattice(n,n,[1.;2],0.).unwrap();
    let make=|b:Vec3|Simulation::new(mesh.clone(),Config{profile:Profile::BulkFrameHllCompactV1,mean_magnetic:[1.,0.,0.],motion:Motion::Rigid([b[0],b[1]]),max_dt:dt,..Config::default()},|p|{let x=2.*PI*p[0];Initial{density:1.,pressure:0.1,velocity:[1.+b[0],0.1*x.sin()+b[1],0.1*x.cos()+b[2]],potential:[0.,0.1/(2.*PI)*x.sin(),0.1/(2.*PI)*x.cos()],phi:0.}}).unwrap();
    let mut a=make([0.;3]);let mut b=make(boost); let mut t=0.;
    for step in 0..1251 {
        let fa=trace_factors(&a);let fb=trace_factors(&b);
        let mut worst=(0_f64,0,0);
        for k in 0..3{for i in 0..n*n{let diff=(fa[k][i]-fb[k][i]).abs();if diff>worst.0{worst=(diff,k,i);}}}
        let pa=a.prepare(&mut 0).unwrap();let pb=b.prepare(&mut 0).unwrap();
        let rate=pa.potential_rate.iter().zip(&pb.potential_rate).flat_map(|(a,b)|a.iter().zip(b).map(|(a,b)|(a-b).abs())).fold(0.,f64::max);
        let values=a.state.potential.iter().zip(&b.state.potential).flat_map(|(a,b)|a.iter().zip(b).map(|(a,b)|(a-b).abs())).fold(0.,f64::max);
        if step%25==0||worst.0>0.01{println!("step {step} t {t:.17e} factor {worst:?} Amax {values:.17e} Rmax {rate:.17e}");}
        if worst.0>0.01 && rate>1e-10 {
            let (_,k,i)=worst;
            for (name,s) in [("base",&a),("boost",&b)] {
                let values:Vec<_>=s.state.potential.iter().map(|a|a[k]).collect();
                let jets=s.geometry.compact.as_ref().unwrap().jets(&s.geometry.neighbours,s.geometry.quadratic.as_ref().unwrap(),&values).unwrap();let j=&jets[i];
                let mesh=&s.state.mesh;
                let high=mesh.cells[i].faces.iter().map(|(f,_)|values[mesh.neighbour(&mesh.faces[*f],i).0]).fold(values[i],f64::max);
                let low=mesh.cells[i].faces.iter().map(|(f,_)|values[mesh.neighbour(&mesh.faces[*f],i).0]).fold(values[i],f64::min);
                println!("{name} A {:.17e} high_delta {:.17e} low_delta {:.17e} gradient {:?} hessian {:?}",values[i],high-values[i],low-values[i],j.gradient,j.hessian);
                for (f,_) in &mesh.cells[i].faces{let d=mesh.displacement(&mesh.faces[*f],i);let g=dot(j.gradient,d);let h=moving_mesh::quadratic::term(j.hessian,d);println!("{name} face {f} d{d:?} linear{g:.17e} quad{h:.17e} total{:.17e}",g+h);}
            }
            return;
        }
        t+=dt;a.advance_to(t).unwrap();b.advance_to(t).unwrap();
    }
}
