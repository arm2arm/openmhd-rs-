# Transport/limiter isolation controls, registered before evaluation

These are root-agent diagnostics, not independent AI review or a proposed production profile. Start from numerical sources frozen at aae382e. Keep all original failed results and acceptance thresholds. The production solver is untouched.

Compare the same finite-amplitude standing Alfvén wave in the base frame and a joint fluid/mesh boost (2,-1,0), using compact reconstruction. First run N16 and N32 regular grids to t=.25 and t=1 with fixed max_dt=.0002. Record actual step/rejection counters, primitive boost differences, exact-wave errors and normalized conserved budgets. Test separate removal of primitive limiting, A limiting, both, and baseline. Unlimited controls are mechanism isolation only, not admissible replacements for shock reconstruction.

If useful, compare full two-wave HLL conservative and induction fluxes, retaining the original SL/SR outer bounds, supersonic upwind branch and symmetric A completion. A separate symmetric-fan control uses SL=-alpha, SR=alpha, alpha=max(abs(SL),abs(SR)). These are controls for stationary-characteristic dissipation and consistency between fluid and A transport, not claims of a cure. No gate is relaxed and no full expensive acceptance matrix is authorized by these diagnostics.

build.py embeds the frozen auxiliary/gauge/operators/general source with explicit diagnostic substitutions, and compiles a local mhd-core library. Every command/source/library/binary hash is recorded. Compiled binaries can be omitted from the final archive with hashes retained. pair.rs is the added measurement harness.

## Completed controls and limits

N16 all four limiter controls remain at roundoff. N32 fixed-cap controls give final primary maximum normalized boost L1: baseline7.99254745e-6; primitive limiter disabled6.81164805e-7; A limiter disabled2.29082928e-13; both disabled7.03129550e-14; full HLL2.04868344e-7; symmetric fan2.66545057e-7. No control has a CFL/state rejection. Disabling A limiting is a mechanism isolation, not an accepted shock algorithm; neither flux replacement meets the1e-8 gate.

trace/ captures the developing common-factor amplification at step53, t=.0106. A flat transverse minimum in Ax has a negative transverse polynomial increment, forcing the base factor0; a perturbed transverse bound permits the boosted factor.36275084. The finite x reconstruction consequently differs much more than the potential perturbation. The separate AI evidence distinguishes this conditioning example from a genuine zero-transverse-limit discontinuity.
