from pathlib import Path
import hashlib,json,subprocess,sys
out=Path(__file__).resolve().parent
repo=out.parents[2]
frozen='aae382e957e2d3e2d8534c908e550039ad815fd2'
deps=Path('/tmp/openmhd-m1-compact/target/release/deps')
rustc='/Users/arm2arm/.cargo/bin/rustc'
mode=sys.argv[1]
assert mode in ('baseline','no_primitive','no_a','unlimited','hll','rusanov')
dest=out/mode;dest.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={}
def source(path):
    data=subprocess.check_output(['git','show',f'{frozen}:{path}'],cwd=repo)
    sources[path]=hashlib.sha256(data).hexdigest()
    return data.decode()
core=source('crates/mhd-core/src/lib.rs')
if mode in ('hll','rusanov'):
    old='hlld(eos, l, r, [sl, sr], [pl, pr])'
    assert core.count(old)==1
    core=core.replace(old,'None::<(State, State)>')
if mode=='rusanov':
    old='let sr = lq.velocity[0].max(rq.velocity[0]) + cf;'
    core=core.replace(old,old+'\n    let alpha = sl.abs().max(sr.abs());\n    let sl = -alpha;\n    let sr = alpha;')
(dest/'core.rs').write_text(core)
commands=[]
def run(cmd):
    commands.append(cmd)
    subprocess.run(cmd,cwd=repo,check=True)
run([rustc,'--edition=2024','-Awarnings','-O','--crate-name','mhd_core','--crate-type','rlib',str(dest/'core.rs'),'-o',str(dest/'libmhd_core.rlib')])
text=''
for name in ('auxiliary','gauge','operators','general'):
    code=source(f'crates/mhd-vector-pot/src/{name}.rs').replace('//!','//')
    if name=='operators':
        if mode in ('no_primitive','unlimited'):
            old=') -> Result<Vec<[Vec2; N]>, String> {\n'
            assert code.count(old)==1
            code=code.replace(old,old+'    let limited = false;\n')
        if mode in ('no_a','unlimited'):
            old='        let (stencil, quadratic, compact, consistent, matched) = stencils;'
            assert code.count(old)==1
            code=code.replace(old,'        let limited = false;\n'+old)
    if name=='general':code+='\n'+(out/'pair.rs').read_text()
    text+='mod '+name+' {\n'+code+'\n}\n'
text+='fn main(){general::control_pair()}\n'
(dest/'probe.rs').write_text(text)
mesh=next(deps.glob('libmoving_mesh-*.rlib'))
run([rustc,'--edition=2024','-Awarnings','-O',str(dest/'probe.rs'),'-L','dependency='+str(deps),'--extern','mhd_core='+str(dest/'libmhd_core.rlib'),'--extern','moving_mesh='+str(mesh),'-o',str(dest/'probe')])
manifest={'scope':'Diagnostic only; not a production profile or acceptance run','frozen_revision':frozen,'mode':mode,'commands':commands,'frozen_sources':sources,'mesh_library':{'path':str(mesh),'sha256':sha(mesh)},'artifacts':{p.name:sha(p) for p in dest.iterdir() if p.is_file()},'build_script_sha256':sha(Path(__file__)),'harness_sha256':sha(out/'pair.rs'),'rustc':subprocess.check_output([rustc,'--version','--verbose'],text=True)}
(dest/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(mode+' built')
