from pathlib import Path
import hashlib,json,subprocess
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');out=Path(__file__).resolve().parent;old=out.parent/'openmhd_standing_ai';frozen=Path('/tmp/openmhd-m1-compact');deps=frozen/'target/release/deps';text=''
base=(old/'full_probe_extra.rs').read_text().split('fn review_unboost')[0]
for name in ['auxiliary','gauge','operators','general']:
 code=(out/(name+'_frozen.rs')).read_text().replace('//!','//')
 if name=='general':code+='\n'+base+'\n'+(out/'directional_extra.rs').read_text()
 text+='mod '+name+' {\n'+code+'\n}\n'
text+='fn main(){general::review_directional("'+str(old)+'","'+str(out)+'");}\n';(out/'directional.rs').write_text(text);cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-Awarnings','-O',str(out/'directional.rs'),'-L','dependency='+str(deps)]
for name in ['moving_mesh','mhd_core']:cmd+=['--extern',name+'='+str(next(deps.glob('lib'+name+'-*.rlib')))]
cmd+=['-o',str(out/'directional')];subprocess.run(cmd,cwd=frozen,check=True)
with (out/'run.txt').open('w') as f:subprocess.run([str(out/'directional')],stdout=f,stderr=subprocess.STDOUT,check=True)
p=json.loads((out/'provenance.json').read_text());p.update(compile_command=cmd,run_command=[str(out/'directional')],binary_sha256=hashlib.sha256((out/'directional').read_bytes()).hexdigest(),rustc=subprocess.check_output(['/Users/arm2arm/.cargo/bin/rustc','-Vv'],cwd=frozen,text=True));(out/'provenance.json').write_text(json.dumps(p,indent=2)+'\n')
