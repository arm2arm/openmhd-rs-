"""Independently recompute directional summary statistics from saved component responses."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
root=Path(__file__).resolve().parents[3]
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'directional.csv').open()))
assert len(rows)==48
norm=np.linalg.norm
records=[];maximum=0.;checks=0
for r in rows:
    amplitude=float(r['amplitude'])
    candidates=list(p.glob(f"response_v{r['parallel']}_limited{r['limited']}_{r['mode']}_e*.csv"))
    file=next(f for f in candidates if float(f.stem.split('_e')[-1])==amplitude)
    a=np.genfromtxt(file,delimiter=',',names=True)
    assert len(a)==576 and np.array_equal(a['coordinate'],np.arange(576))
    v=a['mode']; pr=a['predicted_rate']; ps=a['predicted_step']; rp=a['plus_rate']; rm=a['minus_rate']; sp=a['plus_step']; sm=a['minus_step']; rs=.5*(rp+rm); ss=.5*(sp+sm)
    dt=1e-4; rn=max(norm(pr),1e-30); inc=(ps-v)/dt; incn=max(norm(inc),1e-30); vn=norm(v)
    values={
      'predicted_rate_projection':v@pr/(v@v), 'rate_plus_projection':v@rp/(v@v), 'rate_minus_projection':v@rm/(v@v), 'rate_symmetric_projection':v@rs/(v@v),
      'rate_plus_relative_mismatch':norm(rp-pr)/rn, 'rate_minus_relative_mismatch':norm(rm-pr)/rn, 'rate_symmetric_relative_mismatch':norm(rs-pr)/rn,
      'rate_onesided_disagreement':norm(rp-rm)/rn,
      'predicted_step_gain':norm(ps)/vn, 'step_plus_gain':norm(sp)/vn, 'step_minus_gain':norm(sm)/vn, 'step_symmetric_gain':norm(ss)/vn,
      'step_plus_increment_mismatch':norm((sp-v)/dt-inc)/incn, 'step_minus_increment_mismatch':norm((sm-v)/dt-inc)/incn, 'step_symmetric_increment_mismatch':norm((ss-v)/dt-inc)/incn,
      'step_onesided_increment_disagreement':norm((sp-sm)/dt)/incn}
    for k,value in values.items():
      expected=float(r[k]);difference=abs(value-expected)/max(1.,abs(value),abs(expected));maximum=max(maximum,difference);checks+=1
      assert difference<2e-8,(file,k,value,expected,difference)
    r2=dict(r);r2['response_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
    r2['directional_rate_disagreement_by_field']={name:float(norm((rp-rm)[i*64:(i+1)*64])) for i,name in enumerate(['rho','mx','my','mz','E','Ax','Ay','Az','phi'])}
    r2['absolute_rate_symmetric_mismatch']=float(norm(rs-pr))
    r2['absolute_step_symmetric_increment_mismatch']=float(norm((ss-v)/dt-inc))
    records.append(r2)
selected=[r for r in records if float(r['amplitude'])==1e-7]
out={'scope':'Independent summary recomputation; Euclidean combined state norms are diagnostic, not physical benchmark gates. Physical norms are recovered by the Rust probe.','rows':48,'scalar_checks':checks,'maximum_scaled_discrepancy':maximum,'selected_amplitude_1e_7':selected,'all_rows':records}
(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
lines=[f'{checks} independent scalar checks; maximum scaled discrepancy {maximum:.4e}']
for r in selected:
 lines.append(f"v{r['parallel']} limited={r['limited']} {r['mode']}: projection={float(r['rate_symmetric_projection']):.9g} (matrix {float(r['predicted_rate_projection']):.9g}); step={float(r['step_plus_gain']):.12g}/{float(r['step_minus_gain']):.12g} (matrix {float(r['predicted_step_gain']):.12g}); symmetric rate relative mismatch={float(r['rate_symmetric_relative_mismatch']):.6g}; B/v gains={float(r['plus_B_gain']):.12g}/{float(r['plus_v_gain']):.12g}")
(p/'analysis.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
