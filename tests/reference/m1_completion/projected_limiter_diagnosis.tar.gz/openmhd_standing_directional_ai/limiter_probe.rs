use moving_mesh::{Mesh,Derivatives};
use moving_mesh::quadratic::{Quadratic,Compact,term};
fn main(){
for n in [8,16,32] {let mesh=Mesh::lattice(n,n,[1.;2],0.).unwrap();let i=n/2+n*(n/2);let x0=mesh.cells[i].centroid[0];let linear=Derivatives::build(&mesh,false).unwrap();let q=Quadratic::build(&mesh).unwrap();let c=Compact::build(&mesh,&linear).unwrap();
for frequency in [1.,4.] {let values:Vec<_>=mesh.cells.iter().map(|x|(std::f64::consts::TAU*frequency*(x.centroid[0]-x0)).cos()).collect();let j=c.jets(&linear,&q,&values).unwrap();let grad:Vec<_>=j.iter().map(|v|v.gradient).collect();let h:Vec<_>=j.iter().map(|v|v.hessian).collect();let f=mesh.reconstruction().unwrap().quadratic_factors(&values,&grad,&h).unwrap();println!("COS n{n} k{frequency} index{i} g{:?} H{:?} factor{}",grad[i],h[i],f[i]);for &(fi,_) in &mesh.cells[i].faces{let d=mesh.displacement(&mesh.faces[fi],i);let change=grad[i][0]*d[0]+grad[i][1]*d[1]+term(h[i],d);println!("FACE d{:?} increment{change:.17e}",d);}}
// Exact local quadratic jets: arbitrary finite valid inputs to the actual limiter API.
let dx=|x:f64|{let d=x-x0;d-d.round()};let values:Vec<_>=mesh.cells.iter().map(|x|-dx(x.centroid[0]).powi(2)).collect();let gradients:Vec<_>=mesh.cells.iter().map(|x|[-2.*dx(x.centroid[0]),0.]).collect();let mut h=vec![[-2.,0.,0.];n*n];
for epsilon in [0.,-1e-8,1e-8,1e-12,1e-16,1e-20,1e-100] {h[i][1]=epsilon;let f=mesh.reconstruction().unwrap().quadratic_factors(&values,&gradients,&h).unwrap();println!("JET n{n} epsilon{epsilon:.17e} factor{} limitedHxx{:.17e}",f[i],-2.*f[i]);}
}}
