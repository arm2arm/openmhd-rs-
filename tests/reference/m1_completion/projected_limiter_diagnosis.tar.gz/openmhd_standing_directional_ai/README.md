# AI review: actual directional and quadratic-limiter diagnostics

Scientific implementation: `aae382e957e2d3e2d8534c908e550039ad815fd2`.
This is a separate AI numerical review. No production solver/profile files were changed. Earlier evidence in `../openmhd_standing_ai` is untouched. These are small deterministic diagnostics, not benchmark replacements or M1 acceptance.

## Actual directional result

The 48 cases use the exact frozen finite-amplitude N8 circular-wave initialization, parallel velocity 0 or 1, limited/unlimited reconstruction, the previously extracted rate or endpoint eigenvector, and amplitudes 1e-4 through 1e-9 of both signs. Each perturbed state uses actual `prepare` and one actual endpoint step at dt=1e-4. The nine-variable state ordering is density, three momentum densities, energy density, three reduced A components, phi; all perturbation directions are normalized to max component 1. Reference velocity and fixed geometry remain those of the background.

`directional.csv` and 48 `response_*.csv` preserve every component response. `analyze.py` independently recomputes 768 summary scalars: maximum scaled difference 3.73e-15. The source records physical volume-weighted RMS density/pressure/vector-velocity/vector-B perturbations separately. Combined Euclidean state norms mix variables and are only local diagnostics, not registered physical error norms.

For parallel velocity 1 with limiting, the old rate-mode matrix projection 6.587398 becomes an actual symmetric directional projection 1.372254. Its symmetric vector mismatch remains about 90.2%. The old endpoint-mode gain 1.000711390 becomes actual +/- gain about 1.000210470; symmetric rate mismatch is 79.9%. These disagreements persist as amplitude decreases. Opposite one-sided vector derivatives disagree even though their projections happen to agree closely. The coordinate-difference matrices therefore do not represent a single Frechet Jacobian on these directions, and their positive eigenvalues must not be reported as validated physical eigenmodes.

There is still real bounded one-step amplification in the parallel-1 limited endpoint direction: B perturbation RMS gain about 1.00043095 and velocity about 1.00020469. This is not a proof of persistent exponential instability: the background is not an exact discrete equilibrium, the next perturbation direction changes, and a nonnormal stable system can have transient growth. Parallel-0 limited controls make the limitation especially clear: the matrix predicts gain 1.00041322 while the actual extracted direction has combined gain .99996783. Unlimited controls agree much more closely in absolute terms; relative errors for near-neutral modes are ill-conditioned and should not be overinterpreted.

## Independently reproduced limiter defect

`limiter_probe.rs` links the frozen moving-mesh library and uses its actual Compact fit and quadratic limiter. Exactly row-constant cosine data, with its maximum at a cell center, produces nonzero transverse Hessian:

| N | Hxx | Hyy | common limiter factor |
|---|---:|---:|---:|
| 8 | -31.38996311 | 1.220073780 | 0 |
| 16 | -37.32551564 | .3296327436 | 0 |
| 32 | -38.93167198 | .08401475110 | 0 |

True transverse derivatives vanish. The broad free-intercept quadratic fit has higher-order transverse contamination (Hyy is approximately O(h^2), face increment O(h^4)). At N32, both x-face increments are admissible negative values about -.00475240, but the transverse increments +1.02557e-5 violate the zero upper margin and set the common factor to zero. This is deterministic fit contamination, not roundoff.

A separate exact-local-quadratic-jet API test isolates a genuine mathematical discontinuity: values -dx^2, raw Hxx=-2, zero gradient at the target maximum, and Hyy=0 or negative give factor 1; every positive Hyy tested down to 1e-100 gives factor 0. The finite valid x curvature is suppressed by an arbitrarily small transverse perturbation. This test directly supplies analytically valid finite jets to the limiter API; it does not claim each supplied perturbed jet was reconstructed from a perturbed scalar field. A corresponding finite reconstruction jump is O(h^2), with potentially O(h) point-transport-rate effect.

The captured root evolution trace at step53, t=.0106, is independently checked arithmetically in `root_trace_arithmetic.json`: base theta=0; boosted theta=.3627508374. A transverse bound change 2.89419e-10 permits finite x-face increments about 4.28e-7 and 5.73e-7. At that specific evolved state Hyy is already nonzero, so this is severe conditioning, not necessarily a mathematical discontinuity at that precise state. The independent cosine/jet controls and the root evolution trace support continuity-focused limiter investigation. They do not establish that every failed M1 gate shares one cause.

## Reproduce and provenance

All generated probe inputs were hash-verified against the old immutable diagnostics and frozen revision. `provenance.json` contains those hashes, exact compilation/run commands, Rust version and binary hash. `limiter_provenance.json` contains the second probe commands and library/source/binary hashes. Scientific source copies are included; external frozen rlibs are identified by hashes. To regenerate with the already built frozen checkout:

```sh
/Users/arm2arm/.venvs/openmhd-plot/bin/python results/review_resume/openmhd_standing_directional_ai/build_run.py
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python results/review_resume/openmhd_standing_directional_ai/analyze.py
```

The limiter compilation/run argv are in `limiter_provenance.json`. Do not overwrite this completed evidence when testing a new implementation. The two compiled binaries can be omitted from a source/data archive if their hashes remain.

## Bounded verdict and next hypothesis

The actual directional check is complete. Retract the interpretation of the old positive coordinate eigenvalues as validated eigenmodes; retain the matrices and this counterevidence. A common scalar limiter couples tiny transverse constraints into finite longitudinal reconstruction changes. The next justified bounded experiment is a continuous projection of dimensionless quadratic jets onto exactly the same incident-face bounds, with a rotation-invariant symmetric-tensor metric, explicit primal/KKT checks and separate profile registration. No projection implementation or physical candidate is included here. M1 remains open; the compact spatial order 1.640159 and two standing boost failures remain failures.
