mod operators {
// 2.5D operators for the reviewed paper-global-v2 endpoint scheme.
// Derivatives are [component][x/y]; physical vectors retain all three components.
use crate::auxiliary::SmoothVelocity;
use mhd_core::{FaceFlux, IdealGas, Primitive, Vec3, cross};
use moving_mesh::{
    Derivatives, Face, Mesh, Vec2, dot,
    quadratic::{Compact, Quadratic},
};

pub type PrimitiveGradient = [Vec2; 8];

pub(crate) fn components(q: Primitive) -> [f64; 8] {
    [
        q.density,
        q.velocity[0],
        q.velocity[1],
        q.velocity[2],
        q.pressure,
        q.magnetic[0],
        q.magnetic[1],
        q.magnetic[2],
    ]
}
pub(crate) fn primitive(q: [f64; 8]) -> Result<Primitive, String> {
    let p = Primitive {
        density: q[0],
        velocity: [q[1], q[2], q[3]],
        pressure: q[4],
        magnetic: [q[5], q[6], q[7]],
    };
    p.validate()?;
    Ok(p)
}
pub(crate) fn gradients<const N: usize>(
    mesh: &Mesh,
    stencil: &Derivatives,
    values: &[[f64; N]],
    limited: bool,
) -> Result<Vec<[Vec2; N]>, String> {
    let mut result = vec![[[0.; 2]; N]; mesh.cells.len()];
    let reconstruction = if limited {
        Some(mesh.reconstruction()?)
    } else {
        None
    };
    for k in 0..N {
        let scalar: Vec<_> = values.iter().map(|v| v[k]).collect();
        let mut grad = stencil.gradient(&scalar)?;
        if let Some(reconstruction) = &reconstruction {
            grad = reconstruction.limit_gradients(&scalar, &grad)?;
        }
        for (out, g) in result.iter_mut().zip(grad) {
            out[k] = g;
        }
    }
    Ok(result)
}

#[derive(Clone, Debug)]
pub struct MagneticFit {
    pub raw: Vec<[Vec2; 3]>,
    pub limited: Vec<[Vec2; 3]>,
    pub magnetic: Vec<Vec3>,
    pub divergence_a: Vec<f64>,
    pub gradient_phi: Vec<Vec2>,
    /// Limited Hessians [component][xx,yy,xy], only for the consistent profile.
    pub curvature: Option<Vec<[[f64; 3]; 3]>>,
}
impl MagneticFit {
    pub fn build(
        mesh: &Mesh,
        potential: &[Vec3],
        phi: &[f64],
        mean: Vec3,
        limited: bool,
    ) -> Result<Self, String> {
        let stencil = Derivatives::build(mesh, false)?;
        Self::with_stencil(
            mesh,
            (&stencil, None, None, false, false),
            potential,
            phi,
            mean,
            limited,
        )
    }
    pub(crate) fn with_stencil(
        mesh: &Mesh,
        stencils: (
            &Derivatives,
            Option<&Quadratic>,
            Option<&Compact>,
            bool,
            bool,
        ),
        potential: &[Vec3],
        phi: &[f64],
        mean: Vec3,
        limited: bool,
    ) -> Result<Self, String> {
        if !mean.iter().all(|x| x.is_finite()) {
            return Err("nonfinite mean field".into());
        }
        let (stencil, quadratic, compact, consistent, matched) = stencils;
        if (consistent || matched || compact.is_some()) && quadratic.is_none() {
            return Err("consistent fit requires quadratic reconstruction".into());
        }
        let mut curvature = if consistent {
            Some(vec![[[0.; 3]; 3]; mesh.cells.len()])
        } else {
            None
        };
        let raw = if let Some(quadratic) = quadratic {
            let mut raw = vec![[[0.; 2]; 3]; mesh.cells.len()];
            for k in 0..3 {
                let values: Vec<_> = potential.iter().map(|a| a[k]).collect();
                for (i, (g, jet)) in raw
                    .iter_mut()
                    .zip(if let Some(c) = compact {
                        c.jets(stencil, quadratic, &values)?
                    } else {
                        quadratic.jets(&values)?
                    })
                    .enumerate()
                {
                    g[k] = jet.gradient;
                    if let Some(h) = &mut curvature {
                        h[i][k] = jet.hessian;
                    }
                }
            }
            raw
        } else {
            gradients(mesh, stencil, potential, false)?
        };
        let extrapolation = if limited && quadratic.is_some() {
            let guard = mesh.reconstruction()?;
            let mut extrapolation = raw.clone();
            for k in 0..3 {
                let values: Vec<_> = potential.iter().map(|a| a[k]).collect();
                let gradient: Vec<_> = raw.iter().map(|g| g[k]).collect();
                if let Some(h) = &mut curvature {
                    let hessian: Vec<_> = h.iter().map(|h| h[k]).collect();
                    let factors = guard.quadratic_factors(&values, &gradient, &hessian)?;
                    for (i, factor) in factors.into_iter().enumerate() {
                        extrapolation[i][k] = gradient[i].map(|v| v * factor);
                        h[i][k] = hessian[i].map(|v| v * factor);
                    }
                } else {
                    for (out, g) in extrapolation
                        .iter_mut()
                        .zip(guard.limit_gradients(&values, &gradient)?)
                    {
                        out[k] = g;
                    }
                }
            }
            extrapolation
        } else if limited {
            gradients(mesh, stencil, potential, true)?
        } else {
            raw.clone()
        };
        let magnetic: Vec<Vec3> = raw
            .iter()
            .map(|g| {
                [
                    mean[0] + g[2][1],
                    mean[1] - g[2][0],
                    mean[2] + g[1][0] - g[0][1],
                ]
            })
            .collect();
        let divergence_a: Vec<f64> = raw.iter().map(|g| g[0][0] + g[1][1]).collect();
        if !magnetic
            .iter()
            .flatten()
            .chain(&divergence_a)
            .all(|x| x.is_finite())
        {
            return Err("curl/divergence arithmetic overflow".into());
        }
        Ok(Self {
            curvature,
            raw,
            limited: extrapolation,
            magnetic,
            divergence_a,
            gradient_phi: if let Some(c) = compact {
                c.jets(
                    stencil,
                    quadratic.ok_or("compact cleaning requires quadratic fit")?,
                    phi,
                )?
                .iter()
                .map(|j| j.gradient)
                .collect()
            } else if matched {
                quadratic
                    .ok_or("matched cleaning requires quadratic reconstruction")?
                    .jets(phi)?
                    .iter()
                    .map(|j| j.gradient)
                    .collect()
            } else {
                stencil.gradient(phi)?
            },
        })
    }
}

/// Solenoidal material predictor (U1): deliberately omits v * estimated div(B).
/// This local algebra assumes validated q/gradients; predictor outputs are checked.
pub fn material_derivative(eos: IdealGas, q: Primitive, g: PrimitiveGradient) -> [f64; 8] {
    let theta = g[1][0] + g[2][1];
    let current = [g[7][1], -g[7][0], g[6][0] - g[5][1]];
    let force = cross(current, q.magnetic);
    let mut rate = [0.; 8];
    rate[0] = -q.density * theta;
    rate[4] = -eos.gamma() * q.pressure * theta;
    for k in 0..3 {
        rate[1 + k] = (force[k] - if k < 2 { g[4][k] } else { 0. }) / q.density;
        rate[5 + k] =
            g[1 + k][0] * q.magnetic[0] + g[1 + k][1] * q.magnetic[1] - q.magnetic[k] * theta;
    }
    rate
}

/// Offset is the *unwrapped* new evaluation point minus the old cell centroid.
pub fn predict(
    eos: IdealGas,
    q: Primitive,
    g: PrimitiveGradient,
    offset: Vec2,
    dt: f64,
) -> Result<Primitive, String> {
    if !dt.is_finite()
        || dt < 0.
        || !offset
            .iter()
            .chain(g.iter().flatten())
            .all(|x| x.is_finite())
    {
        return Err("invalid predictor data".into());
    }
    q.validate()?;
    let material = material_derivative(eos, q, g);
    let displacement = [
        offset[0] - dt * q.velocity[0],
        offset[1] - dt * q.velocity[1],
    ];
    let old = components(q);
    primitive(std::array::from_fn(|k| {
        old[k] + dot(g[k], displacement) + dt * material[k]
    }))
}

/// Differentiated Voronoi bisector speed; mesh must be validated and face incident.
pub fn face_velocity(
    mesh: &Mesh,
    face: &Face,
    generators_velocity: &[Vec2],
) -> Result<Vec3, String> {
    if generators_velocity.len() != mesh.cells.len() {
        return Err("generator velocity length".into());
    }
    let ri = mesh.generators[face.left];
    let rj: Vec2 = std::array::from_fn(|k| {
        mesh.generators[face.right][k] + f64::from(face.image[k]) * mesh.lengths[k]
    });
    let d: Vec2 = std::array::from_fn(|k| rj[k] - ri[k]);
    let f: Vec2 = std::array::from_fn(|k| face.centroid[k] - 0.5 * (ri[k] + rj[k]));
    let wi = generators_velocity[face.left];
    let wj = generators_velocity[face.right];
    let correction = dot([wi[0] - wj[0], wi[1] - wj[1]], f) / dot(d, d);
    let result = [
        0.5 * (wi[0] + wj[0]) + d[0] * correction,
        0.5 * (wi[1] + wj[1]) + d[1] * correction,
        0.,
    ];
    if !result.iter().all(|x| x.is_finite()) {
        return Err("invalid moving bisector velocity".into());
    }
    Ok(result)
}

pub(crate) struct PotentialStage<'a> {
    pub mesh: &'a Mesh,
    pub face_stencil: &'a Derivatives,
    pub potential: &'a [Vec3],
    pub fit: &'a MagneticFit,
    pub faces: &'a [FaceFlux],
    pub auxiliary: &'a SmoothVelocity,
    pub advection_velocity: &'a [Vec2],
    pub mean: Vec3,
    pub reference_velocity: Vec3,
    pub tau: f64,
    pub centered: bool,
}
impl PotentialStage<'_> {
    /// Paper (69)-(72),(76); numerical EMF must not be replaced by a state product.
    pub fn rate(&self) -> Result<Vec<Vec3>, String> {
        self.mesh
            .cells
            .iter()
            .enumerate()
            .map(|(i, cell)| {
                let aux = self.auxiliary.sample(cell.centroid, self.tau)?;
                let b = [
                    self.advection_velocity[i][0] - aux.velocity[0],
                    self.advection_velocity[i][1] - aux.velocity[1],
                ];
                let perimeter: f64 = cell
                    .faces
                    .iter()
                    .map(|(f, _)| self.mesh.faces[*f].area)
                    .sum();
                // BulkFrameV1 changes the gauge, not the lab-frame fluid fluxes.
                // Substituting A=a+C into the original gauge alone would leave
                // -H^T C; its deliberate omission is documented in the profile.
                let mean_source = cross(
                    std::array::from_fn(|k| aux.velocity[k] - self.reference_velocity[k]),
                    self.mean,
                );
                let mut result: Vec3 = std::array::from_fn(|k| {
                    mean_source[k]
                        - (0..3)
                            .map(|a| aux.jacobian[a][k] * self.potential[i][a])
                            .sum::<f64>()
                        + if k < 2 {
                            self.fit.gradient_phi[i][k]
                        } else {
                            0.
                        }
                });
                for &(f, sign) in &cell.faces {
                    let face = &self.faces[f];
                    let geometry = &self.mesh.faces[f];
                    let weight = if self.centered {
                        geometry.area
                            * sign
                            * dot(geometry.normal, self.mesh.displacement(geometry, i))
                            / (2. * cell.volume)
                    } else {
                        geometry.area / perimeter
                    };
                    let ux_b = cross(aux.velocity, face.magnetic);
                    for k in 0..3 {
                        result[k] += weight * (face.electromotive[k] - ux_b[k]);
                    }
                }
                for sample in &self.face_stencil.samples[i] {
                    let face = &self.mesh.faces[sample.index];
                    let displacement = self.mesh.displacement(face, i);
                    let donor = if dot(b, displacement) < 0. {
                        i
                    } else {
                        self.mesh.neighbour(face, i).0
                    };
                    let donor_offset = self.mesh.displacement(face, donor);
                    for (k, r) in result.iter_mut().enumerate() {
                        let up = self.potential[donor][k]
                            + dot(self.fit.limited[donor][k], donor_offset);
                        let correction = if let Some(h) = &self.fit.curvature {
                            moving_mesh::quadratic::term(h[donor][k], donor_offset)
                                - moving_mesh::quadratic::term(h[i][k], displacement)
                        } else {
                            0.
                        };
                        *r += dot(b, sample.weight)
                            * if self.fit.curvature.is_some() {
                                up - self.potential[i][k] + correction
                            } else {
                                up - self.potential[i][k]
                            };
                    }
                }
                if !result.iter().all(|x| x.is_finite()) {
                    return Err("nonfinite potential rate".into());
                }
                Ok(result)
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::auxiliary::VelocitySample;
    use mhd_core::FluxMethod;
    #[test]
    fn compact_limiter_bounds_complete_face_polynomials_and_phi_is_unlimited() {
        let mesh = Mesh::lattice(12, 9, [1.; 2], 0.15).unwrap();
        let linear = Derivatives::build(&mesh, false).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let compact = Compact::build(&mesh, &linear).unwrap();
        let a: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| {
                [
                    (13. * c.centroid[0]).sin(),
                    if c.centroid[0] < 0.5 { 1. } else { -1. },
                    (9. * c.centroid[1]).cos(),
                ]
            })
            .collect();
        let phi: Vec<_> = a.iter().map(|a| a[1]).collect();
        let fit = MagneticFit::with_stencil(
            &mesh,
            (&linear, Some(&quadratic), Some(&compact), true, true),
            &a,
            &phi,
            [0.; 3],
            true,
        )
        .unwrap();
        let exact = compact.jets(&linear, &quadratic, &phi).unwrap();
        for (i, c) in mesh.cells.iter().enumerate() {
            assert_eq!(fit.gradient_phi[i], exact[i].gradient);
            for k in 0..3 {
                let mut lo = a[i][k];
                let mut hi = lo;
                for &(f, _) in &c.faces {
                    let j = mesh.neighbour(&mesh.faces[f], i).0;
                    lo = lo.min(a[j][k]);
                    hi = hi.max(a[j][k]);
                }
                for &(f, _) in &c.faces {
                    let d = mesh.displacement(&mesh.faces[f], i);
                    let value = a[i][k]
                        + dot(fit.limited[i][k], d)
                        + moving_mesh::quadratic::term(fit.curvature.as_ref().unwrap()[i][k], d);
                    assert!(
                        value >= lo - 1e-12 && value <= hi + 1e-12,
                        "{value} [{lo},{hi}]"
                    );
                }
            }
        }
    }
    #[test]
    fn matched_cleaning_removes_the_mixed_derivative_growing_fourier_mode() {
        let mesh = Mesh::lattice(16, 16, [1.; 2], 0.).unwrap();
        let linear = Derivatives::build(&mesh, false).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let phi: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| (std::f64::consts::TAU * (6. * c.centroid[0] + 5. * c.centroid[1])).sin())
            .collect();
        let a = vec![[0.; 3]; phi.len()];
        let mut coefficients = Vec::new();
        for matched in [false, true] {
            let fit = MagneticFit::with_stencil(
                &mesh,
                (&linear, Some(&quadratic), None, true, matched),
                &a,
                &phi,
                [0.; 3],
                false,
            )
            .unwrap();
            let gx: Vec<_> = fit.gradient_phi.iter().map(|g| g[0]).collect();
            let gy: Vec<_> = fit.gradient_phi.iter().map(|g| g[1]).collect();
            let dx = quadratic.jets(&gx).unwrap();
            let dy = quadratic.jets(&gy).unwrap();
            let lap: Vec<_> = dx
                .iter()
                .zip(&dy)
                .map(|(x, y)| x.gradient[0] + y.gradient[1])
                .collect();
            let curl: Vec<_> = dx
                .iter()
                .zip(&dy)
                .map(|(x, y)| y.gradient[0] - x.gradient[1])
                .collect();
            let norm: f64 = phi.iter().map(|p| p * p).sum();
            let coefficient =
                |v: &[f64]| v.iter().zip(&phi).map(|(v, p)| v * p).sum::<f64>() / norm;
            let lambda = coefficient(&lap);
            let curl_lambda = coefficient(&curl);
            assert!(
                lap.iter()
                    .zip(&phi)
                    .all(|(v, p)| (v - lambda * p).abs() < 1e-9)
            );
            assert!(
                curl.iter()
                    .zip(&phi)
                    .all(|(v, p)| (v - curl_lambda * p).abs() < 1e-9)
            );
            coefficients.push((lambda, curl_lambda));
        }
        // This fixture exposes the semidiscrete defect, independently of timestep size.
        assert!(
            coefficients[0].0 > 60. && coefficients[0].1.abs() > 7.,
            "{coefficients:?}"
        );
        assert!(
            coefficients[1].0 < -10. && coefficients[1].1.abs() < 1e-10,
            "{coefficients:?}"
        );
    }
    #[test]
    fn upwind_donors_and_numerical_emf_use_all_components() {
        let mesh = Mesh::lattice(6, 6, [1.; 2], 0.).unwrap();
        let i = 14; // interior (x index 2, y index 2)
        let mut potential = vec![[0.; 3]; 36];
        for (index, value) in [(i, 0.2), (i - 1, -0.1), (i + 1, 0.9)] {
            potential[index] = [value, 2. * value, -3. * value];
        }
        let mut fit = MagneticFit::build(&mesh, &potential, &vec![0.; 36], [0.; 3], false).unwrap();
        fit.limited.fill([[0.; 2]; 3]); // controlled donor fixture, discontinuous data
        fit.gradient_phi.fill([0.13, -0.12]);
        let u = [0.4, -0.2, 0.3];
        let bfield = [0.2, 0.3, 0.4];
        let mean = [0.3, -0.2, 0.1];
        let emf = [0.03, 0.07, 0.09]; // deliberately different from the face state product
        let flux = FaceFlux {
            fluid: [0.; 5],
            induction: [0.; 3],
            electromotive: emf,
            velocity: [0.; 3],
            magnetic: bfield,
            max_speed: 1.,
            method: FluxMethod::HllFallback,
        };
        let fluxes = vec![flux; mesh.faces.len()];
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| VelocitySample {
                position: c.centroid,
                volume: c.volume,
                velocity: u,
            })
            .collect();
        let aux = SmoothVelocity::build([1.; 2], &samples, [0.; 2]).unwrap();
        let faces = Derivatives::build(&mesh, true).unwrap();
        for (speed, delta) in [(0.7, 0.9 - 0.2), (-0.6, 0.2 - (-0.1))] {
            let w = vec![[u[0] + speed, u[1]]; 36];
            let result = PotentialStage {
                mesh: &mesh,
                face_stencil: &faces,
                potential: &potential,
                fit: &fit,
                faces: &fluxes,
                auxiliary: &aux,
                advection_velocity: &w,
                mean,
                reference_velocity: [0.; 3],
                tau: 0.,
                centered: false,
            }
            .rate()
            .unwrap();
            let ux_b = cross(u, bfield);
            let ux_mean = cross(u, mean);
            for (k, multiplier) in [1., 2., -3.].iter().enumerate() {
                let exact = emf[k] - ux_b[k]
                    + ux_mean[k]
                    + if k < 2 { fit.gradient_phi[i][k] } else { 0. }
                    + speed * 6. * delta * multiplier;
                assert!(
                    (result[i][k] - exact).abs() < 1e-11,
                    "{} != {exact}",
                    result[i][k]
                );
            }
        }
    }
    #[test]
    fn complete_consistent_rate_reproduces_quadratic_a_with_affine_face_source() {
        let mesh = Mesh::lattice(12, 12, [1.; 2], 0.15).unwrap();
        let a = |p: Vec2| {
            let [x, y] = p;
            [
                0.2 + 0.3 * x - 0.2 * y + 0.05 * x * x + 0.07 * x * y - 0.04 * y * y,
                -0.1 + 0.2 * x + 0.4 * y - 0.03 * x * x + 0.02 * x * y + 0.06 * y * y,
                0.4 - 0.25 * x + 0.15 * y + 0.08 * x * x - 0.05 * x * y + 0.09 * y * y,
            ]
        };
        let gradient = |p: Vec2| {
            let [x, y] = p;
            [
                [0.3 + 0.1 * x + 0.07 * y, -0.2 + 0.07 * x - 0.08 * y],
                [0.2 - 0.06 * x + 0.02 * y, 0.4 + 0.02 * x + 0.12 * y],
                [-0.25 + 0.16 * x - 0.05 * y, 0.15 - 0.05 * x + 0.18 * y],
            ]
        };
        let bfield = |p: Vec2| {
            let g = gradient(p);
            [g[2][1], -g[2][0], g[1][0] - g[0][1]]
        };
        let v = [0.7, -0.3, 0.2];
        let u = [0.2, 0.1, -0.1];
        let w = [-0.1, 0.4];
        let adv = [w[0] - u[0], w[1] - u[1]];
        let potential: Vec<_> = mesh.cells.iter().map(|c| a(c.centroid)).collect();
        let phi = vec![0.; potential.len()];
        let neighbours = Derivatives::build(&mesh, false).unwrap();
        let faces = Derivatives::build(&mesh, true).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| VelocitySample {
                position: c.centroid,
                volume: c.volume,
                velocity: u,
            })
            .collect();
        let auxiliary = SmoothVelocity::build(mesh.lengths, &samples, [0.; 2]).unwrap();
        let fluxes: Vec<_> = mesh
            .faces
            .iter()
            .map(|f| {
                let b = bfield(f.centroid);
                FaceFlux {
                    fluid: [0.; 5],
                    induction: [0.; 3],
                    electromotive: cross(v, b),
                    velocity: v,
                    magnetic: b,
                    max_speed: 1.,
                    method: FluxMethod::HllFallback,
                }
            })
            .collect();
        let motion = vec![w; potential.len()];
        let mut errors = Vec::new();
        let compact = Compact::build(&mesh, &neighbours).unwrap();
        for (consistent, correction) in [(false, None), (true, None), (true, Some(&compact))] {
            let fit = MagneticFit::with_stencil(
                &mesh,
                (&neighbours, Some(&quadratic), correction, consistent, false),
                &potential,
                &phi,
                [0.; 3],
                false,
            )
            .unwrap();
            let rate = PotentialStage {
                mesh: &mesh,
                face_stencil: &faces,
                potential: &potential,
                fit: &fit,
                faces: &fluxes,
                auxiliary: &auxiliary,
                advection_velocity: &motion,
                mean: [0.; 3],
                reference_velocity: [0.; 3],
                tau: 0.,
                centered: consistent,
            }
            .rate()
            .unwrap();
            let mut worst: f64 = 0.;
            for (i, c) in mesh.cells.iter().enumerate() {
                if !c.centroid.iter().all(|x| (0.3..0.7).contains(x)) {
                    continue;
                }
                let source = cross(std::array::from_fn(|k| v[k] - u[k]), bfield(c.centroid));
                let g = gradient(c.centroid);
                for k in 0..3 {
                    worst = worst.max((rate[i][k] - source[k] - dot(adv, g[k])).abs());
                }
            }
            errors.push(worst);
        }
        assert!(
            errors[0] > 1e-6,
            "uncorrected control unexpectedly exact: {errors:?}"
        );
        assert!(errors[1..].iter().all(|e| *e < 1e-10), "{errors:?}");
    }
    #[test]
    fn live_distortion_transposes_the_full_auxiliary_jacobian() {
        let mesh = Mesh::lattice(8, 8, [1.; 2], 0.15).unwrap();
        let a = [0.2, -0.4, 0.7];
        let potential = vec![a; mesh.cells.len()];
        let fit = MagneticFit::build(&mesh, &potential, &vec![0.; potential.len()], [0.; 3], true)
            .unwrap();
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| {
                let x = std::f64::consts::TAU * c.centroid[0];
                let y = std::f64::consts::TAU * c.centroid[1];
                VelocitySample {
                    position: c.centroid,
                    volume: c.volume,
                    velocity: [
                        0.1 * x.sin() + 0.02 * y.cos(),
                        0.2 * x.cos() + 0.03 * y.sin(),
                        0.07 * x.sin() - 0.04 * y.cos(),
                    ],
                }
            })
            .collect();
        let aux = SmoothVelocity::build(mesh.lengths, &samples, [0.; 2]).unwrap();
        let sampled: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| aux.sample(c.centroid, 0.).unwrap())
            .collect();
        let w: Vec<_> = sampled
            .iter()
            .map(|u| [u.velocity[0], u.velocity[1]])
            .collect();
        let fluxes = vec![
            FaceFlux {
                fluid: [0.; 5],
                induction: [0.; 3],
                electromotive: [0.; 3],
                velocity: [0.; 3],
                magnetic: [0.; 3],
                max_speed: 1.,
                method: FluxMethod::HllFallback
            };
            mesh.faces.len()
        ];
        let stencil = Derivatives::build(&mesh, true).unwrap();
        let rate = PotentialStage {
            mesh: &mesh,
            face_stencil: &stencil,
            potential: &potential,
            fit: &fit,
            faces: &fluxes,
            auxiliary: &aux,
            advection_velocity: &w,
            mean: [0.; 3],
            reference_velocity: [0.; 3],
            tau: 0.,
            centered: false,
        }
        .rate()
        .unwrap();
        let mut z_coupling = 0_f64;
        for (r, u) in rate.iter().zip(sampled) {
            let h = u.jacobian;
            let exact = [
                -0.2 * h[0][0] + 0.4 * h[1][0] - 0.7 * h[2][0],
                -0.2 * h[0][1] + 0.4 * h[1][1] - 0.7 * h[2][1],
                0.,
            ];
            for k in 0..3 {
                assert!((r[k] - exact[k]).abs() < 1e-11);
            }
            z_coupling = z_coupling.max(h[2][0].abs()).max(h[2][1].abs());
        }
        assert!(z_coupling > 0.1);
    }
}

}
mod auxiliary {
// Periodic bicubic reduction of paper Eq. (68), with the explicit v2 origin rule.
use crate::gauge::{Jacobian, Vec3};
use moving_mesh::Vec2;

#[derive(Clone, Copy, Debug, Default)]
pub struct Jet {
    pub value: Vec3,
    pub dx: Vec3,
    pub dy: Vec3,
    pub dxy: Vec3,
}

#[derive(Clone, Copy, Debug)]
pub struct Sample {
    pub velocity: Vec3,
    pub jacobian: Jacobian,
}

/// Tensor Hermite polynomial on a single element; coordinates are in [0,1]^2.
/// Corner layout is [y][x]; derivative jets are in physical length units.
pub fn interpolate(
    corners: &[[Jet; 2]; 2],
    spacing: Vec2,
    coordinate: Vec2,
) -> Result<Sample, String> {
    if !spacing.iter().all(|h| h.is_finite() && *h > 0.0)
        || !coordinate
            .iter()
            .all(|s| s.is_finite() && (0.0..=1.0).contains(s))
        || corners.iter().flatten().any(|j| {
            [j.value, j.dx, j.dy, j.dxy]
                .iter()
                .flatten()
                .any(|v| !v.is_finite())
        })
    {
        return Err("invalid Hermite element or coordinate".into());
    }
    let basis = |s: f64| {
        [
            [
                2.0 * s * s * s - 3.0 * s * s + 1.0,
                s * s * s - 2.0 * s * s + s,
            ],
            [-2.0 * s * s * s + 3.0 * s * s, s * s * s - s * s],
        ]
    };
    let derivative = |s: f64| {
        [
            [6.0 * s * s - 6.0 * s, 3.0 * s * s - 4.0 * s + 1.0],
            [-6.0 * s * s + 6.0 * s, 3.0 * s * s - 2.0 * s],
        ]
    };
    let bx = basis(coordinate[0]);
    let by = basis(coordinate[1]);
    let dx = derivative(coordinate[0]);
    let dy = derivative(coordinate[1]);
    let mut result = Sample {
        velocity: [0.0; 3],
        jacobian: [[0.0; 3]; 3],
    };
    for (y, row) in corners.iter().enumerate() {
        for (x, jet) in row.iter().enumerate() {
            for (px, py, values) in [
                (0, 0, jet.value),
                (1, 0, jet.dx),
                (0, 1, jet.dy),
                (1, 1, jet.dxy),
            ] {
                let scale = (if px == 0 { 1.0 } else { spacing[0] })
                    * (if py == 0 { 1.0 } else { spacing[1] });
                for (k, v) in values.iter().enumerate() {
                    result.velocity[k] += v * scale * bx[x][px] * by[y][py];
                    result.jacobian[k][0] += v * scale * dx[x][px] * by[y][py] / spacing[0];
                    result.jacobian[k][1] += v * scale * bx[x][px] * dy[y][py] / spacing[1];
                }
            }
        }
    }
    if !result
        .velocity
        .iter()
        .chain(result.jacobian.iter().flatten())
        .all(|v| v.is_finite())
    {
        return Err("Hermite evaluation overflow".into());
    }
    Ok(result)
}

#[derive(Clone, Copy, Debug)]
pub struct VelocitySample {
    pub position: Vec2,
    pub volume: f64,
    pub velocity: Vec3,
}

#[derive(Clone, Debug)]
pub struct SmoothVelocity {
    lengths: Vec2,
    origin: Vec2,
    corners: Vec<Jet>,
    intervals: usize,
    pub counts: Vec<usize>,
    pub max_cell_volumes: Vec<f64>,
    pub coarsenings: usize,
    pub mean_velocity: Vec3,
}

fn bin(position: f64, origin: f64, length: f64, intervals: usize) -> usize {
    let mut q = (position - origin).rem_euclid(length) / length * intervals as f64 + 0.5;
    let nearest = q.round();
    if (q - nearest).abs() <= 32.0 * f64::EPSILON * (1.0 + q.abs()) {
        q = nearest;
    }
    (q.floor() as usize) % intervals
}

fn jets(values: &[Vec3], n: usize, spacing: Vec2) -> Vec<Jet> {
    let index = |x: usize, y: usize| (x % n) + n * (y % n);
    let dx: Vec<Vec3> = (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            std::array::from_fn(|k| {
                (values[index(x + 1, y)][k] - values[index(x + n - 1, y)][k]) / (2.0 * spacing[0])
            })
        })
        .collect();
    (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            Jet {
                value: values[i],
                dx: dx[i],
                dy: std::array::from_fn(|k| {
                    (values[index(x, y + 1)][k] - values[index(x, y + n - 1)][k])
                        / (2.0 * spacing[1])
                }),
                dxy: std::array::from_fn(|k| {
                    (dx[index(x, y + 1)][k] - dx[index(x, y + n - 1)][k]) / (2.0 * spacing[1])
                }),
            }
        })
        .collect()
}

impl SmoothVelocity {
    pub fn build(lengths: Vec2, samples: &[VelocitySample], origin: Vec2) -> Result<Self, String> {
        if samples.is_empty()
            || !lengths.iter().all(|v| v.is_finite() && *v > 0.0)
            || !origin.iter().all(|v| v.is_finite())
            || samples.iter().any(|s| {
                !s.volume.is_finite()
                    || s.volume <= 0.0
                    || !s.position.iter().chain(&s.velocity).all(|v| v.is_finite())
                    || (0..2).any(|k| !(s.position[k] - origin[k]).is_finite())
            })
        {
            return Err("invalid auxiliary velocity samples/domain/origin".into());
        }
        let total: f64 = samples.iter().map(|s| s.volume).sum();
        if !total.is_finite() || total <= 0.0 {
            return Err("auxiliary volume overflow".into());
        }
        let mean_velocity: Vec3 = std::array::from_fn(|k| {
            samples
                .iter()
                .map(|s| s.volume / total * s.velocity[k])
                .sum()
        });
        for (coarsenings, n) in [4, 2, 1].into_iter().enumerate() {
            let mut weights = vec![0.0; n * n];
            let mut values = vec![[0.0; 3]; n * n];
            let mut counts = vec![0; n * n];
            let mut max_cell_volumes = vec![0.0_f64; n * n];
            for s in samples {
                let i = bin(s.position[0], origin[0], lengths[0], n)
                    + n * bin(s.position[1], origin[1], lengths[1], n);
                let w = s.volume / total;
                weights[i] += w;
                counts[i] += 1;
                max_cell_volumes[i] = max_cell_volumes[i].max(s.volume);
                for (k, v) in s.velocity.iter().enumerate() {
                    values[i][k] += w * v;
                }
            }
            if counts.contains(&0) {
                continue;
            }
            for (v, w) in values.iter_mut().zip(weights) {
                for component in v {
                    *component /= w;
                }
            }
            let corners = jets(&values, n, lengths.map(|l| l / n as f64));
            if !mean_velocity
                .into_iter()
                .chain(
                    corners
                        .iter()
                        .flat_map(|j| [j.value, j.dx, j.dy, j.dxy])
                        .flatten(),
                )
                .all(|v| v.is_finite())
            {
                return Err("auxiliary averages/jets overflow".into());
            }
            return Ok(Self {
                lengths,
                origin,
                corners,
                intervals: n,
                counts,
                max_cell_volumes,
                coarsenings,
                mean_velocity,
            });
        }
        Err("auxiliary root remained empty".into())
    }

    pub fn intervals(&self) -> usize {
        self.intervals
    }
    pub fn origin(&self) -> Vec2 {
        self.origin
    }

    pub fn sample(&self, position: Vec2, stage_time: f64) -> Result<Sample, String> {
        if !stage_time.is_finite() || stage_time < 0.0 {
            return Err("invalid auxiliary stage time".into());
        }
        let coordinate: Vec2 = std::array::from_fn(|k| {
            position[k] - self.origin[k] - stage_time * self.mean_velocity[k]
        });
        if !coordinate.iter().all(|v| v.is_finite()) {
            return Err("auxiliary coordinate overflow".into());
        }
        let n = self.intervals;
        let spacing = self.lengths.map(|l| l / n as f64);
        let q: Vec2 =
            std::array::from_fn(|k| coordinate[k].rem_euclid(self.lengths[k]) / spacing[k]);
        let cell = q.map(|v| v.floor() as usize);
        let local = std::array::from_fn(|k| (q[k] - cell[k] as f64).clamp(0.0, 1.0));
        let corners = std::array::from_fn(|y| {
            std::array::from_fn(|x| self.corners[(cell[0] + x) % n + n * ((cell[1] + y) % n)])
        });
        interpolate(&corners, spacing, local)
    }

    pub fn advanced_origin(&self, dt: f64) -> Result<Vec2, String> {
        if !dt.is_finite() || dt < 0.0 {
            return Err("invalid origin advance interval".into());
        }
        let origin: Vec2 = std::array::from_fn(|k| self.origin[k] + dt * self.mean_velocity[k]);
        if !origin.iter().all(|v| v.is_finite()) {
            return Err("auxiliary origin overflow".into());
        }
        Ok(std::array::from_fn(|k| {
            origin[k].rem_euclid(self.lengths[k])
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::TAU;

    #[test]
    fn centred_jets_converge_for_periodic_smooth_data() {
        let mut errors = Vec::new();
        for n in [8, 16, 32] {
            let h = 1.0 / n as f64;
            let values: Vec<_> = (0..n * n)
                .map(|i| [(TAU * (i % n) as f64 * h).sin() * (TAU * (i / n) as f64 * h).cos(); 3])
                .collect();
            let field = SmoothVelocity {
                lengths: [1.0; 2],
                origin: [0.0; 2],
                corners: jets(&values, n, [h; 2]),
                intervals: n,
                counts: vec![1; n * n],
                max_cell_volumes: vec![h * h; n * n],
                coarsenings: 0,
                mean_velocity: [0.0; 3],
            };
            let error: f64 = (0..n * n)
                .map(|i| {
                    let p = [((i % n) as f64 + 0.37) * h, ((i / n) as f64 + 0.63) * h];
                    let g = field.sample(p, 0.0).unwrap().jacobian[0];
                    (g[0] - TAU * (TAU * p[0]).cos() * (TAU * p[1]).cos())
                        .hypot(g[1] + TAU * (TAU * p[0]).sin() * (TAU * p[1]).sin())
                })
                .sum::<f64>()
                / (n * n) as f64;
            errors.push(error);
        }
        for pair in errors.windows(2) {
            // Finite-difference jets plus interpolation: record convergence,
            // rather than assume an asymptotic order on the coarsest grid.
            assert!(pair[1] < pair[0], "{errors:?}");
        }
    }
}

}
mod gauge {
// Isolated pointwise source and staged cleaning kernels for the M0 audit.
// The general module reuses the immutable cleaning stages; its face stencils
// implement the coupled update separately from these pointwise audit kernels.
// Source: arXiv:2609.35989v1 (38), (41)-(42), (49)-(50), (76), (81), (88), (90), (92).

pub type Vec3 = [f64; 3];
/// `[component][coordinate]`, e.g. gradient_a[a][b] = partial_b A_a.
pub type Jacobian = [[f64; 3]; 3];

#[derive(Clone, Copy, Debug)]
/// Local point data: A is the periodic potential, magnetic is the total B and
/// mean_magnetic is the separately stored background. Velocities are laboratory
/// values; centroid_velocity is not a mesh-generator or face velocity.
pub struct PointSources {
    pub potential: Vec3,
    pub fluid_velocity: Vec3,
    pub auxiliary_velocity: Vec3,
    pub centroid_velocity: Vec3,
    pub magnetic: Vec3,
    pub mean_magnetic: Vec3,
    pub gradient_a: Jacobian,
    pub gradient_auxiliary: Jacobian,
    pub gradient_phi: Vec3,
    pub current: Vec3,
    pub resistivity: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct PotentialRate {
    pub induction: Vec3,
    pub distortion: Vec3,
    pub advection: Vec3,
    pub resistive: Vec3,
    pub cleaning: Vec3,
    pub mean_field: Vec3,
}

fn cross(a: Vec3, b: Vec3) -> Vec3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn finite_vec(v: Vec3) -> bool {
    v.iter().all(|x| x.is_finite())
}
fn finite(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() {
        Ok(value)
    } else {
        Err(format!("nonfinite {context}"))
    }
}
fn positive(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() && value > 0.0 {
        Ok(value)
    } else {
        Err(format!("{context} must be finite and positive"))
    }
}
fn interval(dt: f64) -> Result<(), String> {
    if dt.is_finite() && dt >= 0.0 {
        Ok(())
    } else {
        Err("time interval must be finite and nonnegative".into())
    }
}

impl PotentialRate {
    pub fn total(self) -> Vec3 {
        std::array::from_fn(|k| {
            self.induction[k]
                + self.distortion[k]
                + self.advection[k]
                + self.resistive[k]
                + self.cleaning[k]
                + self.mean_field[k]
        })
    }
}

impl PointSources {
    pub fn rate(self) -> Result<PotentialRate, String> {
        if ![
            self.potential,
            self.fluid_velocity,
            self.auxiliary_velocity,
            self.centroid_velocity,
            self.magnetic,
            self.mean_magnetic,
            self.gradient_phi,
            self.current,
        ]
        .into_iter()
        .all(finite_vec)
            || !self
                .gradient_a
                .into_iter()
                .chain(self.gradient_auxiliary)
                .all(finite_vec)
            || !self.resistivity.is_finite()
            || self.resistivity < 0.0
        {
            return Err(
                "point source requires finite vectors/Jacobians and nonnegative resistivity".into(),
            );
        }
        let relative_fluid =
            std::array::from_fn(|k| self.fluid_velocity[k] - self.auxiliary_velocity[k]);
        let relative_mesh: Vec3 =
            std::array::from_fn(|k| self.centroid_velocity[k] - self.auxiliary_velocity[k]);
        let result = PotentialRate {
            induction: cross(relative_fluid, self.magnetic),
            distortion: std::array::from_fn(|b| {
                -(0..3)
                    .map(|a| self.gradient_auxiliary[a][b] * self.potential[a])
                    .sum::<f64>()
            }),
            advection: std::array::from_fn(|a| {
                (0..3)
                    .map(|b| self.gradient_a[a][b] * relative_mesh[b])
                    .sum()
            }),
            resistive: self.current.map(|j| -self.resistivity * j),
            cleaning: self.gradient_phi,
            mean_field: cross(self.auxiliary_velocity, self.mean_magnetic),
        };
        if ![
            result.induction,
            result.distortion,
            result.advection,
            result.resistive,
            result.cleaning,
            result.mean_field,
            result.total(),
        ]
        .into_iter()
        .all(finite_vec)
        {
            return Err("point source overflow".into());
        }
        Ok(result)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Cleaning {
    alpha: f64,
    beta: f64,
}

impl Default for Cleaning {
    fn default() -> Self {
        Self {
            alpha: 1.0,
            beta: 0.15,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct CleaningBounds {
    /// Printed equation (49), r/(alpha cs).
    pub hyperbolic: f64,
    /// Printed equation (50), r^2/D, D=alpha cs r/beta.
    pub diffusive: f64,
}

/// Immutable initial source data enforce equation (90)'s frozen div(A) and cs.
#[derive(Clone, Copy, Debug)]
pub struct CleaningStage {
    parameters: Cleaning,
    phi_initial: f64,
    divergence_initial: f64,
    sound_speed_initial: f64,
    rate_initial: f64,
}

impl Cleaning {
    /// This active-cleaning kernel requires positive alpha and beta. Disabling
    /// cleaning is an explicit caller decision, not represented by invalid bounds.
    pub fn new(alpha: f64, beta: f64) -> Result<Self, String> {
        positive(alpha, "alpha")?;
        positive(beta, "beta")?;
        Ok(Self { alpha, beta })
    }
    pub fn alpha(self) -> f64 {
        self.alpha
    }
    pub fn beta(self) -> f64 {
        self.beta
    }

    pub fn rate(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<f64, String> {
        finite(phi, "cleaning scalar")?;
        finite(divergence_a, "potential divergence")?;
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        finite(
            self.alpha * sound_speed.powi(2) * divergence_a
                - self.beta * sound_speed * phi / radius,
            "cleaning rate",
        )
    }

    pub fn bounds(self, sound_speed: f64, radius: f64) -> Result<CleaningBounds, String> {
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        let hyperbolic = positive(radius / (self.alpha * sound_speed), "hyperbolic bound")?;
        let diffusive = positive(self.beta * hyperbolic, "diffusive bound")?;
        Ok(CleaningBounds {
            hyperbolic,
            diffusive,
        })
    }

    pub fn begin(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<CleaningStage, String> {
        let rate_initial = self.rate(phi, divergence_a, sound_speed, radius)?;
        Ok(CleaningStage {
            parameters: self,
            phi_initial: phi,
            divergence_initial: divergence_a,
            sound_speed_initial: sound_speed,
            rate_initial,
        })
    }
}

impl CleaningStage {
    pub fn initial_rate(self) -> f64 {
        self.rate_initial
    }

    pub fn predicted_phi(self, dt: f64) -> Result<f64, String> {
        interval(dt)?;
        finite(
            self.phi_initial + dt * self.rate_initial,
            "predicted cleaning scalar",
        )
    }

    pub fn endpoint_rate(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        self.parameters.rate(
            self.predicted_phi(dt)?,
            self.divergence_initial,
            self.sound_speed_initial,
            endpoint_radius,
        )
    }

    pub fn finish_phi(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        interval(dt)?;
        let rate_end = self.endpoint_rate(dt, endpoint_radius)?;
        finite(
            self.phi_initial + 0.5 * dt * (self.rate_initial + rate_end),
            "updated cleaning scalar",
        )
    }
}

}
mod passive {
// Prescribed constant-flow scalar A_z transport on fixed/rigid Voronoi meshes.
// This isolates the general pointwise face-LS transport operator; no gas evolves.
use moving_mesh::{
    Derivatives, Mesh, Vec2, dot,
    quadratic::{Compact, Quadratic},
};

pub struct Passive {
    mesh: Mesh,
    potential: Vec<f64>,
    time: f64,
    steps: usize,
    velocity: Vec2,
    mesh_velocity: Vec2,
    neighbour: Derivatives,
    face: Derivatives,
    dt: f64,
    quadratic: Option<Quadratic>,
    consistent: bool,
    compact: Option<Compact>,
}
impl Passive {
    pub fn mesh(&self) -> &Mesh {
        &self.mesh
    }
    pub fn potential(&self) -> &[f64] {
        &self.potential
    }
    pub fn time(&self) -> f64 {
        self.time
    }
    pub fn steps(&self) -> usize {
        self.steps
    }

    pub fn new(
        mesh: Mesh,
        velocity: Vec2,
        mesh_velocity: Vec2,
        initial: impl Fn(Vec2) -> f64,
    ) -> Result<Self, String> {
        Self::with_quadratic(mesh, velocity, mesh_velocity, initial, false)
    }
    pub fn with_quadratic(
        mesh: Mesh,
        velocity: Vec2,
        mesh_velocity: Vec2,
        initial: impl Fn(Vec2) -> f64,
        quadratic: bool,
    ) -> Result<Self, String> {
        Self::with_reconstruction(
            mesh,
            velocity,
            mesh_velocity,
            initial,
            quadratic,
            false,
            false,
        )
    }
    pub fn with_consistent(
        mesh: Mesh,
        velocity: Vec2,
        mesh_velocity: Vec2,
        initial: impl Fn(Vec2) -> f64,
    ) -> Result<Self, String> {
        Self::with_reconstruction(mesh, velocity, mesh_velocity, initial, true, true, false)
    }
    pub fn with_compact(
        mesh: Mesh,
        velocity: Vec2,
        mesh_velocity: Vec2,
        initial: impl Fn(Vec2) -> f64,
    ) -> Result<Self, String> {
        Self::with_reconstruction(mesh, velocity, mesh_velocity, initial, true, true, true)
    }
    fn with_reconstruction(
        mesh: Mesh,
        velocity: Vec2,
        mesh_velocity: Vec2,
        initial: impl Fn(Vec2) -> f64,
        quadratic: bool,
        consistent: bool,
        compact: bool,
    ) -> Result<Self, String> {
        if !velocity.iter().chain(&mesh_velocity).all(|v| v.is_finite()) {
            return Err("nonfinite velocity".into());
        }
        let neighbour = Derivatives::build(&mesh, false)?;
        let face = Derivatives::build(&mesh, true)?;
        let b = [
            mesh_velocity[0] - velocity[0],
            mesh_velocity[1] - velocity[1],
        ];
        let rate = face
            .samples
            .iter()
            .map(|samples| samples.iter().map(|s| dot(b, s.weight).abs()).sum::<f64>())
            .fold(0., f64::max);
        let potential: Vec<_> = mesh.cells.iter().map(|c| initial(c.centroid)).collect();
        if !potential.iter().all(|v| v.is_finite()) {
            return Err("nonfinite initial potential".into());
        }
        let quadratic = if quadratic {
            Some(Quadratic::build(&mesh)?)
        } else {
            None
        };
        let compact = if compact {
            Some(Compact::build(&mesh, &neighbour)?)
        } else {
            None
        };
        Ok(Self {
            compact,
            consistent,
            quadratic,
            mesh,
            potential,
            time: 0.,
            steps: 0,
            velocity,
            mesh_velocity,
            neighbour,
            face,
            dt: 0.3 / rate,
        })
    }
    fn gradient(&self, values: &[f64]) -> Result<Vec<Vec2>, String> {
        if let Some(q) = &self.quadratic {
            Ok(self.jets(q, values)?.iter().map(|j| j.gradient).collect())
        } else {
            self.neighbour.gradient(values)
        }
    }
    fn jets(
        &self,
        q: &Quadratic,
        values: &[f64],
    ) -> Result<Vec<moving_mesh::quadratic::QuadraticJet>, String> {
        if let Some(c) = &self.compact {
            c.jets(&self.neighbour, q, values)
        } else {
            q.jets(values)
        }
    }
    fn rate(&self, a: &[f64]) -> Result<Vec<f64>, String> {
        let (gradient, curvature) = if self.consistent {
            let jets = self.jets(
                self.quadratic
                    .as_ref()
                    .ok_or("consistent transport requires quadratic fit")?,
                a,
            )?;
            let g: Vec<_> = jets.iter().map(|j| j.gradient).collect();
            let h: Vec<_> = jets.iter().map(|j| j.hessian).collect();
            let factors = self.mesh.reconstruction()?.quadratic_factors(a, &g, &h)?;
            (
                g.iter()
                    .zip(&factors)
                    .map(|(g, f)| g.map(|v| v * f))
                    .collect(),
                Some(
                    h.iter()
                        .zip(&factors)
                        .map(|(h, f)| h.map(|v| v * f))
                        .collect::<Vec<_>>(),
                ),
            )
        } else {
            (self.mesh.limit_gradients(a, &self.gradient(a)?)?, None)
        };
        let b = [
            self.mesh_velocity[0] - self.velocity[0],
            self.mesh_velocity[1] - self.velocity[1],
        ];
        Ok(self
            .face
            .samples
            .iter()
            .enumerate()
            .map(|(i, samples)| {
                samples
                    .iter()
                    .map(|s| {
                        let face = &self.mesh.faces[s.index];
                        let donor = if dot(b, self.mesh.displacement(face, i)) < 0. {
                            i
                        } else {
                            self.mesh.neighbour(face, i).0
                        };
                        let up =
                            a[donor] + dot(gradient[donor], self.mesh.displacement(face, donor));
                        let correction = if let Some(h) = &curvature {
                            moving_mesh::quadratic::term(
                                h[donor],
                                self.mesh.displacement(face, donor),
                            ) - moving_mesh::quadratic::term(h[i], self.mesh.displacement(face, i))
                        } else {
                            0.
                        };
                        dot(b, s.weight)
                            * if curvature.is_some() {
                                up - a[i] + correction
                            } else {
                                up - a[i]
                            }
                    })
                    .sum()
            })
            .collect())
    }
    pub fn advance_to(&mut self, target: f64) -> Result<(), String> {
        if !target.is_finite()
            || target < self.time
            || !self.mesh_velocity.iter().all(|v| (v * target).is_finite())
        {
            return Err("invalid target".into());
        }
        if self.velocity == self.mesh_velocity {
            self.time = target;
            return Ok(());
        }
        while self.time < target {
            let dt = self.dt.min(target - self.time);
            if !dt.is_finite() || dt <= 0. || self.time + dt == self.time {
                return Err("invalid passive timestep".into());
            }
            let r0 = self.rate(&self.potential)?;
            let predictor: Vec<_> = self
                .potential
                .iter()
                .zip(&r0)
                .map(|(a, r)| a + dt * r)
                .collect();
            let r1 = self.rate(&predictor)?;
            let next: Vec<_> = self
                .potential
                .iter()
                .zip(r0)
                .zip(r1)
                .map(|((a, r0), r1)| a + 0.5 * dt * (r0 + r1))
                .collect();
            if !next.iter().all(|v| v.is_finite()) {
                return Err("nonfinite passive state".into());
            }
            self.potential = next;
            self.time += dt;
            self.steps += 1;
        }
        Ok(())
    }
    pub fn magnetic(&self) -> Result<Vec<Vec2>, String> {
        Ok(self
            .gradient(&self.potential)?
            .iter()
            .map(|g| [g[1], -g[0]])
            .collect())
    }
    pub fn positions(&self) -> Vec<Vec2> {
        self.mesh
            .cells
            .iter()
            .map(|c| {
                std::array::from_fn(|k| {
                    (c.centroid[k] + self.mesh_velocity[k] * self.time)
                        .rem_euclid(self.mesh.lengths[k])
                })
            })
            .collect()
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn compact_passive_preserves_constant_and_comoving_states_and_refines() {
        for jitter in [0., 0.15] {
            let f = |x: Vec2| (std::f64::consts::TAU * x[0]).sin();
            let mut errors = Vec::new();
            for n in [16, 32] {
                let mesh = Mesh::lattice(n, n, [1.; 2], jitter).unwrap();
                let mut fixed =
                    Passive::with_compact(mesh.clone(), [1., -0.5], [0.; 2], f).unwrap();
                fixed.advance_to(0.1).unwrap();
                errors.push(
                    fixed
                        .positions()
                        .iter()
                        .zip(fixed.potential())
                        .zip(&mesh.cells)
                        .map(|((x, a), c)| c.volume * (a - f([x[0] - 0.1, x[1] + 0.05])).abs())
                        .sum::<f64>(),
                );
                let mut rigid =
                    Passive::with_compact(mesh.clone(), [1., -0.5], [1., -0.5], f).unwrap();
                let a = rigid.potential.clone();
                let b = rigid.magnetic().unwrap();
                rigid.advance_to(0.1).unwrap();
                assert_eq!(a, rigid.potential);
                assert_eq!(b, rigid.magnetic().unwrap());
                let mut constant =
                    Passive::with_compact(mesh, [1., -0.5], [0.; 2], |_| 0.7).unwrap();
                constant.advance_to(0.1).unwrap();
                assert!(constant.potential.iter().all(|a| *a == 0.7));
            }
            assert!(errors[1] < 0.6 * errors[0], "{jitter}: {errors:?}");
        }
    }
    #[test]
    fn consistent_passive_preserves_constant_and_comoving_states_and_refines() {
        for jitter in [0., 0.15] {
            let f = |x: Vec2| (std::f64::consts::TAU * x[0]).sin();
            let mut errors = Vec::new();
            for n in [16, 32] {
                let mesh = Mesh::lattice(n, n, [1.; 2], jitter).unwrap();
                let mut fixed =
                    Passive::with_consistent(mesh.clone(), [1., -0.5], [0.; 2], f).unwrap();
                fixed.advance_to(0.1).unwrap();
                errors.push(
                    fixed
                        .positions()
                        .iter()
                        .zip(fixed.potential())
                        .zip(&mesh.cells)
                        .map(|((x, a), c)| c.volume * (a - f([x[0] - 0.1, x[1] + 0.05])).abs())
                        .sum::<f64>(),
                );
                let mut rigid =
                    Passive::with_consistent(mesh.clone(), [1., -0.5], [1., -0.5], f).unwrap();
                let a = rigid.potential.clone();
                let b = rigid.magnetic().unwrap();
                rigid.advance_to(0.1).unwrap();
                assert_eq!(a, rigid.potential);
                assert_eq!(b, rigid.magnetic().unwrap());
                let mut constant =
                    Passive::with_consistent(mesh, [1., -0.5], [0.; 2], |_| 0.7).unwrap();
                constant.advance_to(0.1).unwrap();
                assert!(constant.potential.iter().all(|a| *a == 0.7));
            }
            assert!(errors[1] < 0.6 * errors[0], "{jitter}: {errors:?}");
        }
    }
    #[test]
    fn rigid_transport_preserves_discrete_potential_and_curl_exactly() {
        for jitter in [0., 0.15] {
            let mut sim = Passive::new(
                Mesh::lattice(12, 9, [1.; 2], jitter).unwrap(),
                [2., 1.],
                [2., 1.],
                |x| (6. * x[0]).sin() * (7. * x[1]).cos(),
            )
            .unwrap();
            let a = sim.potential.clone();
            let b = sim.magnetic().unwrap();
            sim.advance_to(0.37).unwrap();
            assert_eq!(a, sim.potential);
            assert_eq!(b, sim.magnetic().unwrap());
        }
    }
    #[test]
    fn quadratic_passive_option_uses_the_quadratic_curl_and_preserves_comoving_state() {
        let mesh = Mesh::lattice(12, 12, [1.; 2], 0.15).unwrap();
        let f = |x: Vec2| (std::f64::consts::TAU * x[0]).sin();
        let linear = Passive::new(mesh.clone(), [2., 1.], [2., 1.], f).unwrap();
        let mut quad = Passive::with_quadratic(mesh.clone(), [2., 1.], [2., 1.], f, true).unwrap();
        let expected = Quadratic::build(&mesh)
            .unwrap()
            .jets(&quad.potential)
            .unwrap();
        let b = quad.magnetic().unwrap();
        assert!(
            b.iter()
                .zip(linear.magnetic().unwrap())
                .any(|(a, b)| (a[1] - b[1]).abs() > 1e-4)
        );
        for (b, j) in b.iter().zip(expected) {
            assert_eq!(*b, [j.gradient[1], -j.gradient[0]]);
        }
        let a = quad.potential.clone();
        quad.advance_to(1.).unwrap();
        assert_eq!(a, quad.potential);
        assert_eq!(b, quad.magnetic().unwrap());
    }
    #[test]
    fn smooth_fixed_transport_converges_and_constant_is_preserved() {
        for jitter in [0., 0.15] {
            let mut errors = Vec::new();
            for n in [16, 32] {
                let mut sim = Passive::new(
                    Mesh::lattice(n, n, [1.; 2], jitter).unwrap(),
                    [1., -0.5],
                    [0.; 2],
                    |x| (std::f64::consts::TAU * x[0]).sin(),
                )
                .unwrap();
                sim.advance_to(0.1).unwrap();
                errors.push(
                    sim.positions()
                        .iter()
                        .zip(&sim.potential)
                        .zip(&sim.mesh.cells)
                        .map(|((x, a), c)| {
                            c.volume * (a - (std::f64::consts::TAU * (x[0] - 0.1)).sin()).abs()
                        })
                        .sum::<f64>(),
                );
            }
            assert!(errors[1] < 0.6 * errors[0], "{jitter}: {errors:?}");
            let mut sim = Passive::new(
                Mesh::lattice(9, 8, [1.; 2], jitter).unwrap(),
                [-1., 2.],
                [0.; 2],
                |_| 0.7,
            )
            .unwrap();
            sim.advance_to(0.2).unwrap();
            assert!(sim.potential.iter().all(|a| *a == 0.7));
        }
    }
}

pub fn audit(mesh: moving_mesh::Mesh, values: &[f64], w:[f64;2])->Vec<f64>{let mut sim=Passive::with_compact(mesh,[0.;2],w, |_|0.).unwrap();sim.potential=values.to_vec();sim.rate(values).unwrap()}

}
use moving_mesh::{Mesh,Derivatives,quadratic::{Compact,Quadratic}};
use auxiliary::{SmoothVelocity,VelocitySample};
use operators::{MagneticFit,PotentialStage};
use mhd_core::{FaceFlux,FluxMethod};
fn main(){let mut worst:f64=0.;let mut cases=0;
 for (nx,ny) in [(8,7),(12,8)] {for jitter in [0.,0.15] {for reversed in [false,true] {for shape in 0..3 {
 let mut mesh=Mesh::lattice(nx,ny,[1.3,0.7],jitter).unwrap();if reversed {let mut pts=mesh.generators.clone();pts.reverse();mesh=Mesh::build(pts,mesh.lengths).unwrap();}
 let values:Vec<_>=mesh.cells.iter().map(|c|{let x=c.centroid;match shape {0=>0.7,1=>(6.0*x[0]).sin()*(9.0*x[1]).cos(),_=>if (10.*x[0]).sin()>0. {0.8} else {-0.4}}}).collect();let w=[0.7,-1.2];
 let passive=passive::audit(mesh.clone(),&values,w);
 let a:Vec<_>=values.iter().map(|&v|[0.,0.,v]).collect();let phi=vec![0.;a.len()];
 let neighbours=Derivatives::build(&mesh,false).unwrap();let faces=Derivatives::build(&mesh,true).unwrap();let quadratic=Quadratic::build(&mesh).unwrap();
 let compact=Compact::build(&mesh,&neighbours).unwrap();
 let fit=MagneticFit::with_stencil(&mesh,(&neighbours,Some(&quadratic),Some(&compact),true,true),&a,&phi,[0.;3],true).unwrap();
 let samples:Vec<_>=mesh.cells.iter().map(|c|VelocitySample{position:c.centroid,volume:c.volume,velocity:[0.;3]}).collect();let auxiliary=SmoothVelocity::build(mesh.lengths,&samples,[0.;2]).unwrap();
 let fluxes=vec![FaceFlux{fluid:[0.;5],induction:[0.;3],electromotive:[0.;3],velocity:[0.;3],magnetic:[0.;3],max_speed:1.,method:FluxMethod::HllFallback};mesh.faces.len()];let motion=vec![w;a.len()];
 let coupled=PotentialStage{mesh:&mesh,face_stencil:&faces,potential:&a,fit:&fit,faces:&fluxes,auxiliary:&auxiliary,advection_velocity:&motion,mean:[0.;3],reference_velocity:[0.;3],tau:0.,centered:true}.rate().unwrap();
 for (p,c) in passive.iter().zip(coupled){worst=worst.max((p-c[2]).abs());assert_eq!([c[0],c[1]],[0.;2]);}cases+=1;
 }}}}println!("cases={cases}; maximum passive/general rate difference={worst:.17e}");assert!(worst<1e-12);
}
