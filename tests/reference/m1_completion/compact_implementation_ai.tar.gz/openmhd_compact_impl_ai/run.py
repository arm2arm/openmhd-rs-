from pathlib import Path
import subprocess,hashlib,json
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');out=Path('/tmp/openmhd_compact_impl_ai');deps=root/'target/debug/deps'
base=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-Awarnings','-L','dependency='+str(deps)]
libs={name:max(deps.glob('lib'+name+'-*.rlib'),key=lambda x:x.stat().st_mtime) for name in ('moving_mesh','mhd_core')}
for name,p in libs.items():base+=['--extern',name+'='+str(p)]
marker='\nuse general::{Profile,Config,Initial,Motion,Simulation};'
main=marker+Path('/tmp/openmhd_consistent_ai/old.rs').read_text().rsplit(marker,1)[1]
main=main.replace('Profile::BulkFrameHllQuadraticV1]', 'Profile::BulkFrameHllQuadraticV1,Profile::BulkFrameHllConsistentV1,Profile::BulkFrameHllMatchedV1]')
for name,rev in [('old','e505837'),('new','568cfed')]:
 chunks=[]
 for m in ['general','operators','auxiliary','gauge']:
  code=subprocess.check_output(['git','show',rev+':crates/mhd-vector-pot/src/'+m+'.rs'],cwd=root,text=True);chunks.append('mod '+m+' {\n'+code.replace('//!','//')+'\n}')
 source=out/(name+'.rs');source.write_text('\n'.join(chunks)+main);subprocess.run(base+[str(source),'-o',str(out/name)],check=True)
 with (out/(name+'.txt')).open('w') as f:subprocess.run([str(out/name)],stdout=f,check=True)
assert (out/'old.txt').read_bytes()==(out/'new.txt').read_bytes();print('Historical36 coupled cases: bit-identical')
marker='\nuse moving_mesh::{Mesh,Derivatives,quadratic::Quadratic};'
main=marker+Path('/tmp/openmhd_consistent_ai/passive_equivalence.rs').read_text().rsplit(marker,1)[1]
main=main.replace('quadratic::Quadratic','quadratic::{Compact,Quadratic}')
main=main.replace('let fit=MagneticFit::with_stencil','let compact=Compact::build(&mesh,&neighbours).unwrap();\n let fit=MagneticFit::with_stencil')
main=main.replace('(&neighbours,Some(&quadratic),true)', '(&neighbours,Some(&quadratic),Some(&compact),true,true)')
extra='\npub fn audit(mesh: moving_mesh::Mesh, values: &[f64], w:[f64;2])->Vec<f64>{let mut sim=Passive::with_compact(mesh,[0.;2],w, |_|0.).unwrap();sim.potential=values.to_vec();sim.rate(values).unwrap()}\n'
chunks=[]
for m in ['operators','auxiliary','gauge','passive']:
 code=subprocess.check_output(['git','show','568cfed:crates/mhd-vector-pot/src/'+m+'.rs'],cwd=root,text=True);chunks.append('mod '+m+' {\n'+code.replace('//!','//')+(extra if m=='passive' else '')+'\n}')
source=out/'passive_equivalence.rs';source.write_text('\n'.join(chunks)+main);subprocess.run(base+[str(source),'-o',str(out/'passive_equivalence')],check=True)
with (out/'passive_equivalence.txt').open('w') as f:subprocess.run([str(out/'passive_equivalence')],stdout=f,check=True)
print((out/'passive_equivalence.txt').read_text().strip())
(out/'provenance.json').write_text(json.dumps({'historical_comparator':'e505837','implementation':'568cfed','historical_cases':36,'historical_bit_equal':True,'linked_libraries':{n:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in libs.items()}},indent=2)+'\n')
