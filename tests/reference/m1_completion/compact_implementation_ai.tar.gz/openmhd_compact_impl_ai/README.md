# Separate AI implementation review — compact derivative

Bounded implementation approval for `aae382e957e2d3e2d8534c908e550039ad815fd2` (numerical implementation `568cfed`, public-constructor validation follow-up `aae382e`). No physical candidate simulation was run by this reviewer, and no convergence/stability or M1 acceptance is asserted.

`run.py` embeds the exact general/operators/auxiliary/gauge modules from historical comparator `e505837` and implementation `568cfed` in `old.rs`/`new.rs`. A common independent driver evolves 36 cases: six historical profiles × fixed/rigid/fluid × limited/unlimited, on a rectangular 6×8 jitter .15 mesh for six steps to t=.003. Fields have nonuniform density/pressure, three-component A/v, nonzero phi and mean B. It serializes potential, phi, conservative state, generator positions and gauge offset by f64 bits. All old/new output bytes are identical. The follow-up constructor validation does not alter valid-geometry numerics.

`passive_equivalence.rs` uses the committed compact general and passive methods. It compares 24 instantaneous transport rates: two rectangular mesh sizes × regular/jitter .15 × original/reversed IDs × constant/smooth/jump data. Source, distortion and cleaning are set to zero in the general operator. The maximum difference is exactly zero. This verifies the passive restriction, not a coupled physical solution.

Reproduce using a checkout of the final reviewed libraries and pinned toolchain:

```sh
/Users/arm2arm/.cargo/bin/cargo build --locked -p moving-mesh -p mhd-core
python3 /tmp/openmhd_compact_impl_ai/run.py
/Users/arm2arm/.cargo/bin/cargo test --locked -p moving-mesh -p mhd-vector-pot compact
/Users/arm2arm/.cargo/bin/cargo test --locked -p mhd-vector-pot complete_consistent_rate_reproduces_quadratic_a_with_affine_face_source
python3 scripts/test_m1_completion.py
```

The script retains the original absolute repo/tmp paths and links workspace debug rlibs using `rustc --edition=2024 -Awarnings -L dependency=target/debug/deps --extern moving_mesh=... --extern mhd_core=...`. Compiler/library provenance and hashes are recorded. The seven focused compact tests, expanded complete-rate test and five completion-measurement fixtures passed independently. The parent separately reports 112 workspace tests and required checks passing.

Review checked cached first-sample-relative quadratic moments with actual periodic image offsets, five A-fit call sites including initial energy, raw curl/div versus common gradient/Hessian limiting, unlimited scalar gradient, deformation rebuilds, rigid cache reuse, historical profile preservation, passive/CLI/measurement identity. The only implementation issue found was missing validation at public Compact::build; `aae382e` adds mesh.validate() and malformed-face/neighbour/order regressions. No blocker remains for freezing the registered experiment. Earlier failed profiles and the design review's weak positive irregular coupled mode remain limitations to report, not erased evidence.
