from pathlib import Path
import json,random,math
p=Path(__file__).resolve().parent
cases=json.loads((p/'cases.json').read_text())
assert len(cases)==17
(p/'cases_initial17.json').write_bytes((p/'cases.json').read_bytes());(p/'cases_initial17.txt').write_bytes((p/'cases.txt').read_bytes());(p/'reference_initial17.json').write_bytes((p/'reference.json').read_bytes())
for name in ['square_zero_width','repeated_opposite','near_dependent','irregular_multiple_active']:
 base=next(x for x in cases if x['name']==name)
 for tag,order in [('reverse',list(reversed(range(len(base['constraints']))))),('cyclic',list(range(3,len(base['constraints'])))+list(range(3)))]:
  new=dict(base);new['name']=name+'_'+tag;new['constraints']=[base['constraints'][i] for i in order];new['permutation_of']=name;new['permutation']=order;cases.append(new)
rng=random.Random(20261105)
for k in range(12):
 cs=[];faces=[]
 for j in range(6):
  theta=math.tau*(j/6+rng.uniform(-.025,.025));radius=rng.uniform(.35,.65);x=radius*math.cos(theta);y=radius*math.sin(theta);faces.append([x,y]);normal=[x,y,x*x,y*y,math.sqrt(2)*x*y]
  cs.extend([dict(normal=normal,bound=0 if k%3==0 else .17),dict(normal=[-v for v in normal],bound=0 if k%3<2 else .23)])
 cases.append(dict(name=f'deterministic_hex_{k:02}',raw=[rng.uniform(-2,2) for _ in range(5)],constraints=cs,faces=faces))
cases.append(dict(name='underflow_normalization',raw=['1e-200',0,0,0,0],constraints=[dict(normal=['1e-200',0,0,0,0],bound=0)]))
cases.append(dict(name='overflow_normalization',raw=['1.3e308']*5,constraints=[dict(normal=['1e-200']*5,bound='5e108')]))
(p/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(p/'cases.txt').write_text('\n'.join('|'.join([v['name'],','.join(map(str,v['raw']))]+[','.join(map(str,a['normal']+[a['bound']])) for a in v['constraints']]) for v in cases)+'\n')
print(len(cases),'extended fixtures')
