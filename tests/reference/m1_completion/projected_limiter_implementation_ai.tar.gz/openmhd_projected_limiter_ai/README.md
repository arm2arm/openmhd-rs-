# Separate AI review — projected A reconstruction

Bounded implementation approval: `fb8bb14bf362a9eb42c2f32d6ec8c1252482790d`, following main implementation `0f2e5e295e55bc083690fc1450df9f4efe557932` and prospective registration `34fa7e2`. This is an AI numerical/code review, not human peer review or M1 scientific acceptance. No production files or solver profiles were edited by this reviewer, and no physical evolution was launched by this reviewer.

The prior directional/limiter diagnosis is separate and immutable in `../openmhd_standing_directional_ai`. It invalidates interpreting the old finite-difference coordinate eigenvalues as verified physical modes, independently reproduces the common-factor discontinuity, and identifies broad-fit transverse curvature contamination on exactly one-dimensional cosine data.

## Design and implementation checked

The new profile projects the five dimensionless A-jet coefficients onto the same incident-face bounds. Its metric is `||h g||^2 + ||h^2 H/2||_F^2`, with h=sqrt(cell volume), so rotations commute with the mathematical projection. The identity objective Hessian gives a unique primal solution even with dependent tight constraints. For fixed geometry the projection is continuous and piecewise affine in its raw coefficients and bounds. This addresses the reproduced limiter discontinuity without proving full coupled stability or convergence.

The code uses a feasible primal active set, twice-reorthogonalized working rows, explicit multiplier/feasibility/stationarity checks, and explicit failure on unsupported numerical rank, nonfinite arithmetic, iteration exhaustion or unrepresentable multipliers. Feasible raw jets are preserved. The mathematical bounds are unchanged; the implementation checks f64 residuals at a numerical, coefficient-scaled tolerance, not a physical gate relaxation. Exact bounds cannot preserve every arbitrary quadratic on an arbitrary irregular mesh; feasible raw quadratics remain unchanged.

All five A fits (initial state/energy, diagnostics, old stage, predictor stage, final closure) select projected limiting only for `bulk-frame-hll-projected-v1`. Raw compact curl/div(A)/grad(phi), frozen cleaning, gauge/reference velocity, fluid/induction HLLD flux and symmetric-HLL A completion remain unchanged. Both donor extrapolation and receiver quadratic correction use the projected Hessian. The passive restriction and CLI/runner identities match. Measurement diffs add only the new profile/identity choices; no physical threshold, normalization or accepted status is changed.

## Independent kernel reference

`reference.py` uses Python's 80-digit Decimal arithmetic and exhaustive independent active-subset KKT enumeration in dimension five. It imports no production algorithm. The 39 fixtures examine 44,541 subsets. Cases include feasible/constant jets, zero-width bounds, the flat transverse limit, recorded cosine jets, repeated/opposite/nearly dependent constraints, four/six-face configurations, row permutations, rotations, signed scaling, amplitude scaling and constraint normalization, plus extreme-range cases.

`revision3/` captures the final reviewed kernel exactly. Thirty-eight cases return successful projections, with these maximum independently evaluated errors:

| Quantity | Maximum |
|---|---:|
| coefficient error / raw coefficient scale | 1.412e-16 |
| normalized primal violation | 8.344e-17 |
| normalized stationarity residual | 5.144e-16 |
| normalized complementarity residual | 7.861e-17 |

The extreme overflow case explicitly fails because its original-normalization multiplier is not representable. A separate fortieth probe, `multiplier_underflow.txt`, likewise explicitly fails for a positive multiplier smaller than the f64 range. The final guard leaves all 38 ordinary primal outputs byte-identical to the initial implementation.

The first draft had two false-success range paths: an unnormalized feasibility product underflow and an intermediate bound-normalization overflow. They were fixed before `0f2e5e2`; `revision2/` preserves those checks. A later multiplier-underflow reporting edge was fixed in `fb8bb14`; the original failing output remains preserved. Final projection source SHA256: `8be10764c00db9161eba20485c015aee6cda5415d996678e134bc840b5a68642`.

## Historical behavior and focused checks

`historical/` compares all seven historical profiles against frozen `aae382e`: fixed/rigid/fluid mesh motion times limited/unlimited reconstruction, for 42 rectangular 6x8 jittered evolutions with nonuniform three-component fields, nonzero mean B and phi. A, phi, conservative amounts, generator positions and gauge offset serialize bit-identically. The exact driver, captured modules, commands, library hashes and output hashes are retained.

Reviewer-run checks passed: seven projection tests, three projected-profile/passive tests, five completion measurement tests and eight wave measurement tests. Parent separately reports all 122 Rust tests, formatting, strict Clippy and locked release build passing. An initial mistyped Python test filename failed to launch; `wave_tests.log` retains it, and the correct eight-test run is in `wave_loop_tests.log`.

## Completed fixed-cap controls checked

Parent ran the unchanged frozen `0f2e5e2` binary. The reviewer independently checked all 25 source hashes against that revision, binary/runner/cache hashes, all 28 raw artifact digests, the final manifest/runs seal, cell IDs, times, periodic boost position matching, volumes, transforms and vector/scalar norms. The source and measurement provenance must remain associated with `0f2e5e2`, even though the later public API guard is approved separately.

| N | dt cap | paired steps | quarter primary max normalized L1 | final primary max normalized L1 |
|---|---:|---:|---:|---:|
| 32 | .0002 | 5001 each | 9.52005e-14 | 1.18865e-12 |
| 64 | .0001 | 10002 each | 1.42930e-13 | 1.82609e-10 |

Both pairs are below the unchanged 1e-8 threshold, have no CFL/state/geometry rejection, and remain positive. The maximum recorded normalized conservation budget is 3.15304e-14. N64's residual is a bounded pass, not described as roundoff-level. These controls improve the prior compact failures but do not replace the registered adaptive comparisons or spatial convergence gates.

`controls_n32/` preserves the metadata snapshot taken while N64 was still running; it explicitly marks the whole-study seal absent at that time. `controls_n64/` and `controls_final_seal.json` verify the completed four-run seal. An initial NumPy/Accelerate matmul emitted floating-point warnings despite finite reported values; its script/output snapshot is retained under `controls_n32_matmul_warning/`. The accepted independent measurement uses explicit elementwise products/reductions and finite-value assertions, with identical reported norms.

## Reproduce and scope

Use the standard Python interpreter for `make_cases.py`, `extend_cases.py`, `reference.py` and `compare.py`; the reference requires only the standard library. `build_probe.py` and `rerun_kernel.py` record exact rustc commands and source/binary hashes. The NumPy control verifier should run with BLAS threads restricted:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python check_control.py 32
```

Run regenerations in a new directory; the completed evidence here should remain immutable. `checksums.json` covers every retained file except itself. Compiled executables can be omitted from the source/data archive if their hashes are retained.

Final bounded verdict: no blocker remains to freeze `fb8bb14` for the registered wave ladder. The old compact convergence order 1.640159 and standing boost failures remain failed evidence. The projected candidate still needs its own complete physical, temporal, conservation, positivity and invariance packet before M1 or issue #7 can close.
