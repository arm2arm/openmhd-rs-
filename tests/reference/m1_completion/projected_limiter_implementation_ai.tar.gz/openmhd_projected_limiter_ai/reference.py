"""Independent Decimal exhaustive KKT active-subset reference, dimension five.
No production active-set implementation is imported. Constraints are a.z <= b.
Zero-feasible inputs only. Decimal precision 80; numerical rank threshold 1e-60.
"""
from decimal import Decimal,localcontext
from itertools import combinations
import json,sys,time
D=lambda x: Decimal(str(x))
def dot(a,b): return sum((x*y for x,y in zip(a,b)),Decimal(0))
def solve(a,b):
    n=len(b); a=[list(row)+[b[i]] for i,row in enumerate(a)]
    scale=max((abs(x) for row in a for x in row[:-1]),default=Decimal(1))
    for j in range(n):
        pivot=max(range(j,n),key=lambda i:abs(a[i][j]))
        if abs(a[pivot][j]) <= Decimal('1e-60')*scale: return None
        a[j],a[pivot]=a[pivot],a[j]
        z=a[j][j];a[j]=[x/z for x in a[j]]
        for i in range(n):
            if i==j: continue
            z=a[i][j]
            if z: a[i]=[x-z*y for x,y in zip(a[i],a[j])]
    return [row[-1] for row in a]
def project(raw,constraints):
    with localcontext() as ctx:
        ctx.prec=80
        raw=list(map(D,raw)); aa=[list(map(D,c['normal'])) for c in constraints]; bb=[D(c['bound']) for c in constraints]
        assert len(raw)==5 and all(len(a)==5 for a in aa) and all(b>=0 for b in bb)
        scale=max([Decimal(1)]+[abs(x) for x in raw]+bb)
        tol=Decimal('1e-45')*scale
        result=None; tried=0; rank_deficient=0; valid=0
        if all(dot(a,raw)<=b for a,b in zip(aa,bb)):
            return dict(value=[str(x) for x in raw],objective='0',active=[],multipliers=['0']*len(aa),tried=0,rank_deficient=0,valid=1,feasibility='0',stationarity='0')
        for k in range(1,min(5,len(aa))+1):
            for ids in combinations(range(len(aa)),k):
                tried+=1; a=[aa[i] for i in ids]
                gram=[[dot(x,y) for y in a] for x in a]
                lam=solve(gram,[dot(aa[i],raw)-bb[i] for i in ids])
                if lam is None: rank_deficient+=1; continue
                if any(l < -tol for l in lam): continue
                z=[raw[j]-sum(l*x[j] for l,x in zip(lam,a)) for j in range(5)]
                feasibility=max([Decimal(0)]+[dot(x,z)-b for x,b in zip(aa,bb)])
                if feasibility>tol: continue
                objective=dot([x-y for x,y in zip(z,raw)],[x-y for x,y in zip(z,raw)])/2
                valid+=1
                if result is None or objective<D(result['objective']):
                    multipliers=[Decimal(0)]*len(aa)
                    for i,l in zip(ids,lam): multipliers[i]=l
                    stationarity=max(abs(z[j]-raw[j]+sum(l*a[j] for l,a in zip(multipliers,aa))) for j in range(5))
                    result=dict(value=[str(x) for x in z],objective=str(objective),active=list(ids),multipliers=[str(x) for x in multipliers],feasibility=str(feasibility),stationarity=str(stationarity))
        if result is None: raise ArithmeticError('No high-precision feasible KKT candidate')
        return dict(result,tried=tried,rank_deficient=rank_deficient,valid=valid)
if __name__=='__main__':
    start=time.monotonic();cases=json.load(open(sys.argv[1]));out=[]
    for c in cases:
        r=project(c['raw'],c['constraints']);out.append(dict(name=c['name'],**r));print(c['name'],r['tried'],r['valid'],flush=True)
    json.dump(dict(precision=80,rank_threshold='1e-60',KKT_tolerance='1e-45 times input scale',seconds=time.monotonic()-start,cases=out),open(sys.argv[2],'w'),indent=2)
