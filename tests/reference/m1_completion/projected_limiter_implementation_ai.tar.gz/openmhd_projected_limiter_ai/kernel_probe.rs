// Continuous minimum-change projection of quadratic face reconstructions.
// The metric and prospective experiment are specified in M1_COMPLETION_PLAN.md.



pub type Coefficients = [f64; 5];

/// Half-space `normal dot value <= bound`; zero must be feasible.
#[derive(Clone, Copy, Debug)]
pub struct HalfSpace {
    pub normal: Coefficients,
    pub bound: f64,
}

#[derive(Clone, Debug)]
pub struct Projection {
    pub value: Coefficients,
    /// Nonnegative KKT multipliers in the original constraint normalization.
    pub multipliers: Vec<f64>,
    pub iterations: usize,
}

fn dot(a: Coefficients, b: Coefficients) -> f64 {
    a.iter().zip(b).map(|(a, b)| a * b).sum()
}
fn norm(a: Coefficients) -> f64 {
    a.into_iter().fold(0., f64::hypot)
}
const ROUND: f64 = 256. * f64::EPSILON;

/// Euclidean projection, using a feasible primal active set in at most five dimensions.
/// Working rows are independent; the complete set of tight constraints need not be.
/// Failure is explicit rather than substituting another limiter.
pub fn project(raw: Coefficients, constraints: &[HalfSpace]) -> Result<Projection, String> {
    if !raw.iter().all(|x| x.is_finite())
        || constraints.iter().any(|c| {
            !c.bound.is_finite() || c.bound < 0. || !c.normal.iter().all(|x| x.is_finite())
        })
    {
        return Err("projection requires finite coefficients and zero-feasible bounds".into());
    }
    let norms: Vec<_> = constraints.iter().map(|c| norm(c.normal)).collect();
    if norms.iter().any(|n| !n.is_finite() || *n == 0.) {
        return Err("projection requires nonzero finite constraint normals".into());
    }
    if constraints.iter().all(|c| dot(c.normal, raw) <= c.bound) {
        return Ok(Projection {
            value: raw,
            multipliers: vec![0.; constraints.len()],
            iterations: 0,
        });
    }
    let scale = raw.iter().map(|v| v.abs()).fold(0., f64::max);
    if scale == 0. {
        return Err("zero projection unexpectedly infeasible".into());
    }
    let target = raw.map(|v| v / scale);
    let rows: Vec<_> = constraints
        .iter()
        .zip(&norms)
        .map(|(c, n)| c.normal.map(|v| v / n))
        .collect();
    // A positive overflow here is an inactive, very distant bound, not an invalid input.
    let bounds: Vec<_> = constraints
        .iter()
        .zip(&norms)
        .map(|(c, n)| (c.bound / n) / scale)
        .collect();
    let tolerance = ROUND * (1. + norm(target));
    let mut x = [0.; 5];
    let mut active: Vec<usize> = Vec::new();
    for iteration in 0..256 {
        let mut basis: Vec<Coefficients> = Vec::new();
        let mut lower = [[0.; 5]; 5];
        for (i, &index) in active.iter().enumerate() {
            let mut row = rows[index];
            for _ in 0..2 {
                for (j, &q) in basis.iter().enumerate() {
                    let amount = dot(row, q);
                    lower[i][j] += amount;
                    for k in 0..5 {
                        row[k] -= amount * q[k];
                    }
                }
            }
            let diagonal = norm(row);
            if diagonal <= ROUND || !diagonal.is_finite() {
                return Err("projection working constraints are numerically dependent".into());
            }
            lower[i][i] = diagonal;
            basis.push(row.map(|v| v / diagonal));
        }
        let residual: Coefficients = std::array::from_fn(|k| target[k] - x[k]);
        let mut direction = residual;
        for _ in 0..2 {
            for &q in &basis {
                let amount = dot(direction, q);
                for k in 0..5 {
                    direction[k] -= amount * q[k];
                }
            }
        }
        if norm(direction) <= tolerance {
            let mut lambda = vec![0.; active.len()];
            for i in (0..active.len()).rev() {
                lambda[i] = (dot(basis[i], residual)
                    - ((i + 1)..active.len())
                        .map(|j| lower[j][i] * lambda[j])
                        .sum::<f64>())
                    / lower[i][i];
            }
            // Bland-style index selection on negative multipliers avoids arbitrary tie choices.
            if let Some(remove) = (0..active.len())
                .filter(|&i| lambda[i] < -tolerance)
                .min_by_key(|&i| active[i])
            {
                active.remove(remove);
                continue;
            }
            let mut stationarity: Coefficients = std::array::from_fn(|k| x[k] - target[k]);
            for (&index, &l) in active.iter().zip(&lambda) {
                for k in 0..5 {
                    stationarity[k] += l * rows[index][k];
                }
            }
            let multiplier_scale = 1. + lambda.iter().map(|l| l.abs()).sum::<f64>();
            if !x.iter().chain(&lambda).all(|v| v.is_finite())
                || norm(stationarity) > tolerance * multiplier_scale
                || rows
                    .iter()
                    .zip(&bounds)
                    .any(|(&r, &b)| dot(r, x) - b > tolerance)
                || active
                    .iter()
                    .any(|&i| (dot(rows[i], x) - bounds[i]).abs() > tolerance)
            {
                return Err("projection KKT residual exceeds f64 tolerance".into());
            }
            let mut multipliers = vec![0.; constraints.len()];
            for (&index, l) in active.iter().zip(lambda) {
                multipliers[index] = l.max(0.) * scale / norms[index];
            }
            let value = x.map(|v| v * scale);
            if !value.iter().chain(&multipliers).all(|v| v.is_finite()) {
                return Err("projection output overflow".into());
            }
            return Ok(Projection {
                value,
                multipliers,
                iterations: iteration + 1,
            });
        }
        let direction_norm = norm(direction);
        let mut step = 1_f64;
        let mut blocking = None;
        for (i, (&row, &bound)) in rows.iter().zip(&bounds).enumerate() {
            if active.contains(&i) {
                continue;
            }
            let speed = dot(row, direction);
            if speed <= ROUND * direction_norm {
                continue;
            }
            let slack = bound - dot(row, x);
            if slack < -tolerance {
                return Err("projection lost primal feasibility".into());
            }
            let candidate = slack.max(0.) / speed;
            if candidate < step {
                step = candidate;
                blocking = Some(i);
            }
        }
        for k in 0..5 {
            x[k] += step * direction[k];
        }
        if let Some(index) = blocking {
            if active.len() == 5 {
                return Err("projection exceeded working-set dimension".into());
            }
            active.push(index);
        }
    }
    Err("projection active-set iteration limit".into())
}


fn main(){for line in std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap().lines(){
 let v:Vec<_>=line.split('|').collect();let parse=|s:&str|->Vec<f64>{s.split(',').map(|x|x.parse().unwrap()).collect()};let r=parse(v[1]);let raw:[f64;5]=r.try_into().unwrap();let cs:Vec<_>=v[2..].iter().map(|s|{let x=parse(s);HalfSpace{normal:x[..5].try_into().unwrap(),bound:x[5]}}).collect();
 match project(raw,&cs){Ok(r)=>println!("{}|ok|{}|{}|{}",v[0],r.iterations,r.value.iter().map(|x|format!("{x:.17e}")).collect::<Vec<_>>().join(","),r.multipliers.iter().map(|x|format!("{x:.17e}")).collect::<Vec<_>>().join(",")),Err(e)=>println!("{}|error|{}",v[0],e)}
}}
