from pathlib import Path
from decimal import Decimal as D,localcontext
import json
p=Path(__file__).resolve().parent
with localcontext() as ctx:
 ctx.prec=70
 sqrt2=D(2).sqrt(); sqrt3=D(3).sqrt();zero=D(0)
 def dc(xs): return [D(str(x)) for x in xs]
 def fixture(name,raw,faces,low,high,**metadata):
  raw=dc(raw);faces=[dc(f) for f in faces];lo=D(str(low));hi=D(str(high));cs=[]
  for x,y in faces:
   b=[x,y,x*x,y*y,sqrt2*x*y]
   cs.extend([dict(normal=[str(v) for v in b],bound=str(hi)),dict(normal=[str(-v) for v in b],bound=str(-lo))])
  return dict(name=name,raw=[str(v) for v in raw],faces=[[str(v) for v in f] for f in faces],low=str(lo),high=str(hi),constraints=cs,**metadata)
 square=[['.5',0],[0,'.5'],['-.5',0],[0,'-.5']]
 hexagon=[['.5',0],['.25',sqrt3/4],['-.25',sqrt3/4],['-.5',0],['-.25',-sqrt3/4],['.25',-sqrt3/4]]
 cases=[]
 cases.append(fixture('square_feasible',[.1,-.2,-.3,-.4,.7],square,-1,1))
 cases.append(fixture('square_flat_quadratic',[0,0,-1,0,.4],square,-1,0))
 for epsilon in ['1e-8','1e-16','1e-30']:
  cases.append(fixture('square_flat_curvature_'+epsilon,[0,0,-1,epsilon,0],square,-1,0))
 cases.append(fixture('square_zero_width',[.7,-.2,.8,-.4,.3],square,0,0))
 cases.append(fixture('square_multiple_active',[2,-3,4,2,-1],square,-.2,.3))
 cases.append(fixture('hex_multiple_active',[2,-3,4,2,-1],hexagon,-.2,.3))
 irregular=[['.37','.06'],['.21','.56'],['-.31','.44'],['-.59','.02'],['-.22','-.38'],['.28','-.41']]
 cases.append(fixture('irregular_multiple_active',[1.7,-2.1,.8,-.7,.9],irregular,-.23,.14))
 cases.append(fixture('repeated_opposite',[-1,2,3,-4,.5],square+[square[0],square[2]],0,0))
 near=[['.5',0],['.5','1e-10'],['-.5',0],[0,'.5'],[0,'-.5'],['.3','-.4']]
 cases.append(fixture('near_dependent',[0,1,0,0,0],near,0,0))
 # Recorded exact row-constant cosine fit at N32; h=1/32.
 cases.append(fixture('cosine_n32',[0,0,D('-38.93167197866976')/2048,D('.08401475110286681')/2048,0],square,D('-1')+D('.9807852804032304'),0))
 # Orthogonal rational rotation c=3/5,s=4/5 and invariant tensor metric.
 c=D(3)/5;s=D(4)/5
 base=cases[8];raw=dc(base['raw']);gx,gy,xx,yy,xy=raw;cross=xy/sqrt2
 rot=[c*gx-s*gy,s*gx+c*gy,c*c*xx-2*c*s*cross+s*s*yy,s*s*xx+2*c*s*cross+c*c*yy,sqrt2*(c*s*(xx-yy)+(c*c-s*s)*cross)]
 faces=[[c*x-s*y,s*x+c*y] for x,y in map(dc,base['faces'])]
 cases.append(fixture('irregular_rotated',rot,faces,base['low'],base['high'],rotation_of=base['name'],rotation_cos=str(c),rotation_sin=str(s)))
 for scale in ['1e-20','1e20']:
  sc=D(scale);cases.append(fixture('irregular_scaled_'+scale,[sc*x for x in dc(base['raw'])],base['faces'],sc*D(base['low']),sc*D(base['high']),scale_of=base['name'],scale=scale))
 flip=fixture('irregular_sign_reversed',[-x for x in dc(base['raw'])],base['faces'],-D(base['high']),-D(base['low']),sign_reverse_of=base['name']);cases.append(flip)
 # Kernel is generic: duplicate and differently normalized same constraints.
 case=dict(cases[8]);case['name']='irregular_rescaled_constraints';case['constraints']=[dict(normal=[str(D(x)*(D(10)**(i%5-2))) for x in v['normal']],bound=str(D(v['bound'])*(D(10)**(i%5-2)))) for i,v in enumerate(case['constraints'])];cases.append(case)
 (p/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
 (p/'cases.txt').write_text('\n'.join('|'.join([v['name'],','.join(v['raw'])]+[','.join(a['normal']+[a['bound']]) for a in v['constraints']]) for v in cases)+'\n')
 print(len(cases),'fixtures')
