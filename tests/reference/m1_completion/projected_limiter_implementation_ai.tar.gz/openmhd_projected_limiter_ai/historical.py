from pathlib import Path
import subprocess,hashlib,json
p=Path(__file__).resolve().parent;root=p.parents[2];out=p/'historical';out.mkdir();deps=root/'target/release/deps';old='aae382e957e2d3e2d8534c908e550039ad815fd2'
previous=Path('/tmp/openmhd_compact_impl_ai/new.rs').read_text();marker='\nuse general::{Profile,Config,Initial,Motion,Simulation};';main=marker+previous.rsplit(marker,1)[1];main=main.replace('Profile::BulkFrameHllMatchedV1]', 'Profile::BulkFrameHllMatchedV1,Profile::BulkFrameHllCompactV1]');(out/'driver.rs').write_text(main)
libs={name:next(deps.glob('lib'+name+'-*.rlib')) for name in ['moving_mesh','mhd_core']};base=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-Awarnings','-O','-L','dependency='+str(deps)]
for name,lib in libs.items():base+=['--extern',name+'='+str(lib)]
ledger={};commands=[]
for label in ['old','new']:
 chunks=[];ledger[label]={}
 for m in ['general','operators','auxiliary','gauge']:
  filename='crates/mhd-vector-pot/src/'+m+'.rs';code=subprocess.check_output(['git','show',old+':'+filename],cwd=root,text=True) if label=='old' else (root/filename).read_text();ledger[label][filename]=hashlib.sha256(code.encode()).hexdigest();chunks.append('mod '+m+' {\n'+code.replace('//!','//')+'\n}')
 file=out/(label+'.rs');file.write_text('\n'.join(chunks)+main);cmd=base+[str(file),'-o',str(out/label)];commands.append(cmd);subprocess.run(cmd,check=True)
 with (out/(label+'.txt')).open('w') as f:subprocess.run([str(out/label)],stdout=f,stderr=subprocess.STDOUT,check=True)
a=(out/'old.txt').read_bytes();b=(out/'new.txt').read_bytes();assert a==b
cases=sum(1 for line in a.decode().splitlines() if not line.endswith(','));assert cases==42,cases
(out/'provenance.json').write_text(json.dumps(dict(old_revision=old,new='working tree captured by source hashes',cases=cases,bit_identical=True,driver_sha256=hashlib.sha256(main.encode()).hexdigest(),sources=ledger,commands=commands,run_commands=[[str(out/'old')],[str(out/'new')]],libraries={name:dict(path=str(lib),sha256=hashlib.sha256(lib.read_bytes()).hexdigest()) for name,lib in libs.items()},output_sha256=hashlib.sha256(a).hexdigest()),indent=2)+'\n');print('42 historical evolutions bit-identical')
