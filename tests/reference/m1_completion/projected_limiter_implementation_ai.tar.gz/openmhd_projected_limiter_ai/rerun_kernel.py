from pathlib import Path
import hashlib,json,subprocess,sys
base=Path(__file__).resolve().parent;root=base.parents[2];p=base/sys.argv[1];p.mkdir()
source=root/'crates/moving-mesh/src/projection.rs';raw=source.read_text();(p/'projection_reviewed.rs').write_text(raw)
kernel=raw.split('#[derive(Clone, Copy, Debug)]\npub struct LimitedJet')[0].replace('use crate::{Reconstruction, Vec2};','').replace('use std::f64::consts::SQRT_2;','').replace('//!','//')
harness=(base/'kernel_probe.rs').read_text().split('fn main(){')[1];(p/'kernel_probe.rs').write_text(kernel+'fn main(){'+harness)
cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-O',str(p/'kernel_probe.rs'),'-o',str(p/'kernel_probe')];subprocess.run(cmd,check=True)
run=[str(p/'kernel_probe'),str(base/'cases.txt')]
with (p/'kernel_results.txt').open('w') as f:subprocess.run(run,stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'provenance.json').write_text(json.dumps(dict(scope='Independent AI projection kernel rerun',source_path=str(source),source_sha256=hashlib.sha256(raw.encode()).hexdigest(),compile_command=cmd,run_command=run,binary_sha256=hashlib.sha256((p/'kernel_probe').read_bytes()).hexdigest(),cases_sha256=hashlib.sha256((base/'cases.json').read_bytes()).hexdigest(),cases_text_sha256=hashlib.sha256((base/'cases.txt').read_bytes()).hexdigest(),reference_sha256=hashlib.sha256((base/'reference.json').read_bytes()).hexdigest()),indent=2)+'\n')
