from pathlib import Path
from decimal import Decimal as D,localcontext
import json,sys
p=Path(__file__).resolve().parent
results=Path(sys.argv[1]);out=Path(sys.argv[2])
cases={c['name']:c for c in json.loads((p/'cases.json').read_text())};references={r['name']:r for r in json.loads((p/'reference.json').read_text())['cases']};rows=[]
with localcontext() as ctx:
 ctx.prec=80
 for line in results.read_text().splitlines():
  chunks=line.split('|');name=chunks[0];case=cases[name];ref=references[name]
  if chunks[1]=='error': rows.append(dict(name=name,error=chunks[2]));continue
  z=list(map(D,chunks[3].split(',')));lam=list(map(D,chunks[4].split(',')));raw=list(map(lambda x:D(str(x)),case['raw']));target=list(map(D,ref['value']));scale=max(abs(x) for x in raw) or D(1)
  aa=[list(map(lambda x:D(str(x)),a['normal'])) for a in case['constraints']];bb=[D(str(a['bound'])) for a in case['constraints']]
  dot=lambda a,b:sum(x*y for x,y in zip(a,b));slack=[dot(a,z)-b for a,b in zip(aa,bb)]
  primal=max([D(0)]+[s/(dot(a,a).sqrt()*scale) for a,s in zip(aa,slack)])
  stationarity=max(abs(z[j]-raw[j]+sum(l*a[j] for l,a in zip(lam,aa))) for j in range(5))/scale
  comp=max([D(0)]+[abs(l*s)/(scale*scale) for l,s in zip(lam,slack)])
  error=max(abs(x-y) for x,y in zip(z,target))/scale
  row=dict(name=name,iterations=int(chunks[2]),value=[str(x) for x in z],max_value_error_over_raw_scale=float(error),max_normalized_primal_violation=float(primal),max_normalized_stationarity=float(stationarity),max_normalized_complementarity=float(comp),minimum_multiplier=str(min(lam)))
  rows.append(row)
 ordinary=[r for r in rows if r['name']!='overflow_normalization' and 'error' not in r]
 maxima={field:max(r[field] for r in ordinary) for field in ['max_value_error_over_raw_scale','max_normalized_primal_violation','max_normalized_stationarity','max_normalized_complementarity']}
 out.write_text(json.dumps(dict(results_path=str(results),successful=len(ordinary),errors=[r for r in rows if 'error' in r],maxima=maxima,cases=rows),indent=2)+'\n');print(json.dumps(dict(successful=len(ordinary),errors=[r for r in rows if 'error' in r],maxima=maxima),indent=2))
