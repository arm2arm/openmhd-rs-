from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;root=p.parents[2]
source=root/'crates/moving-mesh/src/projection.rs';raw=source.read_text()
(p/'projection_reviewed.rs').write_text(raw)
# Only the public kernel, with imports that refer to unrelated mesh adapter removed.
kernel=raw.split('#[derive(Clone, Copy, Debug)]\npub struct LimitedJet')[0].replace('use crate::{Reconstruction, Vec2};','').replace('use std::f64::consts::SQRT_2;','').replace('//!','//')
harness=r'''
fn main(){for line in std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap().lines(){
 let v:Vec<_>=line.split('|').collect();let parse=|s:&str|->Vec<f64>{s.split(',').map(|x|x.parse().unwrap()).collect()};let r=parse(v[1]);let raw:[f64;5]=r.try_into().unwrap();let cs:Vec<_>=v[2..].iter().map(|s|{let x=parse(s);HalfSpace{normal:x[..5].try_into().unwrap(),bound:x[5]}}).collect();
 match project(raw,&cs){Ok(r)=>println!("{}|ok|{}|{}|{}",v[0],r.iterations,r.value.iter().map(|x|format!("{x:.17e}")).collect::<Vec<_>>().join(","),r.multipliers.iter().map(|x|format!("{x:.17e}")).collect::<Vec<_>>().join(",")),Err(e)=>println!("{}|error|{}",v[0],e)}
}}
'''
(p/'kernel_probe.rs').write_text(kernel+harness)
cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-O',str(p/'kernel_probe.rs'),'-o',str(p/'kernel_probe')];subprocess.run(cmd,check=True)
run=[str(p/'kernel_probe'),str(p/'cases.txt')]
with (p/'kernel_results.txt').open('w') as f:subprocess.run(run,stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'provenance.json').write_text(json.dumps(dict(scope='Independent AI comparison of uncommitted projection kernel; no solver evolution',registration='34fa7e2',source_path=str(source),source_sha256=hashlib.sha256(raw.encode()).hexdigest(),compile_command=cmd,run_command=run,binary_sha256=hashlib.sha256((p/'kernel_probe').read_bytes()).hexdigest(),rustc=subprocess.check_output(['/Users/arm2arm/.cargo/bin/rustc','-Vv'],text=True),reference='Decimal 80-digit exhaustive independent active-subset KKT enumeration',reference_command=['/Users/arm2arm/.venvs/openmhd-plot/bin/python',str(p/'reference.py'),str(p/'cases.json'),str(p/'reference.json')]),indent=2)+'\n')
