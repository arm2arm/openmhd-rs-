"""Independent raw control-pair verification. Captures metadata once; no solver run."""
from pathlib import Path
import hashlib,json,subprocess,sys
import numpy as np
p=Path(__file__).resolve().parent;root=p.parents[2];study=root/'results/m1_projected_controls';n=int(sys.argv[1]);out=p/f'controls_n{n}';out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();metadata={name:(study/name).read_bytes() for name in ['provenance.json','manifest.json','runs.json']}
for name,b in metadata.items():(out/name).write_bytes(b)
prov,manifest,runs=[json.loads(metadata[name]) for name in ['provenance.json','manifest.json','runs.json']];names=[f'n{n}_base',f'n{n}_boost'];assert prov['revision']=='0f2e5e295e55bc083690fc1450df9f4efe557932';frozen=Path('/tmp/openmhd-m1-projected');assert sha((frozen/'target/release/vector-potential').read_bytes())==prov['binary_sha256']
for file,digest in prov['source_sha256'].items():
 assert sha((frozen/file).read_bytes())==digest,file
 assert sha(subprocess.check_output(['git','show',prov['revision']+':'+file],cwd=root))==digest,file
assert sha((root/'results/run_m1_projected_controls.py').read_bytes())==prov['script_sha256']
raw_count=0;raw_hashes={}
for name in names:
 r=runs[name];c=manifest[name];assert r['status']=='completed' and r['exit_code']==0 and r['config']==c
 assert sha(Path(c['mesh_cache']).read_bytes())==c['mesh_cache_sha256']
 for file,digest in r['sha256'].items():
  b=(study/name/file).read_bytes();assert sha(b)==digest,(name,file);raw_count+=1;raw_hashes[name+'/'+file]=digest
 s=json.loads((study/name/'summary.json').read_text());assert s==r['summary'];assert s['profile']=='bulk-frame-hll-projected-v1' and s['limited'] and s['time']==1 and s['completed'];assert s['n']==n and s['nx']==s['ny']==n and s['jitter']==0 and s['parallel_velocity']==1 and s['gamma']==5/3 and s['mean_B']==[1,0,0];assert s['dt_cap']==c['dt'] and all(s[k]==0 for k in ['rejected_cfl','rejected_state','rejected_geometry']);assert s['dt_max']<=c['dt'];assert s['boost']==([2,-1,0] if c['boosted'] else [0,0,0]);assert s['motion']=='rigid' and s['mesh_velocity']==s['boost'][:2]
boost=np.array([2.,-1.,0.]);scales=dict(rho=1.,p=.1,v=.1,B=.1,energy=1.16);results=[]
for file,t in [('initial.csv',0.),('checkpoint_0.25000000.csv',.25),('final.csv',1.)]:
 a,b=[np.genfromtxt(study/name/file,delimiter=',',names=True) for name in names];assert len(a)==len(b)==n*n;assert np.array_equal(a['id'],np.arange(n*n)) and np.array_equal(a['id'],b['id']);assert np.all(a['time']==t) and np.all(b['time']==t)
 positions=max(np.max(np.abs((b[k]-a[k]-shift*t+.5)%1-.5)) for k,shift in zip(['x','y'],boost));volume=np.max(np.abs(a['volume']-b['volume'])/a['volume']);assert positions<1e-11 and volume<1e-11
 V=a['volume'];V=V/np.sum(V);va=np.array([a[k] for k in ['vx','vy','vz']]).T;vb=np.array([b[k] for k in ['vx','vy','vz']]).T;ba=np.array([a[k] for k in ['bx','by','bz']]).T;bb=np.array([b[k] for k in ['bx','by','bz']]).T
 delta={'rho':b['rho']-a['rho'],'p':b['p']-a['p'],'v':np.linalg.norm(vb-boost-va,axis=1),'B':np.linalg.norm(bb-ba,axis=1),'energy':b['energy']-b['rho']*(vb@boost)+.5*b['rho']*(boost@boost)-a['energy']}
 norms={k:dict(L1=float(np.sum(V*np.abs(d))),L2=float(np.sqrt(np.sum(V*d*d))),Linf=float(np.max(np.abs(d)))) for k,d in delta.items()};relative={k:norms[k]['L1']/scales[k] for k in norms};maxerror=max(relative.values());results.append(dict(time=t,position_max=float(positions),relative_volume_max=float(volume),norms=norms,scales=scales,normalized_L1=relative,primary_max_L1=maxerror,pass_at_registered_tolerance=maxerror<=1e-8))
histories={name:json.loads((study/name/'history.json').read_text()) for name in names};assert all([r['time'] for r in h]==[0,.25,1] for h in histories.values());budget=max(abs(x) for h in histories.values() for row in h for x in row['diagnostics']['normalized_budget']);rho=min(row['diagnostics']['rho_min'] for h in histories.values() for row in h);pressure=min(row['diagnostics']['p_min'] for h in histories.values() for row in h)
result=dict(label='AI review of completed fixed-cap control pair only',revision=prov['revision'],n=n,metadata_input_sha256={k:sha(v) for k,v in metadata.items()},whole_study_execution_seal_present='result_sha256' in prov,verified_source_hashes=len(prov['source_sha256']),verified_raw_hashes=raw_count,raw_sha256=raw_hashes,budget_max=budget,rho_min=rho,p_min=pressure,steps={name:runs[name]['summary']['steps'] for name in names},results=results)
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['n','whole_study_execution_seal_present','verified_source_hashes','verified_raw_hashes','budget_max','steps']},indent=2));print([(r['time'],r['primary_max_L1'],r['normalized_L1']['B']) for r in results])
