
use general::{Profile,Config,Initial,Motion,Simulation};
use moving_mesh::Mesh;
use std::f64::consts::TAU;
fn main(){
 for profile in [Profile::PaperGlobalV2,Profile::BulkFrameV1,Profile::BulkFrameHllV1,Profile::BulkFrameHllQuadraticV1,Profile::BulkFrameHllConsistentV1,Profile::BulkFrameHllMatchedV1,Profile::BulkFrameHllCompactV1] {
  for motion in 0..3 {for limited in [false,true] {
   let mesh=Mesh::lattice(6,8,[1.3,0.7],0.15).unwrap();
   let cfg=Config{profile,mean_magnetic:[0.3,0.2,0.1],max_dt:0.0005,limited,motion:match motion{0=>Motion::Fixed,1=>Motion::Rigid([0.3,-0.2]),_=>Motion::Fluid},..Config::default()};
   let mut sim=Simulation::new(mesh,cfg,|x|{let xx=TAU*x[0]/1.3;let yy=TAU*x[1]/0.7;Initial{density:1.+0.01*xx.sin(),pressure:1.+0.01*yy.cos(),velocity:[0.2+0.03*yy.sin(),-0.1+0.03*xx.cos(),0.1],potential:[0.001*(xx+yy).sin(),0.002*(xx-yy).cos(),0.003*xx.sin()*yy.cos()],phi:0.0001*(xx+yy).cos()}}).unwrap();
   sim.advance_to(0.003).unwrap();println!("{:?},{motion},{limited}",profile);
   let state=sim.state();
   for a in &state.potential {for v in a{print!("{:016x},",v.to_bits())}}
   for v in &state.phi{print!("{:016x},",v.to_bits())}
   for q in &state.conserved{for v in q{print!("{:016x},",v.to_bits())}}
   for p in &state.mesh.generators{for v in p{print!("{:016x},",v.to_bits())}}
   for v in state.gauge_offset{print!("{:016x},",v.to_bits())}println!();
  }}
 }
}
