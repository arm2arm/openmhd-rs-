# Separate AI review: compact quarter-time checkpoint

This is interim diagnostic evidence from frozen `aae382e957e2d3e2d8534c908e550039ad815fd2`. N64 and N128 are completed, execution-hash-checked runs. N256 initial and t=0.25 snapshots were complete, finite, count/time/ID checked, stable across review reads, and locally hashed. N256 had no completed execution ledger entry or final seal at capture. No final convergence gate is inferred.

At N64/128/256, initial vector B L1 is 1.5601614e-4 / 3.9316115e-5 / 9.8390115e-6, roughly second order. Quarter-time B L1 is 1.6792470e-4 / 4.5585871e-5 / 2.1986937e-5. N128 to N256 By RMS improves 3.2641946e-5 to 8.1497918e-6, while Bz improves only 4.1488260e-5 to 2.6886229e-5 and vz only 2.7006062e-5 to 2.2890126e-5.

Weighted least-squares removal of mean and sin/cos wave fundamental leaves N256 Bz/vz residual RMS 2.6161784e-5 / 2.2602858e-5, accounting for 94.68% / 97.51% of component error energy. Of those residuals' index FFT energy, 96.26% / 93.64% lies at max(abs(kx),abs(ky)) >= N/4. Dominant pairs are (-20,-114)/(20,114). FFTs refer to persistent structured cell indices, not an exact Fourier basis on irregular physical centroids. The fundamental fits use actual centroids and volume weights. Near-roundoff component error-energy fractions are null and should not be interpreted.

The frozen actual Compact::jets derivative, built from the exact cached geometry, gives RMS curl_Gc grad_Gc(phi) at the checkpoint of 4.4870804e-4 / 9.7138565e-4 / 2.8261942e-3. It is exactly zero initially (phi=0). N256 source high-frequency energy is 96.85%; its weighted correlation with the Bz beyond-fundamental residual is +0.55246 (N128 +0.61917). This establishes a nonzero instantaneous cleaning contribution aligned with error and supports contamination as a plausible mechanism. It does not prove the accumulated error is caused uniquely by cleaning, establish a growth eigenvalue, or predict the final result. Fluid/EMF coupling, limiter and time integration also contribute. The output's source_projection_over_error_energy_per_time is only an instantaneous projection; the vz projection is a spatial comparison, not a direct cleaning source to velocity.

No solver edits, profile changes or physical evolutions were performed. No acceptance threshold was changed. The completed N64/N128 t=1 errors and the interim N256 checkpoint remain distinct.

## Reproduction

Run from `/Users/arm2arm/orca/workspaces/openmhd-rs-/M0` with the original results and frozen checkout retained:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_compact_interim_ai/analyze.py > /tmp/openmhd_compact_interim_ai/analysis.txt
/Users/arm2arm/.cargo/bin/rustc --edition=2024 -O /tmp/openmhd_compact_interim_ai/cleaning.rs -L dependency=/tmp/openmhd-m1-compact/target/release/deps --extern moving_mesh=/tmp/openmhd-m1-compact/target/release/deps/libmoving_mesh-8a2304a6321388ae.rlib -o /tmp/openmhd_compact_interim_ai/cleaning
/tmp/openmhd_compact_interim_ai/cleaning > /tmp/openmhd_compact_interim_ai/cleaning.txt
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_compact_interim_ai/cleaning_analysis.py > /tmp/openmhd_compact_interim_ai/cleaning_analysis.txt
```

`analysis.json` records per-snapshot hashes/norms/fits/spectra. `cleaning_n*_*.csv` are actual Gc differential outputs. `provenance.json` records source/library/cache hashes. `captured_runs.json` and `captured_provenance.json` preserve the interim metadata bytes. Review file hashes are in `checksums.json`.
