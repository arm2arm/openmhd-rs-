use moving_mesh::{Mesh,Derivatives,quadratic::{Compact,Quadratic}};
use std::{fmt::Write,collections::HashMap};
fn main(){for n in [64,128,256]{
 let root="/Users/arm2arm/orca/workspaces/openmhd-rs-/M0";
 let mesh=Mesh::decode_lattice(&std::fs::read_to_string(format!("{root}/results/m1_mesh_cache/unit_{n}_0.15.mesh")).unwrap(),n,n,[1.;2],0.15).unwrap();
 let linear=Derivatives::build(&mesh,false).unwrap();let quad=Quadratic::build(&mesh).unwrap();let compact=Compact::build(&mesh,&linear).unwrap();
 let gradient=|v:&[f64]|compact.jets(&linear,&quad,v).unwrap().iter().map(|j|j.gradient).collect::<Vec<_>>();
 for stage in ["initial","checkpoint_0.25000000"]{
  let csv=std::fs::read_to_string(format!("{root}/results/m1_compact_probe/n{n}/{stage}.csv")).unwrap();let mut lines=csv.lines();let columns:HashMap<_,_>=lines.next().unwrap().split(',').enumerate().map(|(i,k)|(k,i)).collect();let rows:Vec<Vec<f64>>=lines.map(|l|l.split(',').map(|v|v.parse::<f64>().unwrap()).collect()).collect();assert_eq!(rows.len(),n*n);
  for(i,r)in rows.iter().enumerate(){assert_eq!(r[columns["id"]],i as f64);for(k,s)in ["x","y"].iter().enumerate(){assert!((r[columns[s]]-mesh.cells[i].centroid[k]).abs()<1e-14);}}
  let phi:Vec<_>=rows.iter().map(|r|r[columns["phi"]]).collect();let gp=gradient(&phi);let gx=gradient(&gp.iter().map(|g|g[0]).collect::<Vec<_>>());let gy=gradient(&gp.iter().map(|g|g[1]).collect::<Vec<_>>());
  let mut output=String::from("id,curl_grad_phi,lap_phi,grad_phi_x,grad_phi_y\n");
  for i in 0..rows.len(){writeln!(&mut output,"{i},{:.17e},{:.17e},{:.17e},{:.17e}",gy[i][0]-gx[i][1],gx[i][0]+gy[i][1],gp[i][0],gp[i][1]).unwrap();}
  std::fs::write(format!("/tmp/openmhd_compact_interim_ai/cleaning_n{n}_{stage}.csv"),output).unwrap();println!("n{n} {stage} complete");
 }
}}
