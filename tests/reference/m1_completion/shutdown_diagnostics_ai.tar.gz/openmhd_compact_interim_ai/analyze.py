import hashlib,io,json,math
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');base=root/'results/m1_compact_probe';out=Path('/tmp/openmhd_compact_interim_ai')
sha=lambda b:hashlib.sha256(b).hexdigest()
provraw=(base/'provenance.json').read_bytes();runraw=(base/'runs.json').read_bytes();prov=json.loads(provraw);runs=json.loads(runraw)
assert prov['revision']=='aae382e957e2d3e2d8534c908e550039ad815fd2'
(out/'captured_provenance.json').write_bytes(provraw);(out/'captured_runs.json').write_bytes(runraw)
result={'scope':'Interim checkpoint diagnostic; N256 has no completed execution seal, no final convergence gate interpreted','revision':prov['revision'],'captured_metadata_sha256':{'provenance.json':sha(provraw),'runs.json':sha(runraw)},'cases':{}}
for n in [64,128,256]:
 stages={}
 for stage,t in [('initial',0.),('checkpoint_0.25000000',.25)]+([('final',1.)] if n<256 else []):
  p=base/f'n{n}'/(stage+'.csv');raw=p.read_bytes();digest=sha(raw)
  if n<256:assert digest==runs[f'n{n}']['sha256'][p.name]
  a=np.genfromtxt(io.BytesIO(raw),delimiter=',',names=True);assert len(a)==n*n and np.array_equal(a['id'],np.arange(n*n)) and (a['time']==t).all() and (a['volume']>0).all() and all(np.isfinite(a[k]).all() for k in a.dtype.names)
  w=a['volume']/np.sum(a['volume']);phase=2*np.pi*(a['x']+t);X=np.column_stack([np.ones(len(a)),np.sin(phase),np.cos(phase)])
  exact={'bx':np.ones(len(a)),'by':.1*np.sin(phase),'bz':.1*np.cos(phase),'vx':np.zeros(len(a)),'vy':.1*np.sin(phase),'vz':.1*np.cos(phase),'rho':np.ones(len(a)),'p':np.full(len(a),.1)}
  norm=lambda v:dict(L1=float(np.sum(w*abs(v))),RMS=float(np.sqrt(np.sum(w*v*v))),max=float(np.max(abs(v))))
  err={k:a[k]-v for k,v in exact.items()};fits={}
  freq=np.rint(np.fft.fftfreq(n)*n).astype(int);kx,ky=np.meshgrid(freq,freq);high=np.maximum(abs(kx),abs(ky))>=n/4
  for k in [*exact,'phi','div_a']:
   coeff=np.linalg.lstsq(X*np.sqrt(w[:,None]),a[k]*np.sqrt(w),rcond=None)[0];rem=a[k]-np.sum(X*coeff,axis=1);power=abs(np.fft.fft2(rem.reshape(n,n)))**2;total=float(np.sum(power));inds=np.argsort(power.ravel())[-4:][::-1]
   fits[k]={'coeff_const_sin_cos':coeff.tolist(),'beyond_fundamental':norm(rem),'high_frequency_residual_energy_fraction':float(np.sum(power[high])/total) if total else 0.,'largest_residual_index_modes':[[int(kx.ravel()[i]),int(ky.ravel()[i]),float(power.ravel()[i]/total)] for i in inds] if total else []}
   if k in err:fits[k]['error_energy_fraction_beyond_fundamental']=(float(np.sum(w*rem*rem)/np.sum(w*err[k]**2)) if np.sqrt(np.sum(w*err[k]**2))>1e-14 else None)
  stages[stage]={'time':t,'sha256':digest,'sealed_execution':n<256,'errors':{k:norm(v) for k,v in err.items()},'B':norm(np.sqrt(sum(err[k]**2 for k in ['bx','by','bz']))),'fits':fits,'phi':norm(a['phi']),'div_a':norm(a['div_a'])}
  assert p.read_bytes()==raw,'Snapshot changed during read/review'
  print(n,stage,'B_L1',stages[stage]['B']['L1'],'RMS', {k:float(f'{v["RMS"]:.8g}') for k,v in stages[stage]['errors'].items()},flush=True)
  print('noise', {k:{'RMS':float(f'{fits[k]["beyond_fundamental"]["RMS"]:.8g}'),'fraction':fits[k].get('error_energy_fraction_beyond_fundamental'),'high':float(f'{fits[k]["high_frequency_residual_energy_fraction"]:.6g}'),'peaks':fits[k]['largest_residual_index_modes'][:2]} for k in ['by','bz','vz','rho','phi']},flush=True)
 result['cases'][str(n)]=stages
(out/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
