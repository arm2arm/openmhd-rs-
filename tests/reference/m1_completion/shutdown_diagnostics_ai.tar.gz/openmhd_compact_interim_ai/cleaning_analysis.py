import json
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');out=Path('/tmp/openmhd_compact_interim_ai');result={}
for n in [64,128,256]:
 rec={}
 for stage,t in [('initial',0.),('checkpoint_0.25000000',.25)]:
  a=np.genfromtxt(root/f'results/m1_compact_probe/n{n}/{stage}.csv',delimiter=',',names=True);d=np.genfromtxt(out/f'cleaning_n{n}_{stage}.csv',delimiter=',',names=True);assert np.array_equal(a['id'],d['id']);w=a['volume']/sum(a['volume']);phase=2*np.pi*(a['x']+t);X=np.column_stack([np.ones(len(a)),np.sin(phase),np.cos(phase)])
  norm=lambda v:dict(L1=float(np.sum(w*abs(v))),RMS=float(np.sqrt(np.sum(w*v*v))),max=float(np.max(abs(v))))
  c=d['curl_grad_phi'];lap=d['lap_phi'];freq=np.rint(np.fft.fftfreq(n)*n).astype(int);kx,ky=np.meshgrid(freq,freq);high=np.maximum(abs(kx),abs(ky))>=n/4;power=abs(np.fft.fft2(c.reshape(n,n)))**2;total=float(np.sum(power));inds=np.argsort(power.ravel())[-8:][::-1]
  entry={'curl_grad_phi':norm(c),'lap_phi':norm(lap),'grad_phi':norm(np.hypot(d['grad_phi_x'],d['grad_phi_y'])),'high_frequency_energy_fraction':float(np.sum(power[high])/total) if total else 0.,'largest_index_modes':[[int(kx.ravel()[i]),int(ky.ravel()[i]),float(power.ravel()[i]/total)] for i in inds] if total else [],'instantaneous_source_projection':{}}
  for k in ['bz','vz']:
   coeff=np.linalg.lstsq(X*np.sqrt(w[:,None]),a[k]*np.sqrt(w),rcond=None)[0];rem=a[k]-np.sum(X*coeff,axis=1);den=float(np.sum(w*rem*rem));corr=float(np.sum(w*rem*c)/np.sqrt(max(1e-99,den*np.sum(w*c*c))))
   entry['instantaneous_source_projection'][k]={'correlation_with_beyond_fundamental':corr,'source_projection_over_error_energy_per_time':float(np.sum(w*rem*c)/max(1e-99,den))}
  rec[stage]=entry
  print(n,stage,json.dumps(entry),flush=True)
 result[str(n)]=rec
(out/'cleaning_analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
