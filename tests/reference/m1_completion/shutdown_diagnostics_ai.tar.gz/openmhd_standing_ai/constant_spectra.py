from pathlib import Path
import json
import numpy as np
out=Path('/tmp/openmhd_standing_ai');results={};n=8;nc=n*n
for j in [0,.15]:
 for speed in [0,1]:
  for clean in ['false','true']:
   key=f'j{j}_v{speed}_clean{clean}';recs=[];mat=[]
   for eps in ['0.000001','0.0000001']:
    a=np.loadtxt(out/f'constant_n8_j{j}_v{speed}_clean{clean}_e{eps}.csv',delimiter=',');e,v=np.linalg.eig(a);idx=int(np.argmax(e.real));lam=e[idx];vec=v[:,idx];res=float(np.linalg.norm(np.einsum('ij,j->i',a,vec,optimize=False)-lam*vec)/np.linalg.norm(vec));modes={}
    for k,name in enumerate(['Ax','Ay','vz','phi']):
     P=abs(np.fft.fft2(vec[k*nc:(k+1)*nc].reshape(n,n)))**2;inds=np.argsort(P.ravel())[-4:][::-1];freq=np.rint(np.fft.fftfreq(n)*n).astype(int);modes[name]=[[int(freq[i%n]),int(freq[i//n]),float(P.ravel()[i]/max(1e-99,np.sum(P)))] for i in inds]
    recs.append({'epsilon':float(eps),'max_real':float(lam.real),'imag_at_max':float(lam.imag),'positive_above_1e-7':int(sum(e.real>1e-7)),'eigenpair_residual':res,'dominant_index_modes':modes});mat.append(a)
   results[key]={'eigenvalues':recs,'matrix_epsilon_max_difference':float(np.max(abs(mat[0]-mat[1])))};print(key,json.dumps(results[key]),flush=True)
(out/'constant_spectra.json').write_text(json.dumps(results,indent=2)+'\n')
