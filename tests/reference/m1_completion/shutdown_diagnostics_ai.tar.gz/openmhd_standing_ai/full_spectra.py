from pathlib import Path
import json
import numpy as np
out=Path('/tmp/openmhd_standing_ai');results={}
for v in [0,1]:
 for limited in ['false','true']:
  mats={};records={}
  for kind in ['rate','step']:
   rec=[];mats[kind]=[]
   for eps in ['0.000001','0.0000001']:
    key=f'full_{kind}_n8_v{v}_limited{limited}_e{eps}';a=np.loadtxt(out/(key+'.csv'),delimiter=',');e,z=np.linalg.eig(a);idx=np.argmax(e.real if kind=='rate' else abs(e));lam=e[idx];vec=z[:,idx];res=float(np.linalg.norm(np.einsum('ij,j->i',a,vec,optimize=False)-lam*vec)/np.linalg.norm(vec));record={'epsilon':float(eps),'real':float(lam.real),'imag':float(lam.imag),'max_modulus':float(abs(e).max()),'positive_or_growing_count':int(sum(e.real>1e-6)) if kind=='rate' else int(sum(abs(e)>1+1e-8)),'eigenpair_residual':res};rec.append(record);mats[kind].append(a)
    if eps=='0.0000001':np.savetxt(out/(key+'_mode.csv'),np.column_stack([vec.real,vec.imag]),delimiter=',',fmt='%.17e')
   records[kind]={'eigenvalues':rec,'matrix_epsilon_max_difference':float(np.max(abs(mats[kind][0]-mats[kind][1])))}
  results[f'v{v}_limited{limited}']=records;print(v,limited,json.dumps(records),flush=True)
(out/'full_spectra.json').write_text(json.dumps(results,indent=2)+'\n')
