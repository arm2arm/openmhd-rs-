from pathlib import Path
import subprocess
root=Path('/tmp/openmhd-m1-compact');out=Path('/tmp/openmhd_standing_ai');text=''
for name in ['auxiliary','gauge','operators','general']:
 code=(root/f'crates/mhd-vector-pot/src/{name}.rs').read_text().replace('//!','//')
 if name=='general':code+='\n'+(out/'full_probe_extra.rs').read_text()
 text+='mod '+name+' {\n'+code+'\n}\n'
text+='fn main(){ if std::env::args().nth(1).as_deref()==Some("jac"){general::review_jac()}else{general::review_pairs()} }\n';(out/'full_probe.rs').write_text(text);deps=root/'target/release/deps';cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-Awarnings','-O',str(out/'full_probe.rs'),'-L','dependency='+str(deps)]
for name in ['moving_mesh','mhd_core']:cmd+=['--extern',name+'='+str(next(deps.glob('lib'+name+'-*.rlib')))]
cmd+=['-o',str(out/'full_probe')];subprocess.run(cmd,cwd=root,check=True)
