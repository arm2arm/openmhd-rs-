# Separate AI diagnostic handoff — stopped for laptop shutdown

No reviewer processes remain active. All four authorized fixed-cap controls and all small matrix/one-step probes listed below completed. The proposed eigenvector directional-validation and full-HLL follow-ups were **not started**, because the user requested shutdown. Do not interpret that absence as a failed solver run.

The unchanged compact execution is frozen at `aae382e957e2d3e2d8534c908e550039ad815fd2`. Quick 48 original runs and bounded four-resolution wave evidence were hash-checked at shutdown. `shutdown_check.json` records exact counts and failures. The N256 final B L1 is 3.9976262161483235e-5; finest-three order is 1.6401593659, below 1.8. Quick wave boosts pass 14/16, with regular standing fixed N32/N64 failures. Eight loop boosts pass. No M1 acceptance is given.

## Completed fixed-cap controls

`run_controls.py` uses the original frozen binary and profile, no numerical modifications: regular standing fixed-family base/boost pairs, N32 dt=.0002 and N64 dt=.0001, t=1 with checkpoint .25. Full exact commands and binary/source/cache hashes are in controls/{manifest,provenance}.json; run outcomes, summary counters and raw artifact hashes are in controls/runs.json. The controls are separate diagnostics, not replacements for registered adaptive failures or threshold changes.

N32 base/boost both take 5001 steps; N64 both take 10002 steps. Every control has zero CFL/state rejection. Tiny final target-clipping steps occur identically in paired runs. Both controls still fail the 1e-8 boost tolerance: N32 final maximum normalized L1 7.99255e-6 (B 6.67188e-6); N64 5.84084e-6 (B 5.63245e-6). Thus adaptive retry branching is not necessary for failure. Physical differences are dominated by Bz/vz. `adaptive_analysis.json` and `controls_analysis.json` preserve initial/quarter/final component norms and spectra. Differences begin at roundoff and already exceed the boost gate by t=.25.

## Completed operator probes and limits

`constant_operator.rs` uses actual frozen compact derivatives, quadratic point-A advection, frozen fluid/induction flux and symmetric-HLL A completion. It extends the earlier uniform-background subsystem to v_parallel=1. At 8² regular/jitter .15, no large robust growing mode was found for v_parallel=1; small near-zero eigenvalues must not be overinterpreted. This does not settle the finite circular wave.

`build_full_probe.py` embeds exact frozen auxiliary/gauge/operators/general sources and appends instrumentation only in /tmp. The production solver and repository were untouched. `full_probe_extra.rs` performs actual prepare/trial calls. Initial finite-amplitude standing waves at N8/16/32/64 are boost covariant to roundoff for limited/unlimited modes and dt=.0002/.0001/.00001: maximum prepared potential-rate difference <=4.1e-16; one-step conserved-density difference <=1.8e-15. This rules out a large initial transformation defect in those checks.

The full finite-wave probe samples all nine per-cell variables (five conservative densities, three reduced potentials, phi) at 8², parallel speeds 0/1, limited/unlimited reconstruction, eps1e-6/1e-7. It records the instantaneous rate matrix and actual endpoint-map matrix for dt=.0001. Limited standing-wave matrices indicate a max real rate eigenvalue about +6.5874 and endpoint spectral radius 1.00071139; unlimited standing matrices show only small epsilon-sensitive near-zero modes. Limited travelling-wave matrices also show local growth (~4.1423). **These are preliminary coordinate finite-difference indications. Limiters have nondifferentiable ties at the background; a matrix eigenvalue is not yet a verified perturbation growth mode. The background is also not an exact discrete stationary solution.** No instability proof or unique explanation of N32/N64 errors is claimed.

## Exact next diagnostic after reboot

First validate extracted finite-wave eigenvectors with actual positive/negative directional perturbations, comparing rate and endpoint responses against the coordinate matrices over multiple small amplitudes. If the growth indication survives this check, apply the requested full two-wave HLL conservative/induction flux as a **small operator-only control**, retaining existing reconstruction and symmetric completion, to test whether the stationary Alfvén characteristic and mismatched fluid/potential transport lack adequate damping. No full-HLL control has been run, no new profile has been proposed for acceptance, and no solver implementation is authorized by this review. Preserve all current failed evidence. Frozen-C1 temporal error and other coupled mechanisms remain alternatives; do not infer causality from the matrices alone.

## Commands and artifacts

- Physical controls: `python3 /tmp/openmhd_standing_ai/run_controls.py` (requires a fresh controls destination; this would rerun four already completed controls).
- Analysis: `OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_standing_ai/adaptive_analysis.py`; add `--controls` for controls.
- Full operator build: `python3 /tmp/openmhd_standing_ai/build_full_probe.py`; run `full_probe` for pairs or `full_probe jac` for matrices.
- Spectrum analysis: run `constant_spectra.py` and `full_spectra.py` with the same single-BLAS-thread Python environment.
- `full_pairs.txt`, `full_jac.txt`, `*_spectra.json`, mode CSVs, raw matrices, logs and control snapshots are preserved. `provenance.json` and `checksums.json` record source/library and artifact hashes. Binaries can be omitted from archival with hashes retained; raw control CSVs may remain local with seals if archive size requires it.

Review approval remains limited to previously completed implementation/evidence/report checks. The current compact algorithm fails accuracy/invariance gates; M1 remains open.
