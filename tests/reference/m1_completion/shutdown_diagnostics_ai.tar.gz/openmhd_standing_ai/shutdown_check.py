from pathlib import Path
import hashlib,json,math
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');out=Path('/tmp/openmhd_standing_ai');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={}
for name in ['m1_compact_probe','m1_compact_quick']:
 p=root/'results'/name;prov=json.loads((p/'provenance.json').read_text());runs=json.loads((p/'runs.json').read_text())
 for file,h in prov['result_sha256'].items():
  path=p/('execution_summary.json' if file=='summary.json' and (p/'execution_summary.json').exists() else file);assert sha(path)==h,(name,file)
 count=0
 for case,r in runs.items():
  assert r['status']=='completed' and r.get('exit_code',r.get('returncode'))==0
  for file,h in r.get('sha256',r.get('artifacts_sha256')).items():assert sha(p/case/file)==h,(name,case,file);count+=1
 if name=='m1_compact_probe':
  assert set(runs)=={'n32','n64','n128','n256'};es=[runs[f'n{n}']['final_error']['B']['L1'] for n in [64,128,256]];order=math.log(es[0]/es[-1])/math.log(4);result[name]={'completed':len(runs),'raw_artifact_hashes':count,'N256_B_L1':es[-1],'finest_three_order':order,'order_gate':'FAIL'}
 else:
  assert len(runs)==48;summary=json.loads((p/'summary.json').read_text());pairs=[v for v in summary['pairs'] if v['case']=='alfven'];loops=[v for v in summary['pairs'] if v['case']=='loop'];passed=sum(max(v['relative_L1']['wave_amplitude'].values())<=1e-8 and v['positive_and_conservative'] and v['pairing_valid'] for v in pairs);result[name]={'completed':48,'raw_artifact_hashes':count,'alfven_pairs':len(pairs),'alfven_primary_pass':passed,'alfven_primary_fail':len(pairs)-passed,'loop_pairs':len(loops),'loop_pass':sum(v['status']=='pass' for v in loops)}
print(json.dumps(result,indent=2));(out/'shutdown_check.json').write_text(json.dumps(result,indent=2)+'\n')
