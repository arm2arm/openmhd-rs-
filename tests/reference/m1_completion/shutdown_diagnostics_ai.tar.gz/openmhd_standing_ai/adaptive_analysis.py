from pathlib import Path
import hashlib,json,io,sys
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');control='--controls' in sys.argv;base=Path('/tmp/openmhd_standing_ai/controls') if control else root/'results/m1_compact_quick';out=Path('/tmp/openmhd_standing_ai');stem='controls' if control else 'adaptive';sha=lambda b:hashlib.sha256(b).hexdigest();provraw=(base/'provenance.json').read_bytes();runraw=(base/'runs.json').read_bytes();prov=json.loads(provraw);runs=json.loads(runraw)
for file,h in prov.get('result_sha256',{}).items():
 path=base/('execution_summary.json' if file=='summary.json' and (base/'execution_summary.json').exists() else file);assert sha(path.read_bytes())==h,(file,'seal')
(out/(stem+'_provenance.json')).write_bytes(provraw);(out/(stem+'_runs.json')).write_bytes(runraw);result={}
for n in [32,64]:
 prefix=f'n{n}_' if control else f'alfven_bulk-frame-hll-compact-v1_v1.0_j0.0_fixed_n{n}_'
 if any(prefix+side not in runs for side in ['base','boost']):continue
 r={side:runs[prefix+side] for side in ['base','boost']};rec={'metadata':{side:{k:r[side]['summary'][k] for k in ['steps','dt_min','dt_max','rejected_cfl','rejected_state','hll_fallbacks','hll_fallbacks_attempted']} for side in r},'stages':{}}
 for stage,t in [('initial',0.),('checkpoint_0.25000000',.25),('final',1.)]:
  arrays={};digests={}
  for side in r:
   p=base/(prefix+side)/(stage+'.csv');raw=p.read_bytes();assert sha(raw)==r[side]['sha256'][p.name];a=np.genfromtxt(io.BytesIO(raw),delimiter=',',names=True);assert len(a)==n*n and np.array_equal(a['id'],np.arange(n*n)) and (a['time']==t).all();arrays[side]=a;digests[side]=sha(raw)
  a,b=arrays['base'],arrays['boost'];w=a['volume']/np.sum(a['volume']);norm=lambda v:dict(L1=float(np.sum(w*abs(v))),RMS=float(np.sqrt(np.sum(w*v*v))),max=float(np.max(abs(v))))
  errors={k:b[k]-a[k]-shift for k,shift in [('rho',0),('p',0),('vx',2),('vy',-1),('vz',0),('bx',0),('by',0),('bz',0)]};errors['energy']=b['energy']-b['rho']*(2*b['vx']-b['vy'])+2.5*b['rho']-a['energy'];errors['B']=np.sqrt(sum(errors[k]**2 for k in ['bx','by','bz']));errors['v']=np.sqrt(sum(errors[k]**2 for k in ['vx','vy','vz']));X=np.column_stack([np.ones(len(a)),np.sin(2*np.pi*a['x']),np.cos(2*np.pi*a['x'])]);fits={};freq=np.rint(np.fft.fftfreq(n)*n).astype(int);kx,ky=np.meshgrid(freq,freq)
  for k in ['rho','p','by','bz','vy','vz']:
   v=errors[k];c=np.linalg.lstsq(X*np.sqrt(w[:,None]),v*np.sqrt(w),rcond=None)[0];rem=v-np.sum(X*c,axis=1);P=abs(np.fft.fft2(v.reshape(n,n)))**2;total=float(np.sum(P));inds=np.argsort(P.ravel())[-6:][::-1];fits[k]={'coeff_const_sin_cos':c.tolist(),'beyond_fundamental_RMS':norm(rem)['RMS'],'transverse_y_energy_fraction':float(np.sum(P[ky!=0])/total) if total else 0.,'largest_index_modes':[[int(kx.ravel()[i]),int(ky.ravel()[i]),float(P.ravel()[i]/total)] for i in inds] if total else []}
  physical={}
  for side,c in arrays.items():
   shift=2*t if side=='boost' else 0;phase=2*np.pi*(c['x']-shift);exact={'bx':1.,'by':.1*np.sin(phase),'bz':.1*np.cos(phase),'vx':3. if side=='boost' else 1.,'vy':.1*np.sin(phase)+(-1. if side=='boost' else 0.),'vz':.1*np.cos(phase),'rho':1.,'p':.1};d={k:c[k]-v for k,v in exact.items()};physical[side]={k:norm(v) for k,v in d.items()};physical[side]['B']=norm(np.sqrt(sum(d[k]**2 for k in ['bx','by','bz'])))
  entry={'time':t,'raw_sha256':digests,'pair_errors':{k:norm(v) for k,v in errors.items()},'largest_normalized_L1':max(norm(errors[k])['L1']/scale for k,scale in [('rho',1),('p',.1),('energy',1.16),('B',.1),('v',.1)]),'fits':fits,'physical_errors':physical,'position_max':max(float(np.max(abs((b[k]-a[k]-sh*t+.5)%1-.5))) for k,sh in [('x',2),('y',-1)]),'relative_volume_max':float(np.max(abs(b['volume']-a['volume'])/a['volume']))};rec['stages'][stage]=entry
  print(n,stage,'normalized boost',entry['largest_normalized_L1'],'B/v L1',entry['pair_errors']['B']['L1'],entry['pair_errors']['v']['L1'],'component RMS',{k:entry['pair_errors'][k]['RMS'] for k in ['rho','p','by','bz','vy','vz']},flush=True);print('peaks',{k:fits[k]['largest_index_modes'][:2] for k in ['by','bz','vy','vz']},flush=True)
 result[str(n)]=rec
(out/(stem+'_analysis.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
