use moving_mesh::{Mesh,Derivatives};
use std::{collections::BTreeSet,fmt::Write};
fn main(){for n in [4,8,16]{for jitter in [0.,0.15,0.25]{
let mesh=Mesh::lattice(n,n,[1.;2],jitter).unwrap();let lin=Derivatives::build(&mesh,false).unwrap();let prefix=format!("/tmp/openmhd_cubic_design_ai/n{n}_j{jitter}");
let mut direct=String::from("cell,index,dx,dy,wx,wy\n");let mut samples=String::from("cell,index,dx,dy\n");let mut cells=String::from("cell,x,y,volume\n");
for(i,c)in mesh.cells.iter().enumerate(){writeln!(&mut cells,"{i},{:.17e},{:.17e},{:.17e}",c.centroid[0],c.centroid[1],c.volume).unwrap();
for ((f,_),s)in c.faces.iter().zip(&lin.samples[i]){let(j,d)=mesh.neighbour(&mesh.faces[*f],i);assert_eq!(j,s.index);writeln!(&mut direct,"{i},{j},{:.17e},{:.17e},{:.17e},{:.17e}",d[0],d[1],s.weight[0],s.weight[1]).unwrap();}
let mut ids=BTreeSet::new();for &(f,_)in &c.faces{let face=&mesh.faces[f];let(j,_)=mesh.neighbour(face,i);let sign=if face.left==i{1}else{-1};let image=face.image.map(|x|sign*x);ids.insert((j,image));for &(g,_)in &mesh.cells[j].faces{let other=&mesh.faces[g];let(k,_)=mesh.neighbour(other,j);let s=if other.left==j{1}else{-1};ids.insert((k,[image[0]+s*other.image[0],image[1]+s*other.image[1]]));}}
ids.remove(&(i,[0,0]));for(j,im)in ids{let d:[f64;2]=std::array::from_fn(|k|mesh.cells[j].centroid[k]-c.centroid[k]+f64::from(im[k])*mesh.lengths[k]);writeln!(&mut samples,"{i},{j},{:.17e},{:.17e}",d[0],d[1]).unwrap();}}
std::fs::write(format!("{prefix}_direct.csv"),direct).unwrap();std::fs::write(format!("{prefix}_samples.csv"),samples).unwrap();std::fs::write(format!("{prefix}_cells.csv"),cells).unwrap();println!("n{n} j{jitter}");
}}}
