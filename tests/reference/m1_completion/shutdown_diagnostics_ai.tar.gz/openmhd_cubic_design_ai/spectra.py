from pathlib import Path
import json
import numpy as np
out=Path('/tmp/openmhd_cubic_design_ai');results={}
for j in [0,0.15,0.25]:
 for kind in ['Q','C','D']:
  for clean in ['false','true']:
   key=f'{kind}_j{j}_clean{clean}';recs=[];mats=[]
   for eps in ['0.000001','0.0000001']:
    a=np.loadtxt(out/f'alfven_{kind}_n8_j{j}_clean{clean}_e{eps}.csv',delimiter=',');e,v=np.linalg.eig(a);idx=int(np.argmax(e.real));vec=v[:,idx];lam=e[idx];res=float(np.linalg.norm(np.einsum('ij,j->i',a,vec,optimize=False)-lam*vec)/np.linalg.norm(vec));mats.append(a)
    rec={'eps':float(eps),'max_real':float(lam.real),'imag_at_max':float(lam.imag),'positive_above_1e-7':int(np.sum(e.real>1e-7)),'largest_eigenpair_residual':res};recs.append(rec)
   results[key]={'eigenvalues':recs,'matrix_epsilon_max_difference':float(np.max(abs(mats[0]-mats[1])))};print(key,json.dumps(results[key]),flush=True)
# Cleaning-only system using cubic matrices and actual cell radii.
cleanresults={}
for n in [8,16]:
 for j in [0,0.15,0.25]:
  key=f'n{n}_j{j}';nc=n*n;gx=np.loadtxt(out/f'{key}_C3_x.csv',delimiter=',');gy=np.loadtxt(out/f'{key}_C3_y.csv',delimiter=',');c=np.genfromtxt(out/f'{key}_cells.csv',delimiter=',',names=True);lam=.15*np.sqrt(1/6)/np.sqrt(c['volume']/np.pi);A=np.zeros((3*nc,3*nc));A[:nc,2*nc:]=gx;A[nc:2*nc,2*nc:]=gy;A[2*nc:,:nc]=gx/6;A[2*nc:,nc:2*nc]=gy/6;A[2*nc:,2*nc:]=-np.diag(lam);e=np.linalg.eigvals(A);cleanresults[key]={'max_real':float(np.max(e.real)),'positive_above_1e-8':int(sum(e.real>1e-8))};print('cleaning-only',key,json.dumps(cleanresults[key]),flush=True)
(out/'spectra.json').write_text(json.dumps({'coupled':results,'cleaning_only':cleanresults},indent=2,allow_nan=False)+'\n')
