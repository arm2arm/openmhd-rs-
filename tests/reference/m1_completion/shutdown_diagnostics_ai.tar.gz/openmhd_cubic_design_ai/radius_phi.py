import json
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');out=Path('/tmp/openmhd_cubic_design_ai');results={}
for n in [64,128,256]:
 a=np.genfromtxt(root/f'results/m1_compact_probe/n{n}/checkpoint_0.25000000.csv',delimiter=',',names=True);w=a['volume']/np.sum(a['volume']);r=np.sqrt(a['volume']/np.pi);cs=np.sqrt((5/3)*a['p']/a['rho']);tau=r/(.15*cs);recs={}
 rms=lambda v:float(np.sqrt(np.sum(w*v*v)))
 corr=lambda a,b:float(np.sum(w*a*b)/np.sqrt(max(1e-99,np.sum(w*a*a)*np.sum(w*b*b))))
 for cutoff in [4,8]:
  x=a['x'];X=np.column_stack([np.ones(len(a))]+[fun(2*np.pi*k*x) for k in range(1,cutoff+1) for fun in [np.sin,np.cos]])
  def smooth(v):
   c=np.linalg.lstsq(X*np.sqrt(w[:,None]),v*np.sqrt(w),rcond=None)[0];return np.sum(X*c,axis=1)
  phis=smooth(a['phi']);pr=a['phi']-phis;rs=smooth(r);taus=smooth(tau);sources=cs*cs*a['div_a'];ss=smooth(sources);taucs=cs*cs*tau;tc_s=smooth(taucs)
  models={'radius_modulated_phi':phis*(r/rs-1),'tau_modulated_phi':phis*(tau/taus-1),'radius_quasistatic_source':ss*(tau-taus),'tau_cs2_divA_quasistatic':(taucs-tc_s)*smooth(a['div_a'])}
  recs[str(cutoff)]={'smooth_phi_RMS':rms(phis),'residual_phi_RMS':rms(pr),'relative_radius_residual_RMS':rms(r/rs-1),'relative_tau_residual_RMS':rms(tau/taus-1),'tau_mean':float(np.sum(w*tau)),'divA_RMS':rms(a['div_a']),'smooth_divA_RMS':rms(smooth(a['div_a'])),'models':{k:{'RMS':rms(v),'correlation_phi_residual':corr(pr,v),'least_squares_multiplier':float(np.sum(w*pr*v)/np.sum(w*v*v))} for k,v in models.items()}}
 results[str(n)]=recs;print(n,json.dumps(recs),flush=True)
(out/'radius_phi.json').write_text(json.dumps(results,indent=2)+'\n')
