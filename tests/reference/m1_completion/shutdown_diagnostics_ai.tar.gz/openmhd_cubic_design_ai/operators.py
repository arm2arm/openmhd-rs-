import json
from pathlib import Path
import numpy as np
out=Path('/tmp/openmhd_cubic_design_ai')
mm=lambda a,b:np.einsum('ik,kj->ij',a,b,optimize=False)
def basis(d,degree):
 x,y=d.T;a=[np.ones(len(x)),x,y,x*x/2,y*y/2,x*y]
 if degree==3:a.extend([x*x*x/6,y*y*y/6,x*x*y/2,x*y*y/2])
 return np.column_stack(a)
def coefficients(d,h,degree):
 r=np.linalg.norm(d/h,axis=1);root=1/np.sqrt(r);A=basis(d/h,degree)*root[:,None];u,s,vt=np.linalg.svd(A,full_matrices=False);assert s[-1]>s[0]*1e-10
 pinv=mm(vt.T/s,u.T)*root[None,:];scale=np.array([0,1,1,2,2,2]+([3]*4 if degree==3 else []));return pinv/h**scale[:,None],float(s[0]/s[-1]),float(s[-1]),int(sum(s>s[0]*1e-10))
results={}
for n in [4,8,16]:
 for jitter in [0,0.15,0.25]:
  key=f'n{n}_j{jitter}';cells=np.genfromtxt(out/(key+'_cells.csv'),delimiter=',',names=True);direct=np.genfromtxt(out/(key+'_direct.csv'),delimiter=',',names=True);samples=np.genfromtxt(out/(key+'_samples.csv'),delimiter=',',names=True);nc=n*n
  Ds={k:np.zeros((2,nc,nc)) for k in ['L','Q','C2','C3']};counts=[];conditions=[];rankmin=10;polymax=0.;smin=[]
  for i in range(nc):
   ds=direct[direct['cell']==i];qs=samples[samples['cell']==i];d=np.column_stack([ds['dx'],ds['dy']]);q=np.column_stack([qs['dx'],qs['dy']]);ids=ds['index'].astype(int);qids=qs['index'].astype(int);w=np.column_stack([ds['wx'],ds['wy']]);h=np.sqrt(cells['volume'][i]);p2,_,_,_=coefficients(q,h,2);p3,cond,sing,rank=coefficients(q,h,3);counts.append(len(q));conditions.append(cond);rankmin=min(rankmin,rank);smin.append(sing)
   dp=basis(d,3);qp=basis(q,3);m2=np.einsum('jk,jl->kl',w,dp[:,3:6]-dp[0,3:6],optimize=False);m3=np.einsum('jk,jl->kl',w,dp[:,3:]-dp[0,3:],optimize=False)
   expected=np.zeros((2,10));expected[0,1]=1.;expected[1,2]=1.
   poly=mm(w.T,dp-dp[0])-mm(mm(m3,p3[3:]),qp-qp[0]);polymax=max(polymax,float(np.max(abs(poly-expected))))
   for axis in [0,1]:
    np.add.at(Ds['L'][axis,i],ids,w[:,axis]);Ds['L'][axis,i,ids[0]]-=sum(w[:,axis]);Ds['Q'][axis,i,qids[0]]-=sum(p2[axis+1]);np.add.at(Ds['Q'][axis,i],qids,p2[axis+1]);Ds['C2'][axis,i]=Ds['L'][axis,i];Ds['C3'][axis,i]=Ds['L'][axis,i]
    for kind,m,p in [('C2',m2,p2),('C3',m3,p3)]:
     correction=np.einsum('k,kj->j',m[axis],p[3:],optimize=False);np.add.at(Ds[kind][axis,i],qids,-correction);Ds[kind][axis,i,qids[0]]+=sum(correction)
  rec={'sample_count_min_max':[min(counts),max(counts)],'cubic_rank_min':rankmin,'cubic_SVD_condition_min_max':[min(conditions),max(conditions)],'cubic_min_singular':min(smin),'local_cubic_polynomial_identity_max':polymax,'operators':{}}
  if jitter==0:
   expected=np.zeros_like(Ds['C3']);h=1/n
   for y in range(n):
    for x in range(n):
     i=y*n+x
     for axis in [0,1]:
      for shift,value in [(-2,1),(-1,-8),(1,8),(2,-1)]:
       j=(y*n+(x+shift)%n) if axis==0 else ((y+shift)%n*n+x);expected[axis,i,j]+=value/(12*h)
   rec['regular_fourth_order_central_max_difference']=float(np.max(abs(expected-Ds['C3'])))
  for kind,D in Ds.items():
   gx,gy=D;lap=mm(gx,gx)+mm(gy,gy);curl=mm(gx,gy)-mm(gy,gx);e=np.linalg.eigvals(lap);rec['operators'][kind]={'lap_max_eigen_real':float(np.max(e.real)),'lap_positive_count_above_1e-8':int(sum(e.real>1e-8)),'curl_grad_infinity_norm':float(np.max(np.sum(abs(curl),axis=1))),'constant_gradient_max':float(np.max(abs(np.sum(D,axis=2))))}
   weights=cells['volume']/np.sum(cells['volume']);x=cells['x'];f=np.sin(2*np.pi*x);exact_x=2*np.pi*np.cos(2*np.pi*x);g=np.einsum('kij,j->ki',D,f,optimize=False);smooth_curl=np.einsum('ij,j->i',curl,f,optimize=False);radius=np.sqrt(cells['volume']/np.pi);rough=(radius/(1/n/np.sqrt(np.pi))-1)*f/n;rough_curl=np.einsum('ij,j->i',curl,rough,optimize=False)
   rec['operators'][kind]['smooth_sine_gradient_RMS']=float(np.sqrt(np.sum(weights*((g[0]-exact_x)**2+g[1]**2))))
   rec['operators'][kind]['smooth_sine_curl_gradient_RMS']=float(np.sqrt(np.sum(weights*smooth_curl*smooth_curl)))
   rec['operators'][kind]['h_radius_modulated_sine_curl_gradient_RMS']=float(np.sqrt(np.sum(weights*rough_curl*rough_curl)))
   if kind=='C3' and n>=8:
    for axis,G in zip(['x','y'],D):np.savetxt(out/f'{key}_C3_{axis}.csv',G,delimiter=',',fmt='%.17e')
  results[key]=rec;print(key,json.dumps(rec),flush=True)
(out/'operators.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
