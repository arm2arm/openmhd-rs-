import os,subprocess,sys
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path('/tmp/openmhd-m1-compact');deps=root/'target/release/deps';env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'}
def python(script):
 with (out/(script+'.txt')).open('w') as f:subprocess.run([sys.executable,str(out/(script+'.py'))],env=env,stdout=f,check=True)
def rust(script,names):
 cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-O',str(out/(script+'.rs')),'-L','dependency='+str(deps)]
 for name in names:cmd+=['--extern',name+'='+str(next(deps.glob('lib'+name+'-*.rlib')))]
 cmd+=['-o',str(out/script)];subprocess.run(cmd,cwd=root,check=True)
 with (out/(script+'.txt')).open('w') as f:subprocess.run([str(out/script)],stdout=f,check=True)
rust('geometry',['moving_mesh']);python('operators');rust('coupled',['moving_mesh','mhd_core']);python('spectra');python('radius_phi');python('uniform_decay')
