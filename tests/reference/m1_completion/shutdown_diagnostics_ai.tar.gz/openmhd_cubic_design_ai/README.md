# Separate AI contingency design review: cubic moment correction

This is mathematical exploration and small operator diagnostics, not registration, implementation approval, a physical candidate, or M1 acceptance. No solver or repository file was edited; no physical evolution was launched. The current compact N256 final gate remained pending during this review. Geometry and actual fluid/EMF routines are from frozen `aae382e957e2d3e2d8534c908e550039ad815fd2`.

## Algebra and conditional order argument

Let GL be the actual direct-neighbour derivative, with weights w_ij, offsets d_ij and the same first-sample subtraction used by the implementation. Fit a free-intercept cubic polynomial with basis `[1,x,y,x²/2,y²/2,xy,x³/6,y³/6,x²y/2,xy²/2]`, h=sqrt(V), and the existing weight 1/(|d|/h). Use the existing direct+second-ring image-aware support, excluding only the target at zero image. Define G3 by subtracting the GL quadratic and cubic moments contracted with this cubic fit's Hessian and third derivatives. It exactly differentiates cubics when the fit is full rank. For bounded, shape-regular stencils and a smooth field, its first-derivative error is O(h³); symmetry can improve that order.

If the true gauge divergence is zero, the only scalar driving source is O(h³) differentiation error, the linear response remains bounded, and decay time is O(h), then the associated phi error can be O(h⁴). A two-derivative operator with norm O(h^-2) then gives an O(h²) upper estimate for cleaning-driven magnetic contamination. This is a conditional estimate, not a demonstrated bound for the coupled method.

Several premises can fail here. The actual checkpoint div(A) RMS is .00409/.00521/.00648 at N64/128/256, dominated by smooth auxiliary-gauge structure, not the much smaller initial truncation residual. Auxiliary roots remain four intervals at all resolutions. Decay time is **R/(beta*cs)**, from phi_t = alpha*cs²*div(A) - beta*cs*phi/R. The different quantity **beta*R/(alpha*cs)** is the diffusive timestep bound. A nonzero smooth gauge source with local R_i can generate a phi component with cell-scale coefficients; such a field has no uniform smooth Taylor expansion. The cubic correction does not suppress its two-derivative operator norm. Coupled wave response and nonnormality also invalidate reasoning from scalar decay alone. Existing second-order face-source and donor/receiver transport errors, limiter effects, and the already-discretized A field remain other potential leading error sources. Increasing derivative polynomial degree alone does not make those errors smoother or guarantee second-order B evolution.

## Support, polynomial reproduction and regular symbol

Tested N4, N8, N16 square periodic meshes at jitter 0, .15 and .25. Samples remain distinct by `(cell ID, periodic image)`; repeated global IDs are accumulated only in the assembled periodic operator. All local cubic fits have rank 10: regular support has 12 samples; irregular support has 14–22. The largest weighted SVD condition number is 15.86. Local degree-three polynomial identity errors are at most 1.7e-15. These finite examples do not guarantee rank or conditioning for arbitrary deformed meshes. SVD condition numbers here are not the production pivot-ratio rank indicator.

On the regular square mesh G3 matches

`(-f[i+2] + 8*f[i+1] - 8*f[i-1] + f[i-2]) / (12*h)`

within 1.3e-14. Its symbol is `i*sin(theta)*(4-cos(theta))/(3*h)`, retaining sign for 0<theta<pi. Nyquist zeros remain; its maximum derivative magnitude is larger than the second-order central derivative. The old timestep bound therefore needs evaluation if this is ever registered; no stability assertion follows from the sign check.

## Cleaning and coupled spectra

Q denotes broad quadratic derivatives, C/C2 the current quadratic-moment compact derivative, D/C3 the proposed cubic correction. The cubic derivative is independently assembled using NumPy SVD, not implemented in the solver. `operators.py` records all support/rank/polynomial/operator metrics.

C3 cleaning Laplacians have no positive real eigenvalue above 1e-8 in these nine small examples. Full damped cleaning-only matrices for N8/N16 also have none. Irregular curl-grad is not zero. At N16 jitter .15 its infinity norm is 338.87 for C3 versus 223.43 for C2. For a smooth sin(2*pi*x), N8→16 jitter .15 gradient RMS improves .0670→.00580 and curl-grad RMS .3331→.08049 with C3. For a cell-radius-modulated sine of amplitude O(h), curl-grad RMS instead rises .04366→.14820. These are illustrative two-resolution operator probes, not convergence gates.

The coupled probe is the same 8² semidiscrete, unlimited uniform Alfvén subsystem `(Ax,Ay,vz,phi)` used in the earlier compact design review: rho=1, p=.1, gamma=5/3, B=(1,0,0), v=A=phi=0, fixed mesh; actual frozen fluid momentum-z flux and SymmetricHll EMF completion, unlimited linear primitive face gradients, positive beta source weights, matching selected potential/scalar derivative, alpha=1, beta=.15 and actual cell radii. Advection vanishes and distortion is quadratic in perturbations at this base. Mean vz subtraction enforces the bulk-reference sector; nonzero eigenmodes have conserved zero mean momentum. This is neither the nonlinear travelling wave nor the frozen-C1 full-step map.

At jitter .15 C3 has a positive real eigenvalue +.00537660110 with cleaning, versus current C2 +.00443182667. At jitter .25 C3 has +.00126841790 ± .00085629320i, while C2 has no resolved positive mode. The values persist at finite-difference perturbations 1e-6 and 1e-7, with eigenpair residuals about 1e-13 and matrix differences at most 2.3e-10. With cleaning disabled, neither jittered C3 example has a positive mode above 1e-7. Broad Q reproduces the prior strong +.797914621 regular-grid failure. Regular C3 shows small near-zero finite-difference sensitivity (max +1.14e-5 at epsilon1e-6, about1.1e-7 at epsilon1e-7), not a robust instability measurement; the actual near-degenerate Riemann fan limits the precision of that control.

As a matrix-only isolation control, replace solely the phi decay diagonal with beta*cs/Rbar, where Rbar=sqrt(domain_area/(pi*Ncells)); no coefficient is tuned. C3's positive eigenvalues persist: +.00539494 at jitter .15 and +.00127535 ± .00086220i at .25. Thus local-radius variation is not necessary for these particular linearized coupled modes. It may still seed noise in the nonlinear run.

## Actual checkpoint radius/phi comparison

`radius_phi.py` uses the already captured compact quarter-time snapshots. The N256 snapshot is interim and has no completed execution seal. Fixed x Fourier fits k<=4 and k<=8 are both recorded; fits use actual centroids and volume weights. With k<=8 removed, phi residual RMS is 7.86e-7 / 5.90e-7 / 5.70e-7 for N64/128/256; relative radius residual RMS is 5.08% / 5.01% / 6.18%. Correlation with phi_smooth*(R/R_smooth-1) is +.510 / +.372 / +.173. Including cs in tau changes this little. Using k<=4 leaves k8 gauge structure and gives much weaker correlations (.112/.071/.033); this decomposition dependence is preserved. These observations support partial alignment but do not identify local decay as the dominant source of N256 noise.

## Verdict

The cubic correction is a valid polynomial-consistent operator with the anticipated regular symbol and adequate support in these examples. The proposed truncation-only argument does not describe all leading contributions present in the current run. The small coupled tests retain and sometimes worsen growing modes, while arbitrary cell-scale curl-grad contamination is not reduced. No conclusion that cubic correction resolves the observed refinement problem, no implementation authorization, and no relaxation of the current gate is given.

## Reproduction

`reproduce.py` compiles the two read-only Rust probes against frozen release rlibs, runs the geometry exporter, constructs SVD derivative matrices, generates actual-flux Jacobians, and analyzes spectra/checkpoint correlations. It sets BLAS threads to one. Run:

```sh
/Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_cubic_design_ai/reproduce.py
```

`operators.json`, `spectra.json`, `uniform_decay.json`, `radius_phi.json` preserve numeric results. CSV files preserve geometry/derivative/coupled matrices. The provenance records the frozen source/library and reused checkpoint hashes. `checksums.json` lists all review artifacts. Binaries may be omitted from archival while retaining their recorded hashes.
