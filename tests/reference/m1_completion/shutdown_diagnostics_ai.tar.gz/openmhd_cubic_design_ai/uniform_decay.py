import json
from pathlib import Path
import numpy as np
out=Path('/tmp/openmhd_cubic_design_ai');results={};n=8;nc=n*n
for j in [.15,.25]:
 for kind in ['C','D']:
  a=np.loadtxt(out/f'alfven_{kind}_n8_j{j}_cleantrue_e0.0000001.csv',delimiter=',');uniform=.15*np.sqrt(1/6)/(1/n/np.sqrt(np.pi));i=np.arange(3*nc,4*nc);a[i,i]=-uniform;e=np.linalg.eigvals(a);idx=np.argmax(e.real);results[f'{kind}_j{j}']={'decay_rate':uniform,'max_real':float(e[idx].real),'imag_at_max':float(e[idx].imag),'positive_above_1e-7':int(sum(e.real>1e-7))}
print(json.dumps(results,indent=2));(out/'uniform_decay.json').write_text(json.dumps(results,indent=2)+'\n')
