# Independent AI figure-integrity review

Read-only review of `scripts/plot_m1_wave_probes.py`, SHA-256 `af4256b88e41098a32c4af1117448b6449f003c638fb5f1245e66ef17b07ad96`, in `/Users/arm2arm/orca/workspaces/openmhd-rs-/M0`.

The archived input hash is `eb95b1eefb8ec9817f77a64a25e2163bf71ac53b81b861ec4c80d0bb12aa852f`. `check.py` independently verifies 34 recorded raw input hashes, 65,536 exact N128 x/y/B samples and 672 scalar norm values from the raw CSVs using Python csv, math.hypot and math.fsum. It checks time, count, IDs, positive volumes and completed/external-stop classifications. Maximum norm difference is 1.8214596497756474e-17. Results are in check.json.

Run from the repository root:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_wave_figure_ai/check.py
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python scripts/plot_m1_wave_probes.py --figure-input tests/reference/m1_completion/wave_probes/figure_inputs.json.gz --output-dir /tmp/openmhd_wave_figure_ai/replay
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python scripts/plot_m1_wave_probes.py --linear-dir results/m1_completion_full --quadratic-dir results/m1_quadratic_probe --consistent-dir results/m1_consistent_probe --matched-dir results/m1_matched_probe --output-dir /tmp/openmhd_wave_figure_ai/raw
```

Both PNGs were visually inspected. Both PNGs and packed figure input match byte for byte between raw mode, replay and the documentation artifacts; hashes are in replay_check.json. Vector L1 uses the volume-weighted Euclidean magnetic error divided by amplitude 0.1; maps show pointwise Euclidean error at the actual N128 centroids on a common color scale. The figure redraw does not independently remeasure the simulation. No simulation, solver change or repository edit was performed by this review.

Bounded AI approval: no figure-integrity blocker. Full M1 acceptance and compact N256 results are separate and remain pending at review time.
