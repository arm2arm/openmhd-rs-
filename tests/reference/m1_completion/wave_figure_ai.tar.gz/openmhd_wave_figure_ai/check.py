import csv,gzip,hashlib,json,math,pathlib
root=pathlib.Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0')
a=root/'tests/reference/m1_completion/wave_probes/figure_inputs.json.gz'
sha=lambda b:hashlib.sha256(b).hexdigest()
b=a.read_bytes();p=json.loads(gzip.decompress(b));assert sha(b)==a.with_name(a.name+'.sha256').read_text().split()[0]
for name,digest in p['raw_inputs_sha256'].items():assert sha((root/name).read_bytes())==digest,name
studies={'linear HLL':'results/m1_completion_full','quadratic only':'results/m1_quadratic_probe','consistent rate':'results/m1_consistent_probe','matched cleaning':'results/m1_matched_probe'}
maxdiff=0.;norms=0;samples=0
for label,directory in studies.items():
 ledger=json.loads((root/directory/'runs.json').read_text())
 for ns,record in p['measurements'][label].items():
  n=int(ns);run=f'alfven_bulk-frame-hll-v1_v0.0_j0.15_fixed_n{n}_base' if label=='linear HLL' else f'n{n}'
  source=ledger[run]
  if record['status']!='completed':
   assert n==256 and label in ['quadratic only','consistent rate'] and record['status']=='externally stopped'
   assert source['exit_code']==-15 and source['status']=='failed evolution'
   continue
  assert source['status']=='completed'
  for stage,t in [('initial',0.),('final',1.)]:
   path=root/directory/run/(stage+'.csv')
   assert sha(path.read_bytes())==source.get('artifacts_sha256',source.get('sha256'))[path.name]
   with path.open() as f:cells=[{k:float(v) for k,v in row.items()} for row in csv.DictReader(f)]
   assert len(cells)==n*n and [c['id'] for c in cells]==list(range(n*n)) and all(c['time']==t and c['volume']>0 for c in cells)
   if n==128 and stage=='final':
    expected=[{k:c[k] for k in ['x','y','bx','by','bz']} for c in cells]
    assert expected==p['snapshots'][label],label
    samples+=len(cells)
   volume=math.fsum(c['volume'] for c in cells);err={k:[] for k in ['B','v','bx','by','bz','vx','vy','vz']}
   for c in cells:
    phase=2*math.pi*(c['x']+t);trans=[.1*math.sin(phase),.1*math.cos(phase)]
    db=[c[k]-v for k,v in zip(['bx','by','bz'],[1.,*trans])]
    dv=[c[k]-v for k,v in zip(['vx','vy','vz'],[0.,*trans])]
    err['B'].append(math.hypot(*db));err['v'].append(math.hypot(*dv))
    for k,v in zip(['bx','by','bz','vx','vy','vz'],db+dv):err[k].append(v)
   for field,errors in err.items():
    values={'L1':math.fsum(c['volume']*abs(e) for c,e in zip(cells,errors))/volume,'L2':math.sqrt(math.fsum(c['volume']*e*e for c,e in zip(cells,errors))/volume),'max':max(abs(e) for e in errors)}
    for kind,value in values.items():
     stored=record[stage][field][kind];d=abs(value-stored);maxdiff=max(maxdiff,d);assert d<=3e-15+abs(value)*1e-12,(label,n,stage,field,kind,d);norms+=1
result={'archive_sha256':sha(b),'verified_raw_hashes':len(p['raw_inputs_sha256']),'exact_samples':samples,'verified_norm_scalars':norms,'max_independent_norm_difference':maxdiff}
print(json.dumps(result,indent=2));pathlib.Path('/tmp/openmhd_wave_figure_ai/check.json').write_text(json.dumps(result,indent=2)+'\n')
