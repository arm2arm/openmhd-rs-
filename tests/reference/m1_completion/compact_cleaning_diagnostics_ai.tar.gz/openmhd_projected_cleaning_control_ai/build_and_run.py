"""Two explicitly authorized diagnostic evolutions; only phi divergence forcing disabled."""
from pathlib import Path
import subprocess,tarfile,io,json,hashlib,difflib,datetime,time,concurrent.futures,os
p=Path(__file__).resolve().parent;root=p.parents[2];rev='fb8bb14bf362a9eb42c2f32d6ec8c1252482790d';sha=lambda b:hashlib.sha256(b).hexdigest();src=p/'source';src.mkdir();payload=subprocess.check_output(['git','archive',rev,'Cargo.toml','Cargo.lock','rust-toolchain.toml','crates','apps','docs/M1_COMPLETION_PLAN.md'],cwd=root)
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:') as archive:
 assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not m.issym() and not m.islnk() for m in archive.getmembers())
 archive.extractall(src)
paths=sorted(x for x in src.rglob('*') if x.is_file());original={str(f.relative_to(src)):sha(f.read_bytes()) for f in paths};path=src/'crates/mhd-vector-pot/src/general.rs';before=path.read_text();needle='''Cleaning::default().begin(
                    self.state.phi[i],
                    fit.divergence_a[i],''';assert before.count(needle)==1;after=before.replace(needle,needle.replace('fit.divergence_a[i]','0.'));path.write_text(after);(p/'diagnostic.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='frozen/crates/mhd-vector-pot/src/general.rs',tofile='diagnostic/crates/mhd-vector-pot/src/general.rs')))
modified={str(f.relative_to(src)):sha(f.read_bytes()) for f in paths};assert [f for f in original if original[f]!=modified[f]]==['crates/mhd-vector-pot/src/general.rs'];cargo='/Users/arm2arm/.cargo/bin/cargo';target=p/'target';env=dict(os.environ,CARGO_TARGET_DIR=str(target));cmd=[cargo,'build','--release','--locked','--bin','vector-potential']
with (p/'build.log').open('w') as f:subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
binary=target/'release/vector-potential';baseprov=(root/'results/m1_projected_probe/provenance.json').read_bytes();(p/'baseline_provenance_at_launch.json').write_bytes(baseprov);bp=json.loads(baseprov);assert bp['revision']==rev and bp['dirty_status']==''
for f,d in bp['source_sha256'].items():
 if f in original:assert original[f]==d,f
configs={}
for n in [64,128]:
 out=p/f'n{n}';out.mkdir();cache=root/f'results/m1_mesh_cache/unit_{n}_0.15.mesh';command=[str(binary),'--profile','bulk-frame-hll-projected-v1','--case','alfven','--n',str(n),'--jitter','.15','--time','.25','--mesh-cache',str(cache),'--output',str(out)];configs[f'n{n}']=dict(n=n,command=command,mesh_cache=str(cache),mesh_cache_sha256=sha(cache.read_bytes()))
prov=dict(scope='Diagnostic intervention only, not an accepted profile or acceptance run',underlying_frozen_revision=rev,underlying_profile='bulk-frame-hll-projected-v1',intervention='Only Cleaning::begin divergence forcing argument fit.divergence_a[i] changed to0; initial phi0; cleaning timestep bounds retained',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),build_command=cmd,build_cwd=str(src),build_environment_overrides=dict(CARGO_TARGET_DIR=str(target)),binary_sha256=sha(binary.read_bytes()),original_source_sha256=original,modified_source_sha256=modified,patch_sha256=sha((p/'diagnostic.patch').read_bytes()),baseline_provenance_sha256=sha(baseprov),script_sha256=sha(Path(__file__).read_bytes()),jobs=2,rustc=subprocess.check_output(['/Users/arm2arm/.cargo/bin/rustc','-Vv'],cwd=src,text=True))
def dump(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
dump(p/'provenance.json',prov);dump(p/'manifest.json',configs);runs={}
def run(name,c):
 assert sha(binary.read_bytes())==prov['binary_sha256'];out=p/name;start=time.monotonic()
 with (out/'run.log').open('w') as f:r=subprocess.run(c['command'],cwd=src,stdout=f,stderr=subprocess.STDOUT)
 record=dict(status='completed' if r.returncode==0 else 'failed evolution',exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,command=c['command'],sha256={f.name:sha(f.read_bytes()) for f in out.iterdir() if f.is_file()})
 if (out/'summary.json').exists():record['summary']=json.loads((out/'summary.json').read_text())
 if r.returncode==0:
  s=record['summary'];assert s['time']==.25 and s['completed'] and s['profile']=='bulk-frame-hll-projected-v1' and s['n']==c['n'];assert s['initial']['phi']['max']==s['final']['phi']['max']==0
 return name,record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,name,c) for name,c in configs.items()]):
  name,r=future.result();runs[name]=r;dump(p/'runs.json',runs);print(name,r['status'],r['elapsed_seconds'],{k:r.get('summary',{}).get(k) for k in ['steps','rejected_cfl','rejected_state','dt_min','dt_max']},flush=True)
assert sha(binary.read_bytes())==prov['binary_sha256'];assert modified=={str(f.relative_to(src)):sha(f.read_bytes()) for f in paths};assert all(sha(Path(c['mesh_cache']).read_bytes())==c['mesh_cache_sha256'] for c in configs.values());prov['result_sha256']={name:sha((p/name).read_bytes()) for name in ['manifest.json','runs.json']};dump(p/'provenance.json',prov)
