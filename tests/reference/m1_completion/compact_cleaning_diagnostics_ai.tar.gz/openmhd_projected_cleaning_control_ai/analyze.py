from pathlib import Path
import json,hashlib,io
import numpy as np
p=Path(__file__).resolve().parent;root=p.parents[2];baseline=root/'results/m1_projected_probe';sha=lambda b:hashlib.sha256(b).hexdigest()
meta={k:(p/k).read_bytes() for k in ['provenance.json','runs.json','manifest.json']};prov=json.loads(meta['provenance.json']);runs=json.loads(meta['runs.json']);manifest=json.loads(meta['manifest.json']);assert set(runs)=={'n64','n128'}
for k,h in prov['result_sha256'].items():assert sha(meta[k])==h
for f,h in prov['modified_source_sha256'].items():assert sha((p/'source'/f).read_bytes())==h
assert sha((p/'target/release/vector-potential').read_bytes())==prov['binary_sha256'];bm={k:(baseline/k).read_bytes() for k in ['provenance.json','runs.json','manifest.json']}
for k,b in bm.items():(p/('baseline_'+k)).write_bytes(b)
br=json.loads(bm['runs.json']);bp=json.loads(bm['provenance.json']);assert bp['revision']==prov['underlying_frozen_revision'];records={};rawcount=0
for n in [64,128]:
 name=f'n{n}';control=runs[name];base=br[name];assert control['status']==base['status']=='completed' and control['exit_code']==base['exit_code']==0
 for directory,record in [(p/name,control),(baseline/name,base)]:
  for file,digest in record['sha256'].items():assert sha((directory/file).read_bytes())==digest;rawcount+=1
 assert (p/name/'initial.csv').read_bytes()==(baseline/name/'initial.csv').read_bytes(),'initial state differs'
 assert sha(Path(manifest[name]['mesh_cache']).read_bytes())==manifest[name]['mesh_cache_sha256']
 for s in [control['summary'],base['summary']]:
  assert s['profile']=='bulk-frame-hll-projected-v1' and s['n']==n and s['jitter']==.15 and s['motion']=='fixed' and s['mean_B']==[1,0,0] and s['limited'] and s['boost']==[0,0,0] and s['parallel_velocity']==0 and s['gamma']==5/3
  assert s['rejected_state']==s['rejected_geometry']==0
 rows={}
 for label,file in [('baseline',baseline/name/'checkpoint_0.25000000.csv'),('no_phi_forcing',p/name/'final.csv')]:
  a=np.genfromtxt(io.BytesIO(file.read_bytes()),delimiter=',',names=True);assert len(a)==n*n and np.array_equal(a['id'],np.arange(n*n)) and np.all(a['time']==.25) and all(np.all(np.isfinite(a[k])) for k in a.dtype.names);w=a['volume']/np.sum(a['volume']);phase=2*np.pi*(a['x']+.25);e={k:a[k]-ref for k,ref in [('bx',1),('by',.1*np.sin(phase)),('bz',.1*np.cos(phase)),('vx',0),('vy',.1*np.sin(phase)),('vz',.1*np.cos(phase)),('rho',1),('p',.1)]};e['B']=np.sqrt(sum(e[k]**2 for k in ['bx','by','bz']));e['v']=np.sqrt(sum(e[k]**2 for k in ['vx','vy','vz']));norm=lambda v:dict(L1=float(np.sum(w*abs(v))),RMS=float(np.sqrt(np.sum(w*v*v))),max=float(np.max(abs(v))));X=np.column_stack([np.ones(len(a)),np.sin(phase),np.cos(phase)]);sw=np.sqrt(w);noise={};freq=np.fft.fftfreq(n)*n;kx,ky=np.meshgrid(freq,freq);high=np.maximum(abs(kx),abs(ky))>=n/4
  for k in ['by','bz','vy','vz']:
   coef=np.linalg.lstsq(X*sw[:,None],a[k]*sw,rcond=None)[0];res=a[k]-np.sum(X*coef,axis=1);power=abs(np.fft.fft2(res.reshape(n,n)))**2;noise[k]=dict(**norm(res),high_index_frequency_energy_fraction=float(np.sum(power[high])/np.sum(power)))
  rows[label]=dict(errors={k:norm(v) for k,v in e.items()},beyond_fundamental=noise,phi=norm(a['phi']),div_A=norm(a['div_a']),snapshot_sha256=sha(file.read_bytes()))
  if label=='no_phi_forcing':assert np.all(a['phi']==0.)
 bh=json.loads((baseline/name/'history.json').read_bytes());basequarter=next(x for x in bh if x['time']==.25)
 records[name]=dict(**rows,B_L1_ratio_off_over_base=rows['no_phi_forcing']['errors']['B']['L1']/rows['baseline']['errors']['B']['L1'],Bz_noise_RMS_ratio_off_over_base=rows['no_phi_forcing']['beyond_fundamental']['bz']['RMS']/rows['baseline']['beyond_fundamental']['bz']['RMS'],control_counts={k:control['summary'][k] for k in ['steps','rejected_cfl','rejected_state','rejected_geometry','dt_min','dt_max','dt_cap']},baseline_full_t1_counts={k:base['summary'][k] for k in ['steps','rejected_cfl','rejected_state','dt_min','dt_max','dt_cap']},baseline_quarter_history_keys=list(basequarter),control_budget_max=max(abs(v) for v in control['summary']['final']['normalized_budget']),control_rho_min=control['summary']['final']['rho_min'],control_p_min=control['summary']['final']['p_min'])
 print(name,'B L1 baseline/off',rows['baseline']['errors']['B']['L1'],rows['no_phi_forcing']['errors']['B']['L1'],'Bz noise RMS',rows['baseline']['beyond_fundamental']['bz']['RMS'],rows['no_phi_forcing']['beyond_fundamental']['bz']['RMS'],flush=True)
result=dict(scope='Only two quarter-time diagnostic interventions; baseline per-run seals checked, whole baseline ladder still incomplete',revision=prov['underlying_frozen_revision'],metadata_sha256={k:sha(b) for k,b in meta.items()},baseline_metadata_sha256={k:sha(b) for k,b in bm.items()},verified_raw_digests=rawcount,initial_snapshots_bit_identical=True,cases=records)
(p/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
