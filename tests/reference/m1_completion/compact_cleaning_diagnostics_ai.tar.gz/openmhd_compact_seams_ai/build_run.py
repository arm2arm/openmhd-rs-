from pathlib import Path
import json,subprocess,hashlib
p=Path(__file__).resolve().parent;root=p.parents[2];pr=json.loads((p/'review_provenance.json').read_text());lib=Path(pr['library_path']);assert hashlib.sha256(lib.read_bytes()).hexdigest()==pr['library_sha256'];source=''
for module in ['gauge','auxiliary']:source+='mod '+module+' {\n'+(p/f'{module}_frozen.rs').read_text().replace('//!','//')+'\n}\n'
source+=(p/'probe_extra.rs').read_text();(p/'probe.rs').write_text(source);cmd=['/Users/arm2arm/.cargo/bin/rustc','--edition=2024','-O','-Awarnings',str(p/'probe.rs'),'-L','dependency='+str(lib.parent),'--extern','moving_mesh='+str(lib),'-o',str(p/'probe')];subprocess.run(cmd,check=True)
run=[str(p/'probe'),str(root),str(p)]
with (p/'probe.log').open('w') as f:subprocess.run(run,stdout=f,stderr=subprocess.STDOUT,check=True)
pr.update(compile_command=cmd,run_command=run,probe_sha256=hashlib.sha256((p/'probe').read_bytes()).hexdigest(),probe_source_sha256=hashlib.sha256((p/'probe.rs').read_bytes()).hexdigest());(p/'review_provenance.json').write_text(json.dumps(pr,indent=2)+'\n')
print((p/'probe.log').read_text())
