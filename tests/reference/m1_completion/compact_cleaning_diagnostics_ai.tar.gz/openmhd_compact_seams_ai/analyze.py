from pathlib import Path
import hashlib,json,io
import numpy as np
p=Path(__file__).resolve().parent;root=p.parents[2];prov=json.loads((p/'review_provenance.json').read_text());result={};saved={}
def rms(a,w):return float(np.sqrt(np.sum(w*a*a)))
def corr(a,b,w):
 a=a-np.sum(w*a);b=b-np.sum(w*b);return float(np.sum(w*a*b)/np.sqrt(max(1e-300,np.sum(w*a*a)*np.sum(w*b*b))))
for n in [128,256]:
 result[str(n)]={}
 for stage,t in [('initial',0.),('checkpoint_0.25000000',.25),('final',1.)]:
  file=root/f'results/m1_compact_probe/n{n}/{stage}.csv';raw=file.read_bytes();assert hashlib.sha256(raw).hexdigest()==prov['raw_sha256'][str(file)];a=np.genfromtxt(io.BytesIO(raw),delimiter=',',names=True);o=np.genfromtxt(p/f'operators_n{n}_{stage}.csv',delimiter=',',names=True);assert np.array_equal(a['id'],o['id']) and np.all(a['time']==t);w=a['volume']/np.sum(a['volume']);assert all(np.all(np.isfinite(a[k])) for k in a.dtype.names) and all(np.all(np.isfinite(o[k])) for k in o.dtype.names)
  fields=['bx','by','bz','vx','vy','vz','rho','p'];phase=2*np.pi*(a['x']+t);exact=[np.ones(len(a)),.1*np.sin(phase),.1*np.cos(phase),np.zeros(len(a)),.1*np.sin(phase),.1*np.cos(phase),np.ones(len(a)),np.ones(len(a))*.1];errors={k:a[k]-e for k,e in zip(fields,exact)};errors['B']=np.sqrt(sum(errors[k]**2 for k in ['bx','by','bz']))
  # Coherent x-dependent modes through k=16, evaluated at actual irregular positions.
  X=np.column_stack([np.ones(len(a))]+[f(2*np.pi*k*a['x']) for k in range(1,17) for f in [np.sin,np.cos]]);sw=np.sqrt(w);Y=np.column_stack([a['phi'],a['div_a'],a['reduced_ax']]);coefs=np.linalg.lstsq(X*sw[:,None],Y*sw[:,None],rcond=None)[0];smooth=np.sum(X[:,:,None]*coefs[None,:,:],axis=1);residual=Y-smooth
  origin=prov['origins'][str(n)] if stage=='final' else [0,0]
  ds={k:np.abs(((a[k]-origin[i])*4+.5)%1-.5)/4 for i,k in enumerate(['x','y'])};db={k:np.abs(((a[k]-origin[i])*4)%1-.5)/4 for i,k in enumerate(['x','y'])};variables={'B_error':errors['B'],'bz_error':errors['bz'],'vz_error':errors['vz'],'phi':a['phi'],'phi_x16_residual':residual[:,0],'div_a':a['div_a'],'div_a_x16_residual':residual[:,1],'Ax_x16_residual':residual[:,2],'curl_grad_phi':o['curl_grad_phi'],'distortion_x':o['distortion_x']}
  bands={}
  for family,d in [('interpolation_seam',ds),('bin_boundary',db)]:
   for axis in ['x','y','union']:
    distance=d[axis] if axis!='union' else np.minimum(d['x'],d['y'])
    for width in [.5,1,2,4]:
     mask=distance<=width/n;volume=float(np.sum(w[mask]));records={}
     for name,v in variables.items():
      total=np.sum(w*v*v);frac=float(np.sum(w[mask]*v[mask]**2)/total) if total else 0.;records[name]={'energy_fraction':frac,'enrichment':frac/volume if volume else None,'inside_rms':float(np.sqrt(np.sum(w[mask]*v[mask]**2)/volume)) if volume else None,'outside_rms':float(np.sqrt(np.sum(w[~mask]*v[~mask]**2)/(1-volume))) if volume<1 else None}
     bands[f'{family}_{axis}_{width:g}h']={'volume_fraction':volume,'fields':records}
  profiles={}
  for family,d in [('seam',ds),('bin',db)]:
   for axis in ['x','y']:
    distance=d[axis];edges=np.arange(0,17)/2/n;profiles[family+'_'+axis]=[]
    for lo,hi in zip(edges[:-1],edges[1:]):
     mask=(distance>=lo)&(distance<hi);volume=np.sum(w[mask]);profiles[family+'_'+axis].append(dict(distance_h_mid=.5*(lo+hi)*n,volume_fraction=float(volume),rms={name:float(np.sqrt(np.sum(w[mask]*v[mask]**2)/volume)) if volume else None for name,v in variables.items()}))
  seam=np.genfromtxt(p/f'seams_n{n}_{stage}.csv',delimiter=',',names=True);seamsummary={}
  for axis in [0,1]:
   for eps in [1e-5,5e-6]:
    select=(seam['axis']==axis)&(seam['epsilon']==eps);z=seam[select];seamsummary[f'axis{axis}_eps{eps}']={'d2u_jump_rms':{k:float(np.sqrt(np.mean(z['jump_d2u'+k]**2))) for k in ['x','y','z']},'velocity_difference_max':float(np.max(z['velocity_difference'])),'jacobian_difference_max':float(np.max(z['jacobian_difference']))}
  k=np.rint(np.fft.fftfreq(n)*n);kx,ky=np.meshgrid(k,k);high=np.maximum(abs(kx),abs(ky))>=n/4
  noise={}
  for name,v in variables.items():
   ps=abs(np.fft.fft2(v.reshape(n,n)))**2;den=float(np.sum(ps));noise[name]=float(np.sum(ps[high])/den) if den else 0.
  rec=dict(time=t,raw_sha256=hashlib.sha256(raw).hexdigest(),origin_used=origin,div_a_recompute_max_difference=float(np.max(abs(a['div_a']-o['div_a_recomputed']))),errors={k:dict(L1=float(np.sum(w*abs(v))),RMS=rms(v,w),max=float(np.max(abs(v)))) for k,v in errors.items()},variable_rms={k:rms(v,w) for k,v in variables.items()},correlations={'curl_grad_phi_vs_bz_error':corr(o['curl_grad_phi'],errors['bz'],w),'curl_grad_phi_vs_vz_error':corr(o['curl_grad_phi'],errors['vz'],w),'phi_x16_residual_vs_bz_error':corr(residual[:,0],errors['bz'],w)},bands=bands,profiles=profiles,seam_jump=seamsummary,high_index_frequency_energy_fraction=noise,one_dimensional_fit_coefficients=coefs.tolist())
  result[str(n)][stage]=rec
  if stage=='final':saved[n]=(a,o,variables,ds,db)
  b=bands['interpolation_seam_x_2h'];bb=bands['bin_boundary_x_2h'];print(n,stage,'B L1',rec['errors']['B']['L1'],'xseam2h vol',b['volume_fraction'],'B energy',b['fields']['B_error']['energy_fraction'],'enrich',b['fields']['B_error']['enrichment'],'bins enrich',bb['fields']['B_error']['enrichment'],'curl/Bz corr',rec['correlations']['curl_grad_phi_vs_bz_error'],flush=True)
(p/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
# Static diagnostic plots: index-raster at measured centroids, explicit limitation in title.
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
n=256;a,o,v,ds,db=saved[n];fig,axs=plt.subplots(2,3,figsize=(13,7.3),constrained_layout=True)
for ax,(label,key) in zip(axs.flat,[('Bz exact error','bz_error'),('vz exact error','vz_error'),('curl Gc(phi)','curl_grad_phi'),('phi minus x modes k<=16','phi_x16_residual'),('div A minus x modes k<=16','div_a_x16_residual'),('A_x minus x modes k<=16','Ax_x16_residual')]):
 z=v[key].reshape(n,n);limit=np.percentile(abs(z),99.5);im=ax.imshow(z,origin='lower',extent=(0,1,0,1),cmap='RdBu_r',vmin=-limit,vmax=limit,interpolation='nearest');ax.set_title(label);ax.set_xlabel('logical x index / N');ax.set_ylabel('logical y index / N')
 for knot in [0,.25,.5,.75,1]:ax.axvline(knot,c='k',lw=.5,alpha=.5);ax.axhline(knot,c='k',lw=.5,alpha=.5)
 fig.colorbar(im,ax=ax,shrink=.8)
fig.suptitle('Historical compact N256, t=1: signed fields; black auxiliary seams\nIndex raster approximates jittered geometry; each panel has its own color scale (clipped at 99.5%)');fig.savefig(p/'n256_maps.png',dpi=160);plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(13,3.9),constrained_layout=True)
for ax,field in zip(axs,['B_error','curl_grad_phi','phi_x16_residual']):
 for n in [128,256]:
  rr=result[str(n)]['final'];base=rr['variable_rms'][field]
  for family,ls in [('seam','-'),('bin','--')]:
   pp=rr['profiles'][family+'_x'];ax.plot([v['distance_h_mid'] for v in pp],[v['rms'][field]/base if v['rms'][field] is not None else np.nan for v in pp],ls,label=f'N{n} {family}')
 ax.set_xlabel('distance from x line / h');ax.set_ylabel('band RMS / global RMS');ax.set_title(field);ax.axhline(1,c='gray',lw=.7);ax.grid(alpha=.2)
axs[0].legend(fontsize=8);fig.suptitle('t=1 localization: interpolation seams versus bin boundaries');fig.savefig(p/'distance_profiles.png',dpi=160);plt.close(fig)
