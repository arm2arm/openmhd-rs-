from pathlib import Path
import numpy as np,json
p=Path(__file__).resolve().parent;root=p.parents[2];prov=json.loads((p/'review_provenance.json').read_text());out={}
for n in [128,256]:
 out[str(n)]={}
 for stage,t in [('initial',0.),('checkpoint_0.25000000',.25),('final',1.)]:
  a=np.genfromtxt(root/f'results/m1_compact_probe/n{n}/{stage}.csv',delimiter=',',names=True);w=a['volume']/np.sum(a['volume']);r=np.sqrt(a['volume']/np.pi);cs=np.sqrt((5/3)*a['p']/a['rho']);steady=cs*r/.15*a['div_a'];norm=lambda v:float(np.sqrt(np.sum(w*v*v)));seams=np.genfromtxt(p/f'seams_n{n}_{stage}.csv',delimiter=',',names=True);surrogate={}
  for eps in [1e-5,5e-6]:
   s=seams[(seams['axis']==0)&(seams['epsilon']==eps)];origin=prov['origins'][str(n)][0] if stage=='final' else 0.;phase=2*np.pi*(s['knot']/4+origin+t);ay=.1/(2*np.pi)*np.sin(phase);az=.1/(2*np.pi)*np.cos(phase);jump=-(s['jump_d2uy']*ay+s['jump_d2uz']*az);surrogate[str(eps)]={'RMS':float(np.sqrt(np.mean(jump*jump))),'max':float(np.max(abs(jump)))}
  origin=prov['origins'][str(n)];sensitivity={}
  for i,k in enumerate(['x','y']):
   d0=np.abs((4*a[k]+.5)%1-.5)/4;d1=np.abs((4*(a[k]-origin[i])+.5)%1-.5)/4;sensitivity[k]={str(width):int(np.count_nonzero((d0<=width/n)!=(d1<=width/n))) for width in [.5,1,2,4]}
  out[str(n)][stage]=dict(phi_rms=norm(a['phi']),quasisteady_phi_rms=norm(steady),quasisteady_phi_residual_rms=norm(a['phi']-steady),decay_time_min=float(np.min(r/(.15*cs))),decay_time_max=float(np.max(r/(.15*cs))),analytic_transverse_A_distortion_derivative_jump=surrogate,zero_vs_final_origin_band_membership_differences=sensitivity)
(p/'regularity_checks.json').write_text(json.dumps(out,indent=2)+'\n')
