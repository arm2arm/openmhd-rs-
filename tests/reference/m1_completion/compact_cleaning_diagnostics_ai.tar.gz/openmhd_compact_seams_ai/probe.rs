mod gauge {
// Isolated pointwise source and staged cleaning kernels for the M0 audit.
// The general module reuses the immutable cleaning stages; its face stencils
// implement the coupled update separately from these pointwise audit kernels.
// Source: arXiv:2609.35989v1 (38), (41)-(42), (49)-(50), (76), (81), (88), (90), (92).

pub type Vec3 = [f64; 3];
/// `[component][coordinate]`, e.g. gradient_a[a][b] = partial_b A_a.
pub type Jacobian = [[f64; 3]; 3];

#[derive(Clone, Copy, Debug)]
/// Local point data: A is the periodic potential, magnetic is the total B and
/// mean_magnetic is the separately stored background. Velocities are laboratory
/// values; centroid_velocity is not a mesh-generator or face velocity.
pub struct PointSources {
    pub potential: Vec3,
    pub fluid_velocity: Vec3,
    pub auxiliary_velocity: Vec3,
    pub centroid_velocity: Vec3,
    pub magnetic: Vec3,
    pub mean_magnetic: Vec3,
    pub gradient_a: Jacobian,
    pub gradient_auxiliary: Jacobian,
    pub gradient_phi: Vec3,
    pub current: Vec3,
    pub resistivity: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct PotentialRate {
    pub induction: Vec3,
    pub distortion: Vec3,
    pub advection: Vec3,
    pub resistive: Vec3,
    pub cleaning: Vec3,
    pub mean_field: Vec3,
}

fn cross(a: Vec3, b: Vec3) -> Vec3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn finite_vec(v: Vec3) -> bool {
    v.iter().all(|x| x.is_finite())
}
fn finite(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() {
        Ok(value)
    } else {
        Err(format!("nonfinite {context}"))
    }
}
fn positive(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() && value > 0.0 {
        Ok(value)
    } else {
        Err(format!("{context} must be finite and positive"))
    }
}
fn interval(dt: f64) -> Result<(), String> {
    if dt.is_finite() && dt >= 0.0 {
        Ok(())
    } else {
        Err("time interval must be finite and nonnegative".into())
    }
}

impl PotentialRate {
    pub fn total(self) -> Vec3 {
        std::array::from_fn(|k| {
            self.induction[k]
                + self.distortion[k]
                + self.advection[k]
                + self.resistive[k]
                + self.cleaning[k]
                + self.mean_field[k]
        })
    }
}

impl PointSources {
    pub fn rate(self) -> Result<PotentialRate, String> {
        if ![
            self.potential,
            self.fluid_velocity,
            self.auxiliary_velocity,
            self.centroid_velocity,
            self.magnetic,
            self.mean_magnetic,
            self.gradient_phi,
            self.current,
        ]
        .into_iter()
        .all(finite_vec)
            || !self
                .gradient_a
                .into_iter()
                .chain(self.gradient_auxiliary)
                .all(finite_vec)
            || !self.resistivity.is_finite()
            || self.resistivity < 0.0
        {
            return Err(
                "point source requires finite vectors/Jacobians and nonnegative resistivity".into(),
            );
        }
        let relative_fluid =
            std::array::from_fn(|k| self.fluid_velocity[k] - self.auxiliary_velocity[k]);
        let relative_mesh: Vec3 =
            std::array::from_fn(|k| self.centroid_velocity[k] - self.auxiliary_velocity[k]);
        let result = PotentialRate {
            induction: cross(relative_fluid, self.magnetic),
            distortion: std::array::from_fn(|b| {
                -(0..3)
                    .map(|a| self.gradient_auxiliary[a][b] * self.potential[a])
                    .sum::<f64>()
            }),
            advection: std::array::from_fn(|a| {
                (0..3)
                    .map(|b| self.gradient_a[a][b] * relative_mesh[b])
                    .sum()
            }),
            resistive: self.current.map(|j| -self.resistivity * j),
            cleaning: self.gradient_phi,
            mean_field: cross(self.auxiliary_velocity, self.mean_magnetic),
        };
        if ![
            result.induction,
            result.distortion,
            result.advection,
            result.resistive,
            result.cleaning,
            result.mean_field,
            result.total(),
        ]
        .into_iter()
        .all(finite_vec)
        {
            return Err("point source overflow".into());
        }
        Ok(result)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Cleaning {
    alpha: f64,
    beta: f64,
}

impl Default for Cleaning {
    fn default() -> Self {
        Self {
            alpha: 1.0,
            beta: 0.15,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct CleaningBounds {
    /// Printed equation (49), r/(alpha cs).
    pub hyperbolic: f64,
    /// Printed equation (50), r^2/D, D=alpha cs r/beta.
    pub diffusive: f64,
}

/// Immutable initial source data enforce equation (90)'s frozen div(A) and cs.
#[derive(Clone, Copy, Debug)]
pub struct CleaningStage {
    parameters: Cleaning,
    phi_initial: f64,
    divergence_initial: f64,
    sound_speed_initial: f64,
    rate_initial: f64,
}

impl Cleaning {
    /// This active-cleaning kernel requires positive alpha and beta. Disabling
    /// cleaning is an explicit caller decision, not represented by invalid bounds.
    pub fn new(alpha: f64, beta: f64) -> Result<Self, String> {
        positive(alpha, "alpha")?;
        positive(beta, "beta")?;
        Ok(Self { alpha, beta })
    }
    pub fn alpha(self) -> f64 {
        self.alpha
    }
    pub fn beta(self) -> f64 {
        self.beta
    }

    pub fn rate(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<f64, String> {
        finite(phi, "cleaning scalar")?;
        finite(divergence_a, "potential divergence")?;
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        finite(
            self.alpha * sound_speed.powi(2) * divergence_a
                - self.beta * sound_speed * phi / radius,
            "cleaning rate",
        )
    }

    pub fn bounds(self, sound_speed: f64, radius: f64) -> Result<CleaningBounds, String> {
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        let hyperbolic = positive(radius / (self.alpha * sound_speed), "hyperbolic bound")?;
        let diffusive = positive(self.beta * hyperbolic, "diffusive bound")?;
        Ok(CleaningBounds {
            hyperbolic,
            diffusive,
        })
    }

    pub fn begin(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<CleaningStage, String> {
        let rate_initial = self.rate(phi, divergence_a, sound_speed, radius)?;
        Ok(CleaningStage {
            parameters: self,
            phi_initial: phi,
            divergence_initial: divergence_a,
            sound_speed_initial: sound_speed,
            rate_initial,
        })
    }
}

impl CleaningStage {
    pub fn initial_rate(self) -> f64 {
        self.rate_initial
    }

    pub fn predicted_phi(self, dt: f64) -> Result<f64, String> {
        interval(dt)?;
        finite(
            self.phi_initial + dt * self.rate_initial,
            "predicted cleaning scalar",
        )
    }

    pub fn endpoint_rate(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        self.parameters.rate(
            self.predicted_phi(dt)?,
            self.divergence_initial,
            self.sound_speed_initial,
            endpoint_radius,
        )
    }

    pub fn finish_phi(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        interval(dt)?;
        let rate_end = self.endpoint_rate(dt, endpoint_radius)?;
        finite(
            self.phi_initial + 0.5 * dt * (self.rate_initial + rate_end),
            "updated cleaning scalar",
        )
    }
}

}
mod auxiliary {
// Periodic bicubic reduction of paper Eq. (68), with the explicit v2 origin rule.
use crate::gauge::{Jacobian, Vec3};
use moving_mesh::Vec2;

#[derive(Clone, Copy, Debug, Default)]
pub struct Jet {
    pub value: Vec3,
    pub dx: Vec3,
    pub dy: Vec3,
    pub dxy: Vec3,
}

#[derive(Clone, Copy, Debug)]
pub struct Sample {
    pub velocity: Vec3,
    pub jacobian: Jacobian,
}

/// Tensor Hermite polynomial on a single element; coordinates are in [0,1]^2.
/// Corner layout is [y][x]; derivative jets are in physical length units.
pub fn interpolate(
    corners: &[[Jet; 2]; 2],
    spacing: Vec2,
    coordinate: Vec2,
) -> Result<Sample, String> {
    if !spacing.iter().all(|h| h.is_finite() && *h > 0.0)
        || !coordinate
            .iter()
            .all(|s| s.is_finite() && (0.0..=1.0).contains(s))
        || corners.iter().flatten().any(|j| {
            [j.value, j.dx, j.dy, j.dxy]
                .iter()
                .flatten()
                .any(|v| !v.is_finite())
        })
    {
        return Err("invalid Hermite element or coordinate".into());
    }
    let basis = |s: f64| {
        [
            [
                2.0 * s * s * s - 3.0 * s * s + 1.0,
                s * s * s - 2.0 * s * s + s,
            ],
            [-2.0 * s * s * s + 3.0 * s * s, s * s * s - s * s],
        ]
    };
    let derivative = |s: f64| {
        [
            [6.0 * s * s - 6.0 * s, 3.0 * s * s - 4.0 * s + 1.0],
            [-6.0 * s * s + 6.0 * s, 3.0 * s * s - 2.0 * s],
        ]
    };
    let bx = basis(coordinate[0]);
    let by = basis(coordinate[1]);
    let dx = derivative(coordinate[0]);
    let dy = derivative(coordinate[1]);
    let mut result = Sample {
        velocity: [0.0; 3],
        jacobian: [[0.0; 3]; 3],
    };
    for (y, row) in corners.iter().enumerate() {
        for (x, jet) in row.iter().enumerate() {
            for (px, py, values) in [
                (0, 0, jet.value),
                (1, 0, jet.dx),
                (0, 1, jet.dy),
                (1, 1, jet.dxy),
            ] {
                let scale = (if px == 0 { 1.0 } else { spacing[0] })
                    * (if py == 0 { 1.0 } else { spacing[1] });
                for (k, v) in values.iter().enumerate() {
                    result.velocity[k] += v * scale * bx[x][px] * by[y][py];
                    result.jacobian[k][0] += v * scale * dx[x][px] * by[y][py] / spacing[0];
                    result.jacobian[k][1] += v * scale * bx[x][px] * dy[y][py] / spacing[1];
                }
            }
        }
    }
    if !result
        .velocity
        .iter()
        .chain(result.jacobian.iter().flatten())
        .all(|v| v.is_finite())
    {
        return Err("Hermite evaluation overflow".into());
    }
    Ok(result)
}

#[derive(Clone, Copy, Debug)]
pub struct VelocitySample {
    pub position: Vec2,
    pub volume: f64,
    pub velocity: Vec3,
}

#[derive(Clone, Debug)]
pub struct SmoothVelocity {
    lengths: Vec2,
    origin: Vec2,
    corners: Vec<Jet>,
    intervals: usize,
    pub counts: Vec<usize>,
    pub max_cell_volumes: Vec<f64>,
    pub coarsenings: usize,
    pub mean_velocity: Vec3,
}

fn bin(position: f64, origin: f64, length: f64, intervals: usize) -> usize {
    let mut q = (position - origin).rem_euclid(length) / length * intervals as f64 + 0.5;
    let nearest = q.round();
    if (q - nearest).abs() <= 32.0 * f64::EPSILON * (1.0 + q.abs()) {
        q = nearest;
    }
    (q.floor() as usize) % intervals
}

fn jets(values: &[Vec3], n: usize, spacing: Vec2) -> Vec<Jet> {
    let index = |x: usize, y: usize| (x % n) + n * (y % n);
    let dx: Vec<Vec3> = (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            std::array::from_fn(|k| {
                (values[index(x + 1, y)][k] - values[index(x + n - 1, y)][k]) / (2.0 * spacing[0])
            })
        })
        .collect();
    (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            Jet {
                value: values[i],
                dx: dx[i],
                dy: std::array::from_fn(|k| {
                    (values[index(x, y + 1)][k] - values[index(x, y + n - 1)][k])
                        / (2.0 * spacing[1])
                }),
                dxy: std::array::from_fn(|k| {
                    (dx[index(x, y + 1)][k] - dx[index(x, y + n - 1)][k]) / (2.0 * spacing[1])
                }),
            }
        })
        .collect()
}

impl SmoothVelocity {
    pub fn build(lengths: Vec2, samples: &[VelocitySample], origin: Vec2) -> Result<Self, String> {
        if samples.is_empty()
            || !lengths.iter().all(|v| v.is_finite() && *v > 0.0)
            || !origin.iter().all(|v| v.is_finite())
            || samples.iter().any(|s| {
                !s.volume.is_finite()
                    || s.volume <= 0.0
                    || !s.position.iter().chain(&s.velocity).all(|v| v.is_finite())
                    || (0..2).any(|k| !(s.position[k] - origin[k]).is_finite())
            })
        {
            return Err("invalid auxiliary velocity samples/domain/origin".into());
        }
        let total: f64 = samples.iter().map(|s| s.volume).sum();
        if !total.is_finite() || total <= 0.0 {
            return Err("auxiliary volume overflow".into());
        }
        let mean_velocity: Vec3 = std::array::from_fn(|k| {
            samples
                .iter()
                .map(|s| s.volume / total * s.velocity[k])
                .sum()
        });
        for (coarsenings, n) in [4, 2, 1].into_iter().enumerate() {
            let mut weights = vec![0.0; n * n];
            let mut values = vec![[0.0; 3]; n * n];
            let mut counts = vec![0; n * n];
            let mut max_cell_volumes = vec![0.0_f64; n * n];
            for s in samples {
                let i = bin(s.position[0], origin[0], lengths[0], n)
                    + n * bin(s.position[1], origin[1], lengths[1], n);
                let w = s.volume / total;
                weights[i] += w;
                counts[i] += 1;
                max_cell_volumes[i] = max_cell_volumes[i].max(s.volume);
                for (k, v) in s.velocity.iter().enumerate() {
                    values[i][k] += w * v;
                }
            }
            if counts.contains(&0) {
                continue;
            }
            for (v, w) in values.iter_mut().zip(weights) {
                for component in v {
                    *component /= w;
                }
            }
            let corners = jets(&values, n, lengths.map(|l| l / n as f64));
            if !mean_velocity
                .into_iter()
                .chain(
                    corners
                        .iter()
                        .flat_map(|j| [j.value, j.dx, j.dy, j.dxy])
                        .flatten(),
                )
                .all(|v| v.is_finite())
            {
                return Err("auxiliary averages/jets overflow".into());
            }
            return Ok(Self {
                lengths,
                origin,
                corners,
                intervals: n,
                counts,
                max_cell_volumes,
                coarsenings,
                mean_velocity,
            });
        }
        Err("auxiliary root remained empty".into())
    }

    pub fn intervals(&self) -> usize {
        self.intervals
    }
    pub fn origin(&self) -> Vec2 {
        self.origin
    }

    pub fn sample(&self, position: Vec2, stage_time: f64) -> Result<Sample, String> {
        if !stage_time.is_finite() || stage_time < 0.0 {
            return Err("invalid auxiliary stage time".into());
        }
        let coordinate: Vec2 = std::array::from_fn(|k| {
            position[k] - self.origin[k] - stage_time * self.mean_velocity[k]
        });
        if !coordinate.iter().all(|v| v.is_finite()) {
            return Err("auxiliary coordinate overflow".into());
        }
        let n = self.intervals;
        let spacing = self.lengths.map(|l| l / n as f64);
        let q: Vec2 =
            std::array::from_fn(|k| coordinate[k].rem_euclid(self.lengths[k]) / spacing[k]);
        let cell = q.map(|v| v.floor() as usize);
        let local = std::array::from_fn(|k| (q[k] - cell[k] as f64).clamp(0.0, 1.0));
        let corners = std::array::from_fn(|y| {
            std::array::from_fn(|x| self.corners[(cell[0] + x) % n + n * ((cell[1] + y) % n)])
        });
        interpolate(&corners, spacing, local)
    }

    pub fn advanced_origin(&self, dt: f64) -> Result<Vec2, String> {
        if !dt.is_finite() || dt < 0.0 {
            return Err("invalid origin advance interval".into());
        }
        let origin: Vec2 = std::array::from_fn(|k| self.origin[k] + dt * self.mean_velocity[k]);
        if !origin.iter().all(|v| v.is_finite()) {
            return Err("auxiliary origin overflow".into());
        }
        Ok(std::array::from_fn(|k| {
            origin[k].rem_euclid(self.lengths[k])
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::TAU;

    #[test]
    fn centred_jets_converge_for_periodic_smooth_data() {
        let mut errors = Vec::new();
        for n in [8, 16, 32] {
            let h = 1.0 / n as f64;
            let values: Vec<_> = (0..n * n)
                .map(|i| [(TAU * (i % n) as f64 * h).sin() * (TAU * (i / n) as f64 * h).cos(); 3])
                .collect();
            let field = SmoothVelocity {
                lengths: [1.0; 2],
                origin: [0.0; 2],
                corners: jets(&values, n, [h; 2]),
                intervals: n,
                counts: vec![1; n * n],
                max_cell_volumes: vec![h * h; n * n],
                coarsenings: 0,
                mean_velocity: [0.0; 3],
            };
            let error: f64 = (0..n * n)
                .map(|i| {
                    let p = [((i % n) as f64 + 0.37) * h, ((i / n) as f64 + 0.63) * h];
                    let g = field.sample(p, 0.0).unwrap().jacobian[0];
                    (g[0] - TAU * (TAU * p[0]).cos() * (TAU * p[1]).cos())
                        .hypot(g[1] + TAU * (TAU * p[0]).sin() * (TAU * p[1]).sin())
                })
                .sum::<f64>()
                / (n * n) as f64;
            errors.push(error);
        }
        for pair in errors.windows(2) {
            // Finite-difference jets plus interpolation: record convergence,
            // rather than assume an asymptotic order on the coarsest grid.
            assert!(pair[1] < pair[0], "{errors:?}");
        }
    }
}

}
use moving_mesh::{Mesh,Derivatives,quadratic::{Compact,Quadratic}};
use std::{fmt::Write,collections::HashMap};
fn main(){let args:Vec<_>=std::env::args().collect();let root=&args[1];let out=&args[2];let origins=std::fs::read_to_string(format!("{out}/origins.txt")).unwrap();
for n in [128,256]{
 let mesh=Mesh::decode_lattice(&std::fs::read_to_string(format!("{root}/results/m1_mesh_cache/unit_{n}_0.15.mesh")).unwrap(),n,n,[1.;2],0.15).unwrap();let linear=Derivatives::build(&mesh,false).unwrap();let quad=Quadratic::build(&mesh).unwrap();let compact=Compact::build(&mesh,&linear).unwrap();let gradient=|v:&[f64]|compact.jets(&linear,&quad,v).unwrap().iter().map(|j|j.gradient).collect::<Vec<_>>();
 for stage in ["initial","checkpoint_0.25000000","final"]{
  let csv=std::fs::read_to_string(format!("{root}/results/m1_compact_probe/n{n}/{stage}.csv")).unwrap();let mut lines=csv.lines();let columns:HashMap<_,_>=lines.next().unwrap().split(',').enumerate().map(|(i,k)|(k,i)).collect();let rows:Vec<Vec<f64>>=lines.map(|l|l.split(',').map(|v|v.parse::<f64>().unwrap()).collect()).collect();assert_eq!(rows.len(),n*n);for(i,r)in rows.iter().enumerate(){assert_eq!(r[columns["id"]],i as f64);for(k,s)in ["x","y"].iter().enumerate(){assert!((r[columns[s]]-mesh.cells[i].centroid[k]).abs()<1e-14);}}
  let phi:Vec<_>=rows.iter().map(|r|r[columns["phi"]]).collect();let gp=gradient(&phi);let gx=gradient(&gp.iter().map(|g|g[0]).collect::<Vec<_>>());let gy=gradient(&gp.iter().map(|g|g[1]).collect::<Vec<_>>());
  let ga:Vec<_>=["reduced_ax","reduced_ay","reduced_az"].iter().map(|k|gradient(&rows.iter().map(|r|r[columns[k]]).collect::<Vec<_>>())).collect();
  let samples:Vec<_>=rows.iter().map(|r|auxiliary::VelocitySample{position:[r[columns["x"]],r[columns["y"]]],volume:r[columns["volume"]],velocity:[r[columns["vx"]],r[columns["vy"]],r[columns["vz"]]]}).collect();let origin=if stage=="final"{let l=origins.lines().find(|s|s.starts_with(&format!("{n} "))).unwrap();let x:Vec<_>=l.split_once(' ').unwrap().1.split(',').map(|v|v.parse::<f64>().unwrap()).collect();[x[0],x[1]]}else{[0.;2]};let aux=auxiliary::SmoothVelocity::build([1.;2],&samples,origin).unwrap();assert_eq!(aux.intervals(),4);
  let mut output=String::from("id,curl_grad_phi,lap_phi,grad_phi_x,grad_phi_y,div_a_recomputed,ux,uy,uz,hxx,hxy,hyx,hyy,hzx,hzy,distortion_x,distortion_y\n");
  for i in 0..rows.len(){let s=aux.sample(mesh.cells[i].centroid,0.).unwrap();let a=["reduced_ax","reduced_ay","reduced_az"].map(|k|rows[i][columns[k]]);let d:[f64;2]=std::array::from_fn(|axis|-(0..3).map(|k|s.jacobian[k][axis]*a[k]).sum::<f64>());let mut v=vec![gy[i][0]-gx[i][1],gx[i][0]+gy[i][1],gp[i][0],gp[i][1],ga[0][i][0]+ga[1][i][1]];v.extend(s.velocity);for k in 0..3{v.extend(&s.jacobian[k][..2]);}v.extend(d);writeln!(&mut output,"{i},{}",v.iter().map(|v|format!("{v:.17e}")).collect::<Vec<_>>().join(",")).unwrap();}
  std::fs::write(format!("{out}/operators_n{n}_{stage}.csv"),output).unwrap();
  let mut seams=String::from("axis,knot,transverse,epsilon,jump_d2ux,jump_d2uy,jump_d2uz,velocity_difference,jacobian_difference\n");
  for axis in 0..2{for knot in 0..4{for j in 0..16{for epsilon in [1e-5,5e-6]{let mut p=origin;p[axis]+=knot as f64/4.;p[1-axis]+=(j as f64+0.5)/16.;let at=|delta:f64|{let mut x=p;x[axis]+=delta;aux.sample(x,0.).unwrap()};let l2=at(-2.*epsilon);let l=at(-epsilon);let r=at(epsilon);let r2=at(2.*epsilon);let jump:[f64;3]=std::array::from_fn(|k|((r2.jacobian[k][axis]-r.jacobian[k][axis])-(l.jacobian[k][axis]-l2.jacobian[k][axis]))/epsilon);let dv=(0..3).map(|k|(r.velocity[k]-l.velocity[k]).powi(2)).sum::<f64>().sqrt();let dh=(0..3).flat_map(|k|(0..2).map(move|a|(r.jacobian[k][a]-l.jacobian[k][a]).powi(2))).sum::<f64>().sqrt();writeln!(&mut seams,"{axis},{knot},{},{epsilon:.17e},{:.17e},{:.17e},{:.17e},{dv:.17e},{dh:.17e}",(j as f64+0.5)/16.,jump[0],jump[1],jump[2]).unwrap();}}}}
  std::fs::write(format!("{out}/seams_n{n}_{stage}.csv"),seams).unwrap();println!("n{n} {stage} complete");
 }
}}
