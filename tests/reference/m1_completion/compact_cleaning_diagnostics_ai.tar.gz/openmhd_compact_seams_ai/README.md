# AI diagnostic review — auxiliary seams and compact fine-wave errors

Only sealed historical compact `aae382e` N128/N256 initial, quarter and final snapshots are used. Fourteen raw artifact digests, final run/manifest seals, source hashes, cached geometry and frozen moving-mesh library were verified. No evolution or solver/profile change was made here. `build_run.py` records exact Rust commands and source/binary hashes; it recomputes the actual compact cleaning operators and rebuilds the actual bicubic auxiliary field.

The final auxiliary origins are read exactly from the run summaries. The quarter origin was not serialized and is approximated by zero; using zero versus the saved final origin changes none of the tested seam-band memberships. Final origin displacements modulo the box are tiny (x about4e-11/−9e-12, y about7e-8/−7e-9). Quarter auxiliary reconstructions therefore remain a labelled approximation; the measured raw errors and discrete curl-gradient operator do not depend on that approximation.

## Measured localization and cleaning

For bands within2h of the auxiliary interpolation x seams (h=1/N):

| N | band volume | initial B-error energy fraction | final B-error energy fraction | final enrichment |
|---|---:|---:|---:|---:|
| 128 | .124992 | .124443 | .345999 | 2.768 |
| 256 | .0625002 | .0624857 | .188212 | 3.011 |

Seam-localized excess develops, but most total error remains outside these narrow bands. Bin boundaries (midpoints between interpolation knots) are distinguished in the report; they are not the same geometric lines. Final B-error enrichment at bin boundaries is .840 forN128 and1.423 forN256.

The recomputed div(A) matches the saved value exactly. Final `curl_Gc grad_Gc(phi)` RMS increases from .000955911 atN128 to .00443795 atN256. Its signed correlation with Bz exact-solution error is .2641/.4516. The A equation uses +grad(phi), so this is the sign of the instantaneous magnetic cleaning contribution. It is an instantaneous correlation, not a time-integrated causality or instability proof. Final phi minus physical-x Fourier modes k<=16 has RMS3.036e-7/3.105e-7; its small-scale amplitude does not decrease over this pair. Full phi RMS is about5.8e-5 at both resolutions.

The measured scalar is almost quasi-steady under the actual sign convention: `phi ≈ cs R div(A)/beta`, beta=.15. Final residual RMS is1.725e-7/1.476e-7. The decay time is `R/(beta cs)`, whereas the diffusive timestep bound is `beta R/cs`. The hypothesis phi=O(h^3) from only O(h^2) divergence truncation does not describe these data: gauge-driven div(A) is nonzero and increases with this refinement pair.

## Regularity qualification: do not infer an uncancelled kink

Direct one-sided auxiliary sampling gives finite jumps in the normal second derivatives of uy/uz, about4.074 RMS, stable as the sampling distance halves. u and its Jacobian differences tend to zero with that distance, consistent with the actual C1 bicubic construction.

However, a circular wave has a special cancellation. For uniform sinusoidal corner samples of phase increment theta and root spacing H, the Hermite normal second-derivative jump is

`[u''] = 4(1-cos(theta))/H * u'_corner`.

The transverse potential (Ay,Az) is parallel to the transverse circular velocity, and its tangent is orthogonal. Thus `[u''] dot A_transverse = 0` in the ideal one-dimensional circular-wave case. A generic C1 regularity concern alone therefore does not prove an O(1) kink in this wave's distortion source.

Using the measured rebuilt auxiliary second-derivative jumps with the analytic transverse A as a surrogate gives final distortion-derivative jump RMS6.638e-5 atN128 and1.664e-5 atN256. This decreases about4x. It is not a measurement of the full evolved A source jump: actual A contains gauge/error components. The exact ideal cancellation and this small residual must accompany any account of the seam evidence.

## Interpretation and artifacts

`analysis.json`, `regularity_checks.json`, raw derived operator/seam CSVs and two PNGs preserve all values and definitions. The six-panel map uses logical cell-index raster positions as an approximation to jittered geometry; each signed panel has its own scale, clipped at the99.5th percentile. Numerical band integrals use actual centroids and volume weights. Both PNGs were visually inspected. The distance plots compare interpolation seams and bin boundaries and normalize local RMS by global RMS.

This evidence supports a cleaning/regularity contribution and motivates the separately authorized no-forcing intervention. It does not justify changing the auxiliary interpolation or prove a unique cause of the failed compact convergence gate. The original compact order1.640159 remains a failure. No new profile or acceptance claim is made.
