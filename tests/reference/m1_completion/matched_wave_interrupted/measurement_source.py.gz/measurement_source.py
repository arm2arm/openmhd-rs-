from pathlib import Path
import sys,json,gzip,hashlib,subprocess,shlex
ROOT=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');sys.path.insert(0,str(ROOT/'scripts'))
from run_m1_wave_loop import evaluate
src=ROOT/'results/m1_matched_full';out=ROOT/'tests/reference/m1_completion/matched_wave_interrupted'
assert not out.exists();out.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
files={n:(src/n).read_bytes() for n in ('runs.json','manifest.json','provenance.json','interruption.json')}
control=json.loads(files['interruption.json']);runs=json.loads(files['runs.json']);manifest=json.loads(files['manifest.json'])
assert all(sha(files[n])==h for n,h in control['captured_metadata_sha256'].items())
checked={}
for name,r in runs.items():
 assert r['status']=='completed' and r['config']==manifest[name]
 for name2,h in r['sha256'].items():
  p=src/name/name2;assert sha(p.read_bytes())==h,str(p);checked[str(p)]=h
pairs=[]
for name,r in runs.items():
 if not name.endswith('_base'):continue
 other=name[:-5]+'_boost'
 if other not in runs:continue
 c=r['config'];pairs.append(dict(names=[name,other],case=c['case'],profile=c['profile'],n=c['n'],jitter=c['jitter'],parallel=c['parallel'],motion=c['motion_family'],dt=c['dt'],time=c['target']))
result=evaluate(src,runs,pairs,'bulk-frame-hll-matched-v1',False)
stopped=[]
for _,command in control['terminated_processes']:
 args=shlex.split(command)
 if '--output' in args:stopped.append(Path(args[args.index('--output')+1]).name)
assert not set(stopped)&set(runs)
unexecuted=sorted(set(manifest)-set(runs)-set(stopped))
assert set(runs)|set(stopped)|set(unexecuted)==set(manifest)
result['scope']='Explicit interrupted matched-profile evidence, not a complete acceptance packet. Full irregular travelling-wave order fails.'
result['execution_partition']={'completed':sorted(runs),'externally_stopped':sorted(stopped),'unexecuted':unexecuted}
result['temporal']='unexecuted: externally stopped before temporal cases'
files['summary.json']=(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n').encode();files['measurement_source.py']=Path(__file__).read_bytes()
for p,h in checked.items():assert sha(Path(p).read_bytes())==h
assert all((src/n).read_bytes()==b for n,b in files.items() if n not in ('summary.json','measurement_source.py'))
for n,b in files.items():(out/(n+'.gz')).write_bytes(gzip.compress(b,mtime=0))
record={'scope':result['scope'],'measurement_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'measurement_script_sha256':sha((ROOT/'scripts/run_m1_wave_loop.py').read_bytes()),'verified_raw_artifacts':len(checked),'uncompressed_sha256':{n:sha(b) for n,b in files.items()},'archive_sha256':{p.name:sha(p.read_bytes()) for p in out.glob('*.gz')}}
(out/'partial_archive_provenance.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print({k:len(v) for k,v in result['execution_partition'].items()});print('raw hashes:',len(checked));print([(r['jitter'],r['parallel'],r['motion'],r['gate'],r.get('finest_three_order')) for r in result['alfven_convergence']])
