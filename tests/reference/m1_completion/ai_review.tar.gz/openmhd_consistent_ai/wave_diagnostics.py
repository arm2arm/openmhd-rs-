from pathlib import Path
import json,hashlib,sys
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0')
out=Path('/tmp/openmhd_consistent_ai')
specs={}
for n in (64,128):
 specs[f'quadratic_{n}']=(root/f'results/m1_quadratic_probe/n{n}',root/'results/m1_quadratic_probe/runs.json',f'n{n}')
 specs[f'linear_{n}']=(root/f'results/m1_completion_full/alfven_bulk-frame-hll-v1_v0.0_j0.15_fixed_n{n}_base',root/'results/m1_completion_full/runs.json',f'alfven_bulk-frame-hll-v1_v0.0_j0.15_fixed_n{n}_base')
result={}
for name,(d,ledger,key) in specs.items():
 s=json.loads((d/'summary.json').read_text());record=json.loads(ledger.read_text())[key]
 print(name, 'steps',s['steps'],'fallback',s['hll_fallbacks'],'state_reject',s['rejected_state'],'condition',s.get('quadratic_condition'))
 result[name]={'summary':{k:v for k,v in s.items() if k not in ('auxiliary_roots','initial','final')},'stages':{}}
 for stage in ('initial','checkpoint_0.25000000','final'):
  p=d/(stage+'.csv');digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==record['sha256'][p.name],(name,stage,'hash')
  a=np.genfromtxt(p,delimiter=',',names=True); n=int(np.sqrt(len(a))); assert np.array_equal(a['id'],np.arange(n*n));t=float(a['time'][0]);assert (a['time']==t).all()
  weight=a['volume']/np.sum(a['volume']);phase=2*np.pi*(a['x']+t);ref={'rho':np.ones(len(a)),'p':np.ones(len(a))*.1,'vx':np.zeros(len(a)),'vy':.1*np.sin(phase),'vz':.1*np.cos(phase),'bx':np.ones(len(a)),'by':.1*np.sin(phase),'bz':.1*np.cos(phase)}
  err={k:a[k]-v for k,v in ref.items()};norm=lambda z:{'L1':float(np.sum(weight*np.abs(z))),'RMS':float(np.sqrt(np.sum(weight*z*z))),'max':float(np.max(np.abs(z)))}
  rec={'time':t,'sha256':digest,'errors':{k:norm(v) for k,v in err.items()},'B':norm(np.sqrt(sum(err[k]**2 for k in ('bx','by','bz')))),'div':{k:norm(a[k]) for k in ('div_a','div_b_ls','div_b_face','div_b_limited')},'limits':{'rho_min':float(min(a['rho'])),'p_min':float(min(a['p']))},'wave_fit':{}}
  X=np.column_stack([np.ones(len(a)),np.sin(phase),np.cos(phase)])
  for k in ('bx','by','bz','vx','vy','vz'):
   coeff=np.linalg.lstsq(X*np.sqrt(weight[:,None]),a[k]*np.sqrt(weight),rcond=None)[0];rem=a[k]-np.sum(X*coeff,axis=1)
   rec['wave_fit'][k]={'coefficients_const_sin_cos':coeff.tolist(),'residual':norm(rem),'fraction_error_squared_beyond_fundamental':float(np.sum(weight*rem**2)/(np.sum(weight*err[k]**2)+1e-99))}
  for k in ('by','bz'):
   v='v'+k[1:]; rec[k+'_v_match']=norm(a[k]-a[v]);rec[k+'_v_error_corr']=float(np.corrcoef(err[k],err[v])[0,1]) if t else None
  result[name]['stages'][stage]=rec
  print(' ',stage,'B',rec['B'],'componentsRMS',{k:round(v['RMS'],9) for k,v in rec['errors'].items()},'divBRMS',rec['div']['div_b_ls']['RMS'])
  if n==128 and stage=='final':
   print('  fits:',json.dumps(rec['wave_fit']))
   print('  budget max',max(abs(x) for x in s['final']['normalized_budget']))
(out/'wave_diagnostics.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
