from pathlib import Path
import numpy as np,json
out=Path('/tmp/openmhd_consistent_ai');data=[]
for n in (8,16):
 for j in ('0','0.15'):
  for pair in ('LL','QL','QQ'):
   L=np.loadtxt(out/f'clean_lap_{pair}_n{n}_j{j}.csv',delimiter=',');C=np.loadtxt(out/f'clean_curl_{pair}_n{n}_j{j}.csv',delimiter=',')
   e=np.linalg.eigvals(L);largest=float(max(e.real));cs=np.sqrt(1/6);damping=.15*cs*n*np.sqrt(np.pi)
   fullgrowth=np.max(((-damping+np.sqrt(damping**2+4*cs**2*e.astype(complex)))/2).real)
   rec=dict(n=n,jitter=float(j),pair=pair,max_real_eigenvalue=largest,min_real_eigenvalue=float(min(e.real)),positive_eigenvalue_count=int(sum(e.real>1e-8)),max_curl_row_abs_sum=float(max(np.sum(np.abs(C),axis=1))),uniform_radius_cleaning_growth_rate=float(fullgrowth))
   volume=np.loadtxt(out/f'clean_vol_n{n}_j{j}.csv'); gamma=.15*cs/np.sqrt(volume/np.pi)
   Z=np.zeros_like(L); I=np.eye(len(L)); first_order=np.block([[Z,I],[cs**2*L,-np.diag(gamma)]])
   rec['actual_radius_cleaning_growth_rate']=float(max(np.linalg.eigvals(first_order).real))
   dt=.3*.15*float(np.sqrt(volume/np.pi).min())/cs
   Gamma=np.diag(gamma)
   M=np.block([[I+.5*dt*dt*cs**2*L,dt*L-.5*dt*dt*(L*gamma[None,:])],[cs**2*(dt*I-.5*dt*dt*Gamma),I-dt*Gamma+.5*dt*dt*np.diag(gamma**2)]])
   rec['frozen_C1_dt']=dt
   rec['frozen_C1_max_amplification']=float(max(abs(np.linalg.eigvals(M))))
   data.append(rec);print(rec)
(out/'cleaning_spectrum.json').write_text(json.dumps(data,indent=2)+'\n')
