use moving_mesh::{Mesh,Derivatives,quadratic::Quadratic};
use std::fmt::Write;
fn main(){
 for n in [8,16]{for jitter in [0.,0.15]{
  let mesh=Mesh::lattice(n,n,[1.;2],jitter).unwrap();let linear=Derivatives::build(&mesh,false).unwrap();let quad=Quadratic::build(&mesh).unwrap();let count=n*n;
  std::fs::write(format!("/tmp/openmhd_consistent_ai/clean_vol_n{n}_j{jitter}.csv"),mesh.cells.iter().map(|c|format!("{:.17e}",c.volume)).collect::<Vec<_>>().join("\n")).unwrap();
  for pair in ["LL","QL","QQ"]{
   let mut lap=vec![vec![0.;count];count];let mut curl=lap.clone();
   for col in 0..count {let mut phi=vec![0.;count];phi[col]=1.;let g=if pair=="QQ"{quad.jets(&phi).unwrap().into_iter().map(|j|j.gradient).collect::<Vec<_>>()}else{linear.gradient(&phi).unwrap()};
    let gx:Vec<_>=g.iter().map(|g|g[0]).collect();let gy:Vec<_>=g.iter().map(|g|g[1]).collect();
    let gradient=|v:&[f64]|if pair=="LL"{linear.gradient(v).unwrap()}else{quad.jets(v).unwrap().into_iter().map(|j|j.gradient).collect::<Vec<_>>()};let ggx=gradient(&gx);let ggy=gradient(&gy);
    for i in 0..count{lap[i][col]=ggx[i][0]+ggy[i][1];curl[i][col]=ggy[i][0]-ggx[i][1];}
   }
   for (label,matrix) in [("lap",&lap),("curl",&curl)] {let mut out=String::new();for row in matrix{writeln!(&mut out,"{}",row.iter().map(|v|format!("{v:.17e}")).collect::<Vec<_>>().join(",")).unwrap();}std::fs::write(format!("/tmp/openmhd_consistent_ai/clean_{label}_{pair}_n{n}_j{jitter}.csv"),out).unwrap();}
   if n==16&&jitter==0.{let phi:Vec<_>=mesh.cells.iter().map(|c|(std::f64::consts::TAU*(6.*c.centroid[0]+5.*c.centroid[1])).sin()).collect();let norm=phi.iter().map(|p|p*p).sum::<f64>();let apply=|matrix:&Vec<Vec<f64>>|matrix.iter().map(|row|row.iter().zip(&phi).map(|(a,p)|a*p).sum::<f64>()).collect::<Vec<_>>();let l=apply(&lap);let c=apply(&curl);let eigen=l.iter().zip(&phi).map(|(l,p)|l*p).sum::<f64>()/norm;let curlcoef=c.iter().zip(&phi).map(|(c,p)|c*p).sum::<f64>()/norm;let residual=l.iter().zip(&phi).map(|(l,p)|(l-eigen*p).abs()).fold(0.,f64::max);println!("mode n16 k6,5 {pair}: lap eigen {eigen:.17e}, curl coefficient {curlcoef:.17e}, eigen residual {residual:.3e}");}
  }
 }}
}
