from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('/tmp/openmhd_consistent_ai');root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0')
paths={'quadratic':root/'results/m1_quadratic_probe/n128','linear':root/'results/m1_completion_full/alfven_bulk-frame-hll-v1_v0.0_j0.15_fixed_n128_base'}
spectrum=[];fields={}
for kind,d in paths.items():
 for stage in ('initial','checkpoint_0.25000000','final'):
  a=np.genfromtxt(d/(stage+'.csv'),delimiter=',',names=True);n=128;t=a['time'][0];phase=2*np.pi*(a['x']+t)
  vals={'Bz error':a['bz']-.1*np.cos(phase),'density error':a['rho']-1.,'phi':a['phi'],'div(A)':a['div_a']}
  if stage=='final':fields[kind]=(a,vals)
  # This is an index-grid diagnostic on jittered samples, not a physical-space modal decomposition.
  theta=2*np.pi*np.fft.fftfreq(n);xx,yy=np.meshgrid(theta,theta)
  denom=6+2*np.sqrt(2)
  qx=(2+4*np.cos(xx)+2*np.sqrt(2)*np.cos(yy))/denom
  qy=(2+4*np.cos(yy)+2*np.sqrt(2)*np.cos(xx))/denom
  mixed_symbol=-(np.sin(xx)**2*qx+np.sin(yy)**2*qy)*n*n
  band=mixed_symbol>1e-8
  for field,v in vals.items():
   F=np.fft.fft2(v.reshape(n,n));power=np.abs(F)**2
   inds=np.argsort(power.ravel())[-4:][::-1]
   spectrum.append({'profile':kind,'stage':stage,'field':field,'fraction_power_in_regular_mixed_cleaning_positive_symbol_region':float(power[band].sum()/power.sum()) if power.sum() else None,'largest_index_modes':[(int(round(np.fft.fftfreq(n)[i%n]*n)),int(round(np.fft.fftfreq(n)[i//n]*n)),float(power.ravel()[i]/power.sum())) for i in inds] if power.sum() else []})
fig,axes=plt.subplots(2,3,figsize=(13,7),constrained_layout=True)
for col,field in enumerate(('Bz error','density error','phi')):
 lim=max(np.max(np.abs(v[field])) for a,v in fields.values())
 for row,kind in enumerate(('quadratic','linear')):
  a,vs=fields[kind];ax=axes[row,col];im=ax.scatter(a['x'],a['y'],c=vs[field],s=2,cmap='RdBu_r',vmin=-lim,vmax=lim,rasterized=True);ax.set(xlim=(0,1),ylim=(0,1),aspect='equal',title=f'{kind}, {field}',xlabel='x',ylabel='y');fig.colorbar(im,ax=ax,shrink=.8)
fig.suptitle('N128, jitter 0.15, t=1: archived wave diagnostics (shared scale per column)')
fig.savefig(out/'wave_spatial.png',dpi=160)
(out/'wave_index_spectrum.json').write_text(json.dumps(spectrum,indent=2)+'\n')
for r in spectrum:
 if r['profile']=='quadratic' and r['stage']=='final':print(r)
