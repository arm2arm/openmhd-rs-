# Separate AI review probes — consistent and matched M1 experiments

Read-only review artifacts created on 2026-11-05. Repository: `/Users/arm2arm/orca/workspaces/openmhd-rs-/M0`. No solver files were edited by the reviewer. These are small numerical diagnostics and implementation checks, not full M1 acceptance evidence or human peer review.

## Revisions and scope

- Historical comparator: `62e3528`.
- Consistent implementation: `cbc7d80`; runner hardening: `042392a`.
- Prospective matched-gradient plan: `83edecd`; implementation reviewed: `f9a11f0`.
- Existing quadratic-only physical probe: `73dd508`, before QR correction `989c6a9`. Its archived results are preserved. The cleaning-operator probes use corrected, well-conditioned quadratic stencils from the later implementation. They do not retroactively relabel the physical execution.

`old.rs` embeds the exact historical general/operators/auxiliary/gauge modules. `new.rs` embeds the exact same modules from `cbc7d80`; both include the same independent driver. Embedded-source equality against those Git revisions was verified. Both link the same `moving_mesh` and `mhd_core` libraries; the new moving-mesh additions do not alter historical derivative methods. Compiler, linked-library hashes and reviewed revisions are in `provenance.json`.

## Reproduce

Use the pinned Rust toolchain from the repository. Exact orchestration for compiling the Rust probes and comparing their output:

```sh
python3 /tmp/openmhd_consistent_ai/reproduce_rust.py --repo /Users/arm2arm/orca/workspaces/openmhd-rs-/M0
/Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_consistent_ai/cleaning_spectrum.py
/Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_consistent_ai/wave_diagnostics.py
/Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_consistent_ai/wave_spatial.py
```

The orchestration runs `cargo build --locked -p moving-mesh -p mhd-core`, then `rustc --edition=2024 -Awarnings SOURCE -L dependency=REPO/target/debug/deps --extern moving_mesh=RLIB --extern mhd_core=RLIB -o OUTPUT` for each saved source. It runs the resulting programs and requires `old.txt == new.txt` byte for byte. Use the recorded compatible moving-mesh revision when reproducing; later stencil changes can change diagnostic results. The scripts currently retain the original absolute repository and `/tmp/openmhd_consistent_ai` locations.

Focused checks independently executed by the reviewer:

```sh
/Users/arm2arm/.cargo/bin/cargo test --locked -p mhd-vector-pot consistent
/Users/arm2arm/.cargo/bin/cargo test --locked -p mhd-vector-pot matched_cleaning
python3 scripts/test_m1_completion.py
python3 scripts/test_m1_wave_loop.py
```

Results: four consistent tests, two matched-cleaning tests, five completion-measurement tests and seven wave-measurement tests passed. `matched_tests.log` records the matched command. The parent separately ran the complete workspace tests, formatting and Clippy; those are not claimed as independent reruns here.

## Historical behavior and passive restriction

`old.rs`, `new.rs`, `old.txt`, `new.txt`: 24 cases = four historical profiles × fixed/rigid/fluid motion × limited/unlimited reconstruction. Each uses a 6×8 rectangular jitter .15 mesh, nonuniform three-component A/v, nonzero phi/mean B and six steps to t=.003. Potential, phi, conserved quantities, generator positions and gauge offset are serialized by f64 bits. Every output is bit-identical.

`passive_equivalence.rs` and `.txt`: 24 cases = two rectangular resolutions × regular/jitter .15 × original/reversed IDs × constant/smooth/jump data. It compares the actual private Passive rate against the actual general PotentialStage with zero source/distortion/cleaning and the same relative advection velocity. The maximum rate difference is exactly zero. This is operator equivalence, not a full nonlinear stability test.

## Cleaning diagnostics

`cleaning_operator.rs` applies the actual derivative methods to cell basis vectors, exporting dense operators for N8/16, regular and jitter .15 meshes:

- LL = div_linear grad_linear; its curl uses the same linear derivative.
- QL = div_quadratic grad_linear; its curl uses quadratic derivatives.
- QQ = div_quadratic grad_quadratic; its curl uses quadratic derivatives.

`clean_lap_*`, `clean_curl_*`, `clean_vol_*` contain the matrices/volumes. `cleaning_mode_results.txt` and `cleaning_operator.txt` contain the regular N16 manufactured Fourier result for phi=sin[2pi(6x+5y)]. QL has Laplacian eigenvalue +65.590957985 and curl coefficient +7.200097676, with residual below 7e-13. QQ has Laplacian eigenvalue -12.565349767 and roundoff curl.

`cleaning_spectrum.py`, `.json`, `.txt` calculate eigenvalues and a constant-sound-speed (cs²=1/6) cleaning subsystem with alpha=1, beta=.15 and actual radii sqrt(V/pi). The largest QL Laplacian eigenvalues are +20.5041/+82.0166 (regular N8/N16) and +4.49113/+19.1179 (jitter .15). Actual-radius cleaning growth rates are +1.46475/+2.92950 and +.53217/+1.11873, respectively. LL/QQ controls have no positive mode above numerical roundoff in these samples.

The script also evaluates the exact linear map of the frozen-C1 stages for fixed geometry, using dt=.3*.15*min(r)/cs. With d=div(A), L=div grad, Gamma=diag(.15 cs/r), the map is:

```
d_new   = (I+.5 dt² cs² L)d + (dt L-.5 dt² L Gamma)phi
phi_new = cs²(dt I-.5 dt² Gamma)d + (I-dt Gamma+.5 dt² Gamma²)phi
```

QL has amplification above one (regular 1.01141148; jitter N8 1.00363304, N16 1.00387500). LL/QQ have maximum amplification one to roundoff. The defect is present in the spatial operators, so a smaller timestep cannot remove its semidiscrete growth. These results exclude fluid coupling/advection and do not prove general stability of the matched candidate. QQ curl-grad is still nonzero on irregular meshes (N16 infinity operator norm 40.23); no arbitrary irregular-mesh cancellation is claimed.

## Archived physical snapshots

`wave_diagnostics.py` reads N64/128 quadratic-only and linear HLL wave snapshots at t=0,.25,1. It verifies each CSV hash against its recorded run ledger, checks IDs/times, computes volume-weighted errors and fits constant/sin/cos at actual physical x. Exact selected run records and the contemporaneous full-ledger hashes are captured in `physical_input_records.json`; the full-study ledger can still acquire new runs. Raw CSV paths and hashes are recorded in `wave_diagnostics.json`; `.txt` is a concise console record.

The quadratic N128 final error is concentrated in Bz: component RMS errors (Bx,By,Bz)=(1.48e-4,2.74e-4,3.09e-3), with vz RMS error 2.44e-3. The fundamental fit leaves 97.9% of Bz error energy outside the constant/sin/cos subspace. Linear N128 Bz RMS error is 8.86e-5. Both retain positive states and conservative budgets; this does not imply accuracy.

`wave_spatial.py` creates `wave_spatial.png` (visually inspected) and `wave_index_spectrum.json`. The plot uses actual cell centers and shared color limits between profiles. The FFT is explicitly an index-grid diagnostic on jittered samples, not an exact physical-space modal decomposition. Dominant Bz index peaks near (±50,∓19) do not by themselves establish a causal mechanism. Only 14.2% of final quadratic Bz index-spectrum power lies in the positive-symbol region of the ideal regular QL operator. Mixed cleaning is a proven operator defect, but the full nonlinear failure is not attributed to it without controlled matched-profile evidence.

The completed linear irregular-wave ladder was independently remeasured from hash-checked CSVs (`linear_completed_ladder.json`): finest-three order 1.17745 versus required 1.8. This failed order, quadratic-only N128 refinement deterioration and consistent mixed N128 error remain failed evidence. No threshold was adjusted and no M1 acceptance is given by this review.
