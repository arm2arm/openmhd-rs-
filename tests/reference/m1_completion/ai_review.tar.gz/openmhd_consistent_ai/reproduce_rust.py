from pathlib import Path
import argparse,subprocess,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args();root=a.repo.resolve();out=Path(__file__).resolve().parent
cargo=Path.home()/'.cargo/bin/cargo';rustc=cargo.with_name('rustc')
subprocess.run([str(cargo),'build','--locked','-p','moving-mesh','-p','mhd-core'],cwd=root,check=True)
deps=root/'target/debug/deps';libs={name:max(deps.glob('lib'+name+'-*.rlib'),key=lambda p:p.stat().st_mtime) for name in ['moving_mesh','mhd_core']}
for name in ['old','new','passive_equivalence','cleaning_operator']:
 cmd=[str(rustc),'--edition=2024','-Awarnings',str(out/(name+'.rs')),'-L','dependency='+str(deps)]
 for lib,path in libs.items():cmd+=['--extern',lib+'='+str(path)]
 cmd+=['-o',str(out/name)];subprocess.run(cmd,check=True)
 with (out/(name+'.txt')).open('w') as f:subprocess.run([str(out/name)],stdout=f,check=True)
assert (out/'old.txt').read_bytes()==(out/'new.txt').read_bytes()
print('Historical24 cases: bit-identical. See passive_equivalence.txt and cleaning_operator.txt.')
