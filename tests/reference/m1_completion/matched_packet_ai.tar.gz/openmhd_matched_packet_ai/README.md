# Separate AI review: completed matched remaining packet

Bounded evidence/report approval, not M1 acceptance. Execution revision `f9a11f04d7de943920a0be07b3033df328796e0d`; reanalysis revision `bb7361804e41d472a52533885e544e286c3f197b`. The matched wave order remains failed at .77243, and three of 22 completed Alfvén boost comparisons fail the registered primary normalization. Compact is a separate experiment and inherits no matched physical acceptance.

`check.py` independently validates all 26 compressed/uncompressed archive files, original/measurement/reuse seals, execution/measurement Git source hashes, reference hashes, all 154 recorded raw artifact hashes, exact 31-case accounting (16 passive, 3 Brio, 12 vortex), 27 reused + 4 new origins, all 15 projection seals and 60 recomputed reference norms. It separately recomputes 16 passive A errors, exact comoving A/B equality, six vortex boost comparisons and pairing geometry, and evaluates all nine remaining-case ladder criteria. Maximum independently recomputed normalized boost L1 is 9.03505838754035e-14; largest conservative-budget residual is 2.4509949509206257e-13. `reference_probe.py` additionally verifies every archived Brio per-cell reference average directly against the fine reference slabs and three regular vortex raw-to-bin projections using aligned square cells. This independent shortcut is valid only for those regular meshes; it is not a replacement for polygon overlap on irregular meshes.

The archive was independently recreated with the current archive CLI; all 26 compressed payload hashes match. Six PNGs were reproduced from archived compressed versus raw measured inputs and match the documentation byte for byte. Every figure was visually inspected. Wave failure/incomplete labels, missing temporal ladder, common vortex bins/color limits, Brio row-mean plot versus per-cell absolute errors, and passive analytic roundoff versus exact discrete comoving invariance remain explicit.

Reviewed the measurement-only status change in run_m1_wave_loop.py: raw formulas, scales and thresholds are unchanged; both conventions remain present; `primary_normalization=wave_amplitude` and `acceptance_status` make the registered primary gate explicit for valid completed wave pairs. The alternate-only-pass status now says the primary gate failed. All 8 wave measurement fixtures pass, including both-pass, alternate-only-pass and both-fail controls. Earlier sealed archives retain their original status strings; the matched report correctly identifies the N64 regular primary failure despite its old `normalization clarification pending` label.

No solver edits or physical simulations were performed. No new acceptance claim is made. Large raw CSVs remain in original execution paths; source scripts below retain those paths.

## Reproduction

From `/Users/arm2arm/orca/workspaces/openmhd-rs-/M0`:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_matched_packet_ai/check.py
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python /tmp/openmhd_matched_packet_ai/reference_probe.py
python3 scripts/archive_m1_completion.py --remaining-dir results/m1_matched_remaining_final --output-dir /tmp/openmhd_matched_packet_ai/recreated_archive
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python scripts/plot_m1_completion.py --wave-dir tests/reference/m1_completion/matched_wave_interrupted --remaining-dir tests/reference/m1_completion/matched_remaining/remaining --output-dir /tmp/openmhd_matched_packet_ai/figures_archive
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 /Users/arm2arm/.venvs/openmhd-plot/bin/python scripts/plot_m1_completion.py --wave-dir /tmp/openmhd_matched_packet_ai/wave_uncompressed --remaining-dir results/m1_matched_remaining_final --output-dir /tmp/openmhd_matched_packet_ai/figures_raw
python3 scripts/test_m1_wave_loop.py
```

The recreation destination must be fresh. `wave_uncompressed/summary.json` is the exact decompressed partial measured summary, not an unexecuted full-wave result. `check.json`, `reference_probe.json`, `figure_check.json`, test logs and `provenance.json` record results. `checksums.json` lists review files. The recreated archive and figures duplicate the original sealed artifacts and may be omitted when archiving this review, with their hashes retained.
