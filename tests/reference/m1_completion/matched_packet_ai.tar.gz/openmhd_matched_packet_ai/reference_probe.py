import csv,gzip,json,math
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');arc=root/'tests/reference/m1_completion/matched_remaining/remaining';raw=root/'results/m1_matched_remaining_final';out=Path('/tmp/openmhd_matched_packet_ai');largest=0.;count=0
with gzip.open(root/'tests/reference/external_mhd/brio_8192.csv.gz','rt') as f:ref=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]
for n in [256,512,1024]:
 rows=json.loads(gzip.decompress((arc/f'brio_n{n}/projection.json.gz').read_bytes()));cells=np.genfromtxt(raw/f'brio_n{n}/final.csv',delimiter=',',names=True)
 assert len(cells)==4*n and np.max(abs(cells['volume']-2*.125/(4*n)))<1e-16
 for r in rows:
  c=cells[r['id']];assert r['x']==c['x'];left=max(.5,c['x']-1/n);right=min(1.5,c['x']+1/n);weights=[]
  for j in range(max(0,int(math.floor((left-.5)*len(ref)))),min(len(ref),int(math.ceil((right-.5)*len(ref))))):
   overlap=max(0.,min(right,.5+(j+1)/len(ref))-max(left,.5+j/len(ref)))
   if overlap:weights.append((j,overlap))
  assert abs(sum(w for _,w in weights)-(right-left))<1e-14
  for k in ['rho','p','vx','by']:
   assert r['candidate'][k]==c[k];mean=math.fsum(w*ref[j][k] for j,w in weights)/(right-left);d=abs(mean-r['reference'][k]);assert d<1e-13;largest=max(largest,d);count+=1
vortexdiff=0.
for n in [64,128,256]:
 a=np.genfromtxt(raw/f'vortex_n{n}_j0.0_b0/final.csv',delimiter=',',names=True);stored=json.loads(gzip.decompress((arc/f'vortex_n{n}_j0.0_b0/projection.json.gz').read_bytes()));assert len(a)==n*n and np.max(abs(a['volume']-1/n**2))<1e-15
 ids=(np.floor(a['y']*64).astype(int)%64)*64+np.floor(a['x']*64).astype(int)%64
 for k in ['rho','p','vx','vy','vz','bx','by','bz']:
  projected=np.bincount(ids,weights=a['volume']*a[k],minlength=4096)*4096;err=float(np.max(abs(projected-np.array([r[k] for r in stored]))));assert err<1e-12;vortexdiff=max(vortexdiff,err)
r={'brio_reference_cell_averages_verified':count,'brio_max_reference_average_difference':largest,'regular_vortex_raw_to_bin_projections_verified':3,'regular_vortex_max_projection_difference':vortexdiff};print(json.dumps(r,indent=2));(out/'reference_probe.json').write_text(json.dumps(r,indent=2)+'\n')
