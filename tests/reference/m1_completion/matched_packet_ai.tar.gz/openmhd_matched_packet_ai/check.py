import csv,gzip,hashlib,json,math,subprocess
from pathlib import Path
import numpy as np
root=Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/M0');arc=root/'tests/reference/m1_completion/matched_remaining';raw=root/'results/m1_matched_remaining_final';out=Path('/tmp/openmhd_matched_packet_ai');sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((arc/'archive_provenance.json').read_text());blobs={}
for name,h in meta['archive_sha256'].items():assert sha((arc/name).read_bytes())==h
for name,h in meta['uncompressed_sha256'].items():
 b=gzip.decompress((arc/name).read_bytes());assert sha(b)==h;blobs[name.removeprefix('remaining/').removesuffix('.gz')]=b
load=lambda n:json.loads(blobs[n]);s=load('summary.json');r=load('runs.json');m=load('manifest.json');prov=load('execution_provenance.json');meas=load('measurement_provenance.json');reuse=load('reuse_origin.json')
assert set(s['runs'])==set(r)==set(m) and len(r)==31
for file,key in [('summary.json','summary_sha256'),('execution_provenance.json','execution_provenance_sha256'),('execution_summary.json','execution_summary_sha256'),('runs.json','raw_runs_sha256')]:assert sha(blobs[file])==meas[key]
for file in ['manifest.json','runs.json']:assert sha(blobs[file])==prov['result_sha256'][file]
assert sha(blobs['execution_summary.json'])==prov['result_sha256']['summary.json']
assert sha(blobs['reuse_origin.json'])==prov['reuse_origin_sha256']
for name,key in [('provenance.json','provenance_sha256'),('runs.json','runs_sha256'),('manifest.json','manifest_sha256')]:assert sha(blobs['reuse_source/'+name])==reuse['origin'][key] and load('reuse_source/'+name)==reuse[name.removesuffix('.json')]
for file,h in prov['sources_sha256'].items():assert sha(subprocess.check_output(['git','show',prov['revision']+':'+file],cwd=root))==h,(file,'execution source')
for file,h in meas['measurement_sources_sha256'].items():assert sha(subprocess.check_output(['git','show',meas['measurement_revision']+':'+file],cwd=root))==h,(file,'measurement source')
for file,h in prov['external_reference_hashes'].items():assert sha((root/'tests/reference/external_mhd'/file).read_bytes())==h
reused=0;count=0;cases={};projected=0;refnorms=0
with gzip.open(root/'tests/reference/external_mhd/vortex_512.csv.gz','rt') as f:ref=list(csv.DictReader(f))
for name,run in r.items():
 assert run['status']=='completed' and run['exit_code']==0 and run['config']==m[name];assert s['runs'][name]['config']==m[name] and s['runs'][name]['status']=='completed'
 if 'execution_origin' in run:
  reused+=1;assert run['execution_origin']==reuse['origin'];old=reuse['runs'][name];assert all(run[k]==v for k,v in old.items())
 hashes=run.get('artifacts_sha256',run.get('sha256'));case=run['config']['case'];cases[case]=cases.get(case,0)+1
 for file,h in hashes.items():assert sha((raw/name/file).read_bytes())==h,(name,file);count+=1
 if case in ['brio','vortex']:
  b=blobs[name+'/projection.json'];sr=s['runs'][name];assert sha(b)==sr['projection_sha256']==sha((raw/name/'projection.json').read_bytes());rows=json.loads(b);projected+=1
  if case=='brio':
   V=math.fsum(x['volume'] for x in rows);err={k:math.fsum(x['volume']*abs(x['candidate'][k]-x['reference'][k]) for x in rows)/V for k in ['rho','p','vx','by']}
  else:
   assert len(rows)==len(ref)==4096;err={k:math.fsum(abs(x[k]-float(y[k])) for x,y in zip(rows,ref))/len(ref) for k in ['rho','p','bx','by']}
  for k,v in err.items():assert abs(v-sr['reference_L1'][k])<1e-14;refnorms+=1
assert cases=={'brio':3,'passive':16,'vortex':12} and reused==27
assert len(s['gates'])==9 and all(g['status']=='pass' for g in s['gates']);assert len(s['vortex_boost_pairs'])==6 and all(p['status']=='pass' for p in s['vortex_boost_pairs'])
# Recompute analytical passive A error and exact comoving drift, independently.
for name,run in s['runs'].items():
 if run['config']['case']!='passive':continue
 a=np.genfromtxt(raw/name/'initial.csv',delimiter=',',names=True);b=np.genfromtxt(raw/name/'final.csv',delimiter=',',names=True);n=run['config']['n'];assert len(a)==len(b)==n*n and np.array_equal(b['id'],np.arange(n*n)) and (a['time']==0).all() and (b['time']==1).all();w=b['volume']/np.sum(b['volume']);amplitude=.001/math.sqrt(4*math.pi);radius=np.hypot((b['x']-2)%1-.5,(b['y']-1)%1-.5);expected=amplitude*np.maximum(0,.3-radius);e=float(np.sum(w*abs(b['az']-expected)))/(amplitude*.3);assert abs(e-run['relative_A_L1'])<1e-14
 if run['config']['comoving']:assert all(np.array_equal(a[k],b[k]) for k in ['az','bx','by','bz'])
# Recompute vortex joint-boost scalar/vector errors and pairing geometry.
pairmax=0.;normdiff=0.
for pair in s['vortex_boost_pairs']:
 a,b=[np.genfromtxt(raw/name/'final.csv',delimiter=',',names=True) for name in pair['names']];assert len(a)==len(b) and np.array_equal(a['id'],b['id']) and (a['time']==.5).all() and (b['time']==.5).all();w=a['volume']/np.sum(a['volume']);assert np.max(abs(a['volume']-b['volume'])/a['volume'])<1e-10
 for axis,shift in [('x',2.),('y',-1.)]:assert np.max(abs((b[axis]-a[axis]-shift*.5+.5)%1-.5))<1e-8
 errors={k:b[k]-a[k] for k in ['rho','p']};errors['B']=np.sqrt(sum((b[k]-a[k])**2 for k in ['bx','by','bz']));errors['v']=np.sqrt(sum((b[k]-a[k]-u)**2 for k,u in [('vx',2.),('vy',-1.),('vz',0.)]));errors['energy']=b['energy']-b['rho']*(2*b['vx']-b['vy'])+2.5*b['rho']-a['energy']
 for k,v in errors.items():
  rel=float(np.sum(w*abs(v)))/pair['normalization_scales'][k];normdiff=max(normdiff,abs(rel-pair['relative_L1'][k]));assert abs(rel-pair['relative_L1'][k])<2e-15 and rel<1e-8;pairmax=max(pairmax,rel)
maxbudget=max(max(abs(v) for v in run['summary']['final']['normalized_budget']) for run in s['runs'].values() if run['config']['case']!='passive')
assert all(run['summary']['final']['rho_min']>0 and run['summary']['final']['p_min']>0 for run in s['runs'].values() if run['config']['case']!='passive')
assert maxbudget<1e-10
assert s['reference_refinement_uncertainty']==json.loads((root/'tests/reference/external_mhd/provenance.json').read_text())['reference_changes']
for jitter in [0.,.15]:
 for comoving in [False,True]:
  rr=sorted([x for x in s['runs'].values() if x['config']['case']=='passive' and x['config']['jitter']==jitter and x['config']['comoving']==comoving],key=lambda x:x['config']['n']);assert [x['config']['n'] for x in rr]==[32,64,128,256]
  if comoving:assert max(max(x['discrete_A_relative_max'],x['discrete_B_relative_max']) for x in rr)<=1e-10
  else:assert all(a['relative_A_L1']>b['relative_A_L1'] for a,b in zip(rr,rr[1:])) and rr[-1]['relative_A_L1']<=.1
 for boosted in [False,True]:
  rr=[s['runs'][f'vortex_n{n}_j{jitter}_b{int(boosted)}'] for n in [64,128,256]]
  for key,limit in [('rho',.06),('p',.1),('bx',.1),('by',.1)]:assert rr[-1]['scaled_reference_L1'][key]<=limit and rr[-1]['scaled_reference_L1'][key]<rr[0]['scaled_reference_L1'][key]
  assert all(x['mean_B_relative_drift']<=.001 and x['limited_divB_dimensionless_rms']<=.1 for x in rr)
brio=[s['runs'][f'brio_n{n}'] for n in [256,512,1024]]
for key,limit in [('rho',.03),('p',.04),('vx',.03),('by',.04)]:assert brio[-1]['reference_L1'][key]<=limit and brio[-1]['reference_L1'][key]<brio[0]['reference_L1'][key]
assert all(x['bx_max_error']<=1e-8 and x['signal_travel_upper']<.45 for x in brio)
wave=json.loads(gzip.decompress((root/'tests/reference/m1_completion/matched_wave_interrupted/summary.json.gz').read_bytes()));pairs=[x for x in wave['pairs'] if x['case']=='alfven' and 'relative_L1' in x];failures=[{'n':x['n'],'jitter':x['jitter'],'parallel':x['parallel'],'motion':x['motion'],'primary_max':max(x['relative_L1']['wave_amplitude'].values()),'legacy_status':x.get('status',x.get('classification'))} for x in pairs if max(x['relative_L1']['wave_amplitude'].values())>1e-8];assert len(pairs)==22 and len(failures)==3
res={'wave_primary_boost_failed':failures,'wave_primary_boost_counts':{'completed':22,'pass':19,'fail':3},'archive_files_verified':len(blobs),'raw_artifact_hashes':count,'case_counts':cases,'reused':reused,'new':31-reused,'projection_seals':projected,'independent_reference_norms':refnorms,'passive_A_errors_recomputed':16,'boost_pairs_recomputed':6,'max_relative_boost_L1':pairmax,'max_boost_norm_difference':normdiff,'max_normalized_budget':maxbudget,'gate_count':len(s['gates']),'execution_revision':prov['revision'],'measurement_revision':meas['measurement_revision']}
(out/'check.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
