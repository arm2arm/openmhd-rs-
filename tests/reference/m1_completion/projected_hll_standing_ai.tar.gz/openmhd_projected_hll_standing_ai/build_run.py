from pathlib import Path
import subprocess,json,hashlib,datetime,time
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();prior=json.loads((p/'parent_provenance.json').read_text());rustc='/Users/arm2arm/.cargo/bin/rustc';mesh=next(Path(f) for f in prior['library_sha256'] if 'libmoving_mesh-' in f);assert sha(mesh.read_bytes())==prior['library_sha256'][str(mesh)]
for f,h in prior['source_sha256'].items():assert sha((p/(Path(f).stem+'_frozen.rs')).read_bytes())==h
source=''
for m in ['gauge','auxiliary','operators','general']:
 code=(p/(m+'_frozen.rs')).read_text().replace('//!','//')
 if m=='general':code+='\n'+(p/'initial_and_rates.rs').read_text()+'\n'+(p/'evolution_extra.rs').read_text()
 source+='mod '+m+' {\n'+code+'\n}\n'
source+='fn main(){general::audit_evolution("'+str(p)+'");}\n';(p/'evolution.rs').write_text(source)
commands=[[rustc,'--edition=2024','-O','-Awarnings','--crate-name','mhd_core','--crate-type','rlib',str(p/'core.rs'),'-o',str(p/'libmhd_core.rlib')],[rustc,'--edition=2024','-O','-Awarnings',str(p/'evolution.rs'),'-L','dependency='+str(mesh.parent),'--extern','mhd_core='+str(p/'libmhd_core.rlib'),'--extern','moving_mesh='+str(mesh),'-o',str(p/'evolution')],[str(p/'evolution')]]
for c in commands[:2]:subprocess.run(c,check=True)
prov=dict(scope='AI diagnostic only: same two actual N8 finite-standing-wave perturbations, full two-wave HLL plus projected limiting; no production or acceptance change',revision=prior['revision'],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),only_scientific_patch='Replace subsonic HLLD selection with None to force existing HLL fallback; preserve original SL/SR, supersonic upwind, symmetric A completion, all limiting and timestep choices',commands=commands,configuration=dict(n=8,parallel_velocity=1,mean_B=[1,0,0],limited=True,dt_cap=.0002,times=[0,.0002,.01,.05,.1,.25,.5,1],amplitudes=[1e-6,1e-8],signs=[1,-1]),mesh_library=dict(path=str(mesh),sha256=sha(mesh.read_bytes())),inputs={f.name:sha(f.read_bytes()) for f in p.iterdir() if f.is_file()},rustc=subprocess.check_output([rustc,'--version','--verbose'],text=True));(p/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n');start=time.monotonic()
with (p/'evolution.log').open('w') as f:r=subprocess.run(commands[2],stdout=f,stderr=subprocess.STDOUT)
prov['execution']=dict(status='completed' if r.returncode==0 else 'failed',exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,artifacts={f.name:sha(f.read_bytes()) for f in p.iterdir() if f.is_file() and f.name!='provenance.json'});(p/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n');print(prov['execution']['status'],prov['execution']['elapsed_seconds']);raise SystemExit(r.returncode)
