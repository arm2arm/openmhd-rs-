from pathlib import Path
import hashlib,json,csv
import numpy as np
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;old=p.parent/'openmhd_projected_standing_operator_ai';sha=lambda b:hashlib.sha256(b).hexdigest();prov=json.loads((p/'provenance.json').read_text())
for f,h in prov['execution']['artifacts'].items():assert sha((p/f).read_bytes())==h
assert prov['execution']['status']=='completed' and prov['execution']['exit_code']==0
assert (p/'core.rs').read_text()==(p/'core_frozen.rs').read_text().replace('hlld(eos, l, r, [sl, sr], [pl, pr])','None::<(State, State)>')
for f,h in json.loads((old/'checksums.json').read_text()).items():assert sha((old/f).read_bytes())==h
for name in ['rate_limitedtrue_mode0_real','rate_limitedtrue_mode6_imag']:assert (p/(name+'.csv')).read_bytes()==(old/(name+'.csv')).read_bytes()
rows={label:list(csv.DictReader((d/'evolution.csv').open())) for label,d in [('projected_HLLD',old),('projected_full_HLL',p)]};data={};times=[0,.0002,.01,.05,.1,.25,.5,1]
for file in p.glob('*_t0.csv'):assert file.read_bytes()==(old/file.name).read_bytes()
fig,axes=plt.subplots(1,2,figsize=(10.5,4),constrained_layout=True)
for ax,name in zip(axes,['rate_limitedtrue_mode0_real','rate_limitedtrue_mode6_imag']):
 data[name]={}
 for label,rr in rows.items():
  cases=[x for x in rr if x['direction']==name and x['limited']=='true'];final=[x for x in cases if float(x['time'])==1];history=[x for x in cases if float(x['amplitude'])==1e-8 and x['sign']=='1'];assert [float(x['time']) for x in history]==times;data[name][label]=dict(final_physical_gain=[min(float(x['physical_gain']) for x in final),max(float(x['physical_gain']) for x in final)],history_plus_1e_8={x['time']:{k:float(x[k]) for k in ['physical_gain','B_gain','v_gain','A_gain','phi_gain']} for x in history});ax.plot(times,[float(x['physical_gain']) for x in history],'-o',label=label.replace('_',' '))
 ax.set_yscale('log');ax.set_xlabel('time');ax.set_ylabel('B/v perturbation norm / initial norm');ax.grid(alpha=.25);ax.legend();ax.set_title('Leading real coordinate direction' if 'mode0' in name else 'Strongest actual one-step direction')
fig.suptitle('Same actual N8 projected perturbations, full HLL flux isolation\nFinite-time norm comparison; no fitted exponential or acceptance claim');fig.savefig(p/'hll_comparison.png',dpi=170);plt.close(fig)
(p/'comparison.json').write_text(json.dumps(dict(scope='Finite-time diagnostic on two fixed HLLD-derived directions, not full-HLL optimal directions or stability spectrum',all_initial_snapshots_and_directions_bit_identical=True,parent_checksums_sha256=sha((old/'checksums.json').read_bytes()),results=data),indent=2)+'\n');print(json.dumps(data,indent=2))
