from pathlib import Path
import csv,json,hashlib
import numpy as np
p=Path(__file__).resolve().parent;rows=list(csv.DictReader((p/'evolution.csv').open()));assert len(rows)==64;normnames=['physical_Bv_norm','B_norm','v_norm','A_norm','phi_norm','energy_density_norm'];gains=['physical_gain','B_gain','v_gain','A_gain','phi_gain','energy_gain'];initial={};records=[];maxdiff=0.;checks=0
for row in rows:
 t=float(row['time']);limited=row['limited'];amp=float(row['amplitude']);sign=row['sign'];prefix=f"evolution_{row['direction']}_limited{limited}_e";file=next(x for x in p.glob(prefix+'*_sign'+sign+'_t*.csv') if float(x.stem.split('_e')[-1].split('_sign')[0])==amp and float(x.stem.split('_t')[-1])==t);base=next(x for x in p.glob('base_limited'+limited+'_t*.csv') if float(x.stem.split('_t')[-1])==t);a=np.genfromtxt(base,delimiter=',',names=True);b=np.genfromtxt(file,delimiter=',',names=True);assert len(a)==len(b)==64 and np.array_equal(a['id'],b['id']) and np.array_equal(a['volume'],b['volume']);assert np.all(a['time']==t) and np.all(b['time']==t);assert all(np.all(np.isfinite(b[k])) for k in b.dtype.names);V=a['volume'];dv=sum((b[k]-a[k])**2 for k in ['vx','vy','vz']);db=sum((b[k]-a[k])**2 for k in ['bx','by','bz']);dA=sum((b[k]-a[k])**2 for k in ['ax','ay','az']);dphi=(b['phi']-a['phi'])**2;de=(b['energy']-a['energy'])**2
 values=[np.sqrt(np.sum(V*x)) for x in [a['recovered_rho']*dv+db,db,dv,dA,dphi,de]];key=(row['direction'],limited,amp,sign)
 if t==0:initial[key]=values
 predicted=values+[v/v0 if v0>1e-25 else 0. for v,v0 in zip(values,initial[key])]
 for k,v in zip(normnames+gains,predicted):
  err=abs(float(row[k])-v)/max(abs(v),abs(float(row[k])),1e-25);maxdiff=max(maxdiff,float(err));assert err<1e-8,(file,k,err);checks+=1
 assert int(row['rejected_cfl'])==int(row['rejected_state'])==int(row['rejected_geometry'])==0;assert float(row['rho_min'])>0 and float(row['p_min'])>0
 records.append(dict(row,snapshot_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),base_snapshot_sha256=hashlib.sha256(base.read_bytes()).hexdigest()))
final=[x for x in records if float(x['time'])==1];summary={}
for limited in ['true']:
 for name in sorted(set(x['direction'] for x in final)):
  rr=[x for x in final if x['limited']==limited and x['direction']==name];summary[name+'_limited'+limited]=dict(final_physical_gain_min=min(float(x['physical_gain']) for x in rr),final_physical_gain_max=max(float(x['physical_gain']) for x in rr),final_A_gain_min=min(float(x['A_gain']) for x in rr),final_A_gain_max=max(float(x['A_gain']) for x in rr),final_phi_gain_min=min(float(x['phi_gain']) for x in rr),final_phi_gain_max=max(float(x['phi_gain']) for x in rr))
out=dict(scope='Actual N8 perturbation trajectories; finite-time amplification, not a stationary-Jacobian or continuum-stability assertion',trajectories=8,snapshots=64,independent_norm_checks=checks,maximum_relative_norm_difference=maxdiff,steps_at_final=sorted(set(int(x['steps']) for x in final)),max_absolute_conservation_drift=max(float(x['budget_absolute_max']) for x in rows),summary=summary,records=records);(p/'evolution_analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
