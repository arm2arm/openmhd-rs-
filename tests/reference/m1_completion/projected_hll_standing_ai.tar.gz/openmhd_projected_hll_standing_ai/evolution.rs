mod gauge {
// Isolated pointwise source and staged cleaning kernels for the M0 audit.
// The general module reuses the immutable cleaning stages; its face stencils
// implement the coupled update separately from these pointwise audit kernels.
// Source: arXiv:2609.35989v1 (38), (41)-(42), (49)-(50), (76), (81), (88), (90), (92).

pub type Vec3 = [f64; 3];
/// `[component][coordinate]`, e.g. gradient_a[a][b] = partial_b A_a.
pub type Jacobian = [[f64; 3]; 3];

#[derive(Clone, Copy, Debug)]
/// Local point data: A is the periodic potential, magnetic is the total B and
/// mean_magnetic is the separately stored background. Velocities are laboratory
/// values; centroid_velocity is not a mesh-generator or face velocity.
pub struct PointSources {
    pub potential: Vec3,
    pub fluid_velocity: Vec3,
    pub auxiliary_velocity: Vec3,
    pub centroid_velocity: Vec3,
    pub magnetic: Vec3,
    pub mean_magnetic: Vec3,
    pub gradient_a: Jacobian,
    pub gradient_auxiliary: Jacobian,
    pub gradient_phi: Vec3,
    pub current: Vec3,
    pub resistivity: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct PotentialRate {
    pub induction: Vec3,
    pub distortion: Vec3,
    pub advection: Vec3,
    pub resistive: Vec3,
    pub cleaning: Vec3,
    pub mean_field: Vec3,
}

fn cross(a: Vec3, b: Vec3) -> Vec3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn finite_vec(v: Vec3) -> bool {
    v.iter().all(|x| x.is_finite())
}
fn finite(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() {
        Ok(value)
    } else {
        Err(format!("nonfinite {context}"))
    }
}
fn positive(value: f64, context: &str) -> Result<f64, String> {
    if value.is_finite() && value > 0.0 {
        Ok(value)
    } else {
        Err(format!("{context} must be finite and positive"))
    }
}
fn interval(dt: f64) -> Result<(), String> {
    if dt.is_finite() && dt >= 0.0 {
        Ok(())
    } else {
        Err("time interval must be finite and nonnegative".into())
    }
}

impl PotentialRate {
    pub fn total(self) -> Vec3 {
        std::array::from_fn(|k| {
            self.induction[k]
                + self.distortion[k]
                + self.advection[k]
                + self.resistive[k]
                + self.cleaning[k]
                + self.mean_field[k]
        })
    }
}

impl PointSources {
    pub fn rate(self) -> Result<PotentialRate, String> {
        if ![
            self.potential,
            self.fluid_velocity,
            self.auxiliary_velocity,
            self.centroid_velocity,
            self.magnetic,
            self.mean_magnetic,
            self.gradient_phi,
            self.current,
        ]
        .into_iter()
        .all(finite_vec)
            || !self
                .gradient_a
                .into_iter()
                .chain(self.gradient_auxiliary)
                .all(finite_vec)
            || !self.resistivity.is_finite()
            || self.resistivity < 0.0
        {
            return Err(
                "point source requires finite vectors/Jacobians and nonnegative resistivity".into(),
            );
        }
        let relative_fluid =
            std::array::from_fn(|k| self.fluid_velocity[k] - self.auxiliary_velocity[k]);
        let relative_mesh: Vec3 =
            std::array::from_fn(|k| self.centroid_velocity[k] - self.auxiliary_velocity[k]);
        let result = PotentialRate {
            induction: cross(relative_fluid, self.magnetic),
            distortion: std::array::from_fn(|b| {
                -(0..3)
                    .map(|a| self.gradient_auxiliary[a][b] * self.potential[a])
                    .sum::<f64>()
            }),
            advection: std::array::from_fn(|a| {
                (0..3)
                    .map(|b| self.gradient_a[a][b] * relative_mesh[b])
                    .sum()
            }),
            resistive: self.current.map(|j| -self.resistivity * j),
            cleaning: self.gradient_phi,
            mean_field: cross(self.auxiliary_velocity, self.mean_magnetic),
        };
        if ![
            result.induction,
            result.distortion,
            result.advection,
            result.resistive,
            result.cleaning,
            result.mean_field,
            result.total(),
        ]
        .into_iter()
        .all(finite_vec)
        {
            return Err("point source overflow".into());
        }
        Ok(result)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Cleaning {
    alpha: f64,
    beta: f64,
}

impl Default for Cleaning {
    fn default() -> Self {
        Self {
            alpha: 1.0,
            beta: 0.15,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct CleaningBounds {
    /// Printed equation (49), r/(alpha cs).
    pub hyperbolic: f64,
    /// Printed equation (50), r^2/D, D=alpha cs r/beta.
    pub diffusive: f64,
}

/// Immutable initial source data enforce equation (90)'s frozen div(A) and cs.
#[derive(Clone, Copy, Debug)]
pub struct CleaningStage {
    parameters: Cleaning,
    phi_initial: f64,
    divergence_initial: f64,
    sound_speed_initial: f64,
    rate_initial: f64,
}

impl Cleaning {
    /// This active-cleaning kernel requires positive alpha and beta. Disabling
    /// cleaning is an explicit caller decision, not represented by invalid bounds.
    pub fn new(alpha: f64, beta: f64) -> Result<Self, String> {
        positive(alpha, "alpha")?;
        positive(beta, "beta")?;
        Ok(Self { alpha, beta })
    }
    pub fn alpha(self) -> f64 {
        self.alpha
    }
    pub fn beta(self) -> f64 {
        self.beta
    }

    pub fn rate(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<f64, String> {
        finite(phi, "cleaning scalar")?;
        finite(divergence_a, "potential divergence")?;
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        finite(
            self.alpha * sound_speed.powi(2) * divergence_a
                - self.beta * sound_speed * phi / radius,
            "cleaning rate",
        )
    }

    pub fn bounds(self, sound_speed: f64, radius: f64) -> Result<CleaningBounds, String> {
        positive(sound_speed, "sound speed")?;
        positive(radius, "cell radius")?;
        let hyperbolic = positive(radius / (self.alpha * sound_speed), "hyperbolic bound")?;
        let diffusive = positive(self.beta * hyperbolic, "diffusive bound")?;
        Ok(CleaningBounds {
            hyperbolic,
            diffusive,
        })
    }

    pub fn begin(
        self,
        phi: f64,
        divergence_a: f64,
        sound_speed: f64,
        radius: f64,
    ) -> Result<CleaningStage, String> {
        let rate_initial = self.rate(phi, divergence_a, sound_speed, radius)?;
        Ok(CleaningStage {
            parameters: self,
            phi_initial: phi,
            divergence_initial: divergence_a,
            sound_speed_initial: sound_speed,
            rate_initial,
        })
    }
}

impl CleaningStage {
    pub fn initial_rate(self) -> f64 {
        self.rate_initial
    }

    pub fn predicted_phi(self, dt: f64) -> Result<f64, String> {
        interval(dt)?;
        finite(
            self.phi_initial + dt * self.rate_initial,
            "predicted cleaning scalar",
        )
    }

    pub fn endpoint_rate(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        self.parameters.rate(
            self.predicted_phi(dt)?,
            self.divergence_initial,
            self.sound_speed_initial,
            endpoint_radius,
        )
    }

    pub fn finish_phi(self, dt: f64, endpoint_radius: f64) -> Result<f64, String> {
        interval(dt)?;
        let rate_end = self.endpoint_rate(dt, endpoint_radius)?;
        finite(
            self.phi_initial + 0.5 * dt * (self.rate_initial + rate_end),
            "updated cleaning scalar",
        )
    }
}

}
mod auxiliary {
// Periodic bicubic reduction of paper Eq. (68), with the explicit v2 origin rule.
use crate::gauge::{Jacobian, Vec3};
use moving_mesh::Vec2;

#[derive(Clone, Copy, Debug, Default)]
pub struct Jet {
    pub value: Vec3,
    pub dx: Vec3,
    pub dy: Vec3,
    pub dxy: Vec3,
}

#[derive(Clone, Copy, Debug)]
pub struct Sample {
    pub velocity: Vec3,
    pub jacobian: Jacobian,
}

/// Tensor Hermite polynomial on a single element; coordinates are in [0,1]^2.
/// Corner layout is [y][x]; derivative jets are in physical length units.
pub fn interpolate(
    corners: &[[Jet; 2]; 2],
    spacing: Vec2,
    coordinate: Vec2,
) -> Result<Sample, String> {
    if !spacing.iter().all(|h| h.is_finite() && *h > 0.0)
        || !coordinate
            .iter()
            .all(|s| s.is_finite() && (0.0..=1.0).contains(s))
        || corners.iter().flatten().any(|j| {
            [j.value, j.dx, j.dy, j.dxy]
                .iter()
                .flatten()
                .any(|v| !v.is_finite())
        })
    {
        return Err("invalid Hermite element or coordinate".into());
    }
    let basis = |s: f64| {
        [
            [
                2.0 * s * s * s - 3.0 * s * s + 1.0,
                s * s * s - 2.0 * s * s + s,
            ],
            [-2.0 * s * s * s + 3.0 * s * s, s * s * s - s * s],
        ]
    };
    let derivative = |s: f64| {
        [
            [6.0 * s * s - 6.0 * s, 3.0 * s * s - 4.0 * s + 1.0],
            [-6.0 * s * s + 6.0 * s, 3.0 * s * s - 2.0 * s],
        ]
    };
    let bx = basis(coordinate[0]);
    let by = basis(coordinate[1]);
    let dx = derivative(coordinate[0]);
    let dy = derivative(coordinate[1]);
    let mut result = Sample {
        velocity: [0.0; 3],
        jacobian: [[0.0; 3]; 3],
    };
    for (y, row) in corners.iter().enumerate() {
        for (x, jet) in row.iter().enumerate() {
            for (px, py, values) in [
                (0, 0, jet.value),
                (1, 0, jet.dx),
                (0, 1, jet.dy),
                (1, 1, jet.dxy),
            ] {
                let scale = (if px == 0 { 1.0 } else { spacing[0] })
                    * (if py == 0 { 1.0 } else { spacing[1] });
                for (k, v) in values.iter().enumerate() {
                    result.velocity[k] += v * scale * bx[x][px] * by[y][py];
                    result.jacobian[k][0] += v * scale * dx[x][px] * by[y][py] / spacing[0];
                    result.jacobian[k][1] += v * scale * bx[x][px] * dy[y][py] / spacing[1];
                }
            }
        }
    }
    if !result
        .velocity
        .iter()
        .chain(result.jacobian.iter().flatten())
        .all(|v| v.is_finite())
    {
        return Err("Hermite evaluation overflow".into());
    }
    Ok(result)
}

#[derive(Clone, Copy, Debug)]
pub struct VelocitySample {
    pub position: Vec2,
    pub volume: f64,
    pub velocity: Vec3,
}

#[derive(Clone, Debug)]
pub struct SmoothVelocity {
    lengths: Vec2,
    origin: Vec2,
    corners: Vec<Jet>,
    intervals: usize,
    pub counts: Vec<usize>,
    pub max_cell_volumes: Vec<f64>,
    pub coarsenings: usize,
    pub mean_velocity: Vec3,
}

fn bin(position: f64, origin: f64, length: f64, intervals: usize) -> usize {
    let mut q = (position - origin).rem_euclid(length) / length * intervals as f64 + 0.5;
    let nearest = q.round();
    if (q - nearest).abs() <= 32.0 * f64::EPSILON * (1.0 + q.abs()) {
        q = nearest;
    }
    (q.floor() as usize) % intervals
}

fn jets(values: &[Vec3], n: usize, spacing: Vec2) -> Vec<Jet> {
    let index = |x: usize, y: usize| (x % n) + n * (y % n);
    let dx: Vec<Vec3> = (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            std::array::from_fn(|k| {
                (values[index(x + 1, y)][k] - values[index(x + n - 1, y)][k]) / (2.0 * spacing[0])
            })
        })
        .collect();
    (0..n * n)
        .map(|i| {
            let x = i % n;
            let y = i / n;
            Jet {
                value: values[i],
                dx: dx[i],
                dy: std::array::from_fn(|k| {
                    (values[index(x, y + 1)][k] - values[index(x, y + n - 1)][k])
                        / (2.0 * spacing[1])
                }),
                dxy: std::array::from_fn(|k| {
                    (dx[index(x, y + 1)][k] - dx[index(x, y + n - 1)][k]) / (2.0 * spacing[1])
                }),
            }
        })
        .collect()
}

impl SmoothVelocity {
    pub fn build(lengths: Vec2, samples: &[VelocitySample], origin: Vec2) -> Result<Self, String> {
        if samples.is_empty()
            || !lengths.iter().all(|v| v.is_finite() && *v > 0.0)
            || !origin.iter().all(|v| v.is_finite())
            || samples.iter().any(|s| {
                !s.volume.is_finite()
                    || s.volume <= 0.0
                    || !s.position.iter().chain(&s.velocity).all(|v| v.is_finite())
                    || (0..2).any(|k| !(s.position[k] - origin[k]).is_finite())
            })
        {
            return Err("invalid auxiliary velocity samples/domain/origin".into());
        }
        let total: f64 = samples.iter().map(|s| s.volume).sum();
        if !total.is_finite() || total <= 0.0 {
            return Err("auxiliary volume overflow".into());
        }
        let mean_velocity: Vec3 = std::array::from_fn(|k| {
            samples
                .iter()
                .map(|s| s.volume / total * s.velocity[k])
                .sum()
        });
        for (coarsenings, n) in [4, 2, 1].into_iter().enumerate() {
            let mut weights = vec![0.0; n * n];
            let mut values = vec![[0.0; 3]; n * n];
            let mut counts = vec![0; n * n];
            let mut max_cell_volumes = vec![0.0_f64; n * n];
            for s in samples {
                let i = bin(s.position[0], origin[0], lengths[0], n)
                    + n * bin(s.position[1], origin[1], lengths[1], n);
                let w = s.volume / total;
                weights[i] += w;
                counts[i] += 1;
                max_cell_volumes[i] = max_cell_volumes[i].max(s.volume);
                for (k, v) in s.velocity.iter().enumerate() {
                    values[i][k] += w * v;
                }
            }
            if counts.contains(&0) {
                continue;
            }
            for (v, w) in values.iter_mut().zip(weights) {
                for component in v {
                    *component /= w;
                }
            }
            let corners = jets(&values, n, lengths.map(|l| l / n as f64));
            if !mean_velocity
                .into_iter()
                .chain(
                    corners
                        .iter()
                        .flat_map(|j| [j.value, j.dx, j.dy, j.dxy])
                        .flatten(),
                )
                .all(|v| v.is_finite())
            {
                return Err("auxiliary averages/jets overflow".into());
            }
            return Ok(Self {
                lengths,
                origin,
                corners,
                intervals: n,
                counts,
                max_cell_volumes,
                coarsenings,
                mean_velocity,
            });
        }
        Err("auxiliary root remained empty".into())
    }

    pub fn intervals(&self) -> usize {
        self.intervals
    }
    pub fn origin(&self) -> Vec2 {
        self.origin
    }

    pub fn sample(&self, position: Vec2, stage_time: f64) -> Result<Sample, String> {
        if !stage_time.is_finite() || stage_time < 0.0 {
            return Err("invalid auxiliary stage time".into());
        }
        let coordinate: Vec2 = std::array::from_fn(|k| {
            position[k] - self.origin[k] - stage_time * self.mean_velocity[k]
        });
        if !coordinate.iter().all(|v| v.is_finite()) {
            return Err("auxiliary coordinate overflow".into());
        }
        let n = self.intervals;
        let spacing = self.lengths.map(|l| l / n as f64);
        let q: Vec2 =
            std::array::from_fn(|k| coordinate[k].rem_euclid(self.lengths[k]) / spacing[k]);
        let cell = q.map(|v| v.floor() as usize);
        let local = std::array::from_fn(|k| (q[k] - cell[k] as f64).clamp(0.0, 1.0));
        let corners = std::array::from_fn(|y| {
            std::array::from_fn(|x| self.corners[(cell[0] + x) % n + n * ((cell[1] + y) % n)])
        });
        interpolate(&corners, spacing, local)
    }

    pub fn advanced_origin(&self, dt: f64) -> Result<Vec2, String> {
        if !dt.is_finite() || dt < 0.0 {
            return Err("invalid origin advance interval".into());
        }
        let origin: Vec2 = std::array::from_fn(|k| self.origin[k] + dt * self.mean_velocity[k]);
        if !origin.iter().all(|v| v.is_finite()) {
            return Err("auxiliary origin overflow".into());
        }
        Ok(std::array::from_fn(|k| {
            origin[k].rem_euclid(self.lengths[k])
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::TAU;

    #[test]
    fn centred_jets_converge_for_periodic_smooth_data() {
        let mut errors = Vec::new();
        for n in [8, 16, 32] {
            let h = 1.0 / n as f64;
            let values: Vec<_> = (0..n * n)
                .map(|i| [(TAU * (i % n) as f64 * h).sin() * (TAU * (i / n) as f64 * h).cos(); 3])
                .collect();
            let field = SmoothVelocity {
                lengths: [1.0; 2],
                origin: [0.0; 2],
                corners: jets(&values, n, [h; 2]),
                intervals: n,
                counts: vec![1; n * n],
                max_cell_volumes: vec![h * h; n * n],
                coarsenings: 0,
                mean_velocity: [0.0; 3],
            };
            let error: f64 = (0..n * n)
                .map(|i| {
                    let p = [((i % n) as f64 + 0.37) * h, ((i / n) as f64 + 0.63) * h];
                    let g = field.sample(p, 0.0).unwrap().jacobian[0];
                    (g[0] - TAU * (TAU * p[0]).cos() * (TAU * p[1]).cos())
                        .hypot(g[1] + TAU * (TAU * p[0]).sin() * (TAU * p[1]).sin())
                })
                .sum::<f64>()
                / (n * n) as f64;
            errors.push(error);
        }
        for pair in errors.windows(2) {
            // Finite-difference jets plus interpolation: record convergence,
            // rather than assume an asymptotic order on the coarsest grid.
            assert!(pair[1] < pair[0], "{errors:?}");
        }
    }
}

}
mod operators {
// 2.5D operators for the reviewed paper-global-v2 endpoint scheme.
// Derivatives are [component][x/y]; physical vectors retain all three components.
use crate::auxiliary::SmoothVelocity;
use mhd_core::{FaceFlux, IdealGas, Primitive, Vec3, cross};
use moving_mesh::{
    Derivatives, Face, Mesh, Vec2, dot,
    quadratic::{Compact, Quadratic},
};

pub type PrimitiveGradient = [Vec2; 8];

pub(crate) fn components(q: Primitive) -> [f64; 8] {
    [
        q.density,
        q.velocity[0],
        q.velocity[1],
        q.velocity[2],
        q.pressure,
        q.magnetic[0],
        q.magnetic[1],
        q.magnetic[2],
    ]
}
pub(crate) fn primitive(q: [f64; 8]) -> Result<Primitive, String> {
    let p = Primitive {
        density: q[0],
        velocity: [q[1], q[2], q[3]],
        pressure: q[4],
        magnetic: [q[5], q[6], q[7]],
    };
    p.validate()?;
    Ok(p)
}
pub(crate) fn gradients<const N: usize>(
    mesh: &Mesh,
    stencil: &Derivatives,
    values: &[[f64; N]],
    limited: bool,
) -> Result<Vec<[Vec2; N]>, String> {
    let mut result = vec![[[0.; 2]; N]; mesh.cells.len()];
    let reconstruction = if limited {
        Some(mesh.reconstruction()?)
    } else {
        None
    };
    for k in 0..N {
        let scalar: Vec<_> = values.iter().map(|v| v[k]).collect();
        let mut grad = stencil.gradient(&scalar)?;
        if let Some(reconstruction) = &reconstruction {
            grad = reconstruction.limit_gradients(&scalar, &grad)?;
        }
        for (out, g) in result.iter_mut().zip(grad) {
            out[k] = g;
        }
    }
    Ok(result)
}

#[derive(Clone, Debug)]
pub struct MagneticFit {
    pub raw: Vec<[Vec2; 3]>,
    pub limited: Vec<[Vec2; 3]>,
    pub magnetic: Vec<Vec3>,
    pub divergence_a: Vec<f64>,
    pub gradient_phi: Vec<Vec2>,
    /// Limited Hessians [component][xx,yy,xy], only for the consistent profile.
    pub curvature: Option<Vec<[[f64; 3]; 3]>>,
}
impl MagneticFit {
    pub fn build(
        mesh: &Mesh,
        potential: &[Vec3],
        phi: &[f64],
        mean: Vec3,
        limited: bool,
    ) -> Result<Self, String> {
        let stencil = Derivatives::build(mesh, false)?;
        Self::with_stencil(
            mesh,
            (&stencil, None, None, false, false),
            potential,
            phi,
            mean,
            limited,
        )
    }
    pub(crate) fn with_stencil(
        mesh: &Mesh,
        stencils: (
            &Derivatives,
            Option<&Quadratic>,
            Option<&Compact>,
            bool,
            bool,
        ),
        potential: &[Vec3],
        phi: &[f64],
        mean: Vec3,
        limited: bool,
    ) -> Result<Self, String> {
        Self::with_projection(mesh, stencils, potential, phi, mean, limited, false)
    }
    pub(crate) fn with_projection(
        mesh: &Mesh,
        stencils: (
            &Derivatives,
            Option<&Quadratic>,
            Option<&Compact>,
            bool,
            bool,
        ),
        potential: &[Vec3],
        phi: &[f64],
        mean: Vec3,
        limited: bool,
        projected: bool,
    ) -> Result<Self, String> {
        if !mean.iter().all(|x| x.is_finite()) {
            return Err("nonfinite mean field".into());
        }
        let (stencil, quadratic, compact, consistent, matched) = stencils;
        if ((consistent || matched || compact.is_some()) && quadratic.is_none())
            || (projected && !consistent)
        {
            return Err("consistent fit requires quadratic reconstruction".into());
        }
        let mut curvature = if consistent {
            Some(vec![[[0.; 3]; 3]; mesh.cells.len()])
        } else {
            None
        };
        let raw = if let Some(quadratic) = quadratic {
            let mut raw = vec![[[0.; 2]; 3]; mesh.cells.len()];
            for k in 0..3 {
                let values: Vec<_> = potential.iter().map(|a| a[k]).collect();
                for (i, (g, jet)) in raw
                    .iter_mut()
                    .zip(if let Some(c) = compact {
                        c.jets(stencil, quadratic, &values)?
                    } else {
                        quadratic.jets(&values)?
                    })
                    .enumerate()
                {
                    g[k] = jet.gradient;
                    if let Some(h) = &mut curvature {
                        h[i][k] = jet.hessian;
                    }
                }
            }
            raw
        } else {
            gradients(mesh, stencil, potential, false)?
        };
        let extrapolation = if limited && quadratic.is_some() {
            let guard = mesh.reconstruction()?;
            let mut extrapolation = raw.clone();
            for k in 0..3 {
                let values: Vec<_> = potential.iter().map(|a| a[k]).collect();
                let gradient: Vec<_> = raw.iter().map(|g| g[k]).collect();
                if let Some(h) = &mut curvature {
                    let hessian: Vec<_> = h.iter().map(|h| h[k]).collect();
                    if projected {
                        let jets = guard.project_quadratic(&values, &gradient, &hessian)?;
                        for (i, jet) in jets.into_iter().enumerate() {
                            extrapolation[i][k] = jet.gradient;
                            h[i][k] = jet.hessian;
                        }
                        continue;
                    }
                    let factors = guard.quadratic_factors(&values, &gradient, &hessian)?;
                    for (i, factor) in factors.into_iter().enumerate() {
                        extrapolation[i][k] = gradient[i].map(|v| v * factor);
                        h[i][k] = hessian[i].map(|v| v * factor);
                    }
                } else {
                    for (out, g) in extrapolation
                        .iter_mut()
                        .zip(guard.limit_gradients(&values, &gradient)?)
                    {
                        out[k] = g;
                    }
                }
            }
            extrapolation
        } else if limited {
            gradients(mesh, stencil, potential, true)?
        } else {
            raw.clone()
        };
        let magnetic: Vec<Vec3> = raw
            .iter()
            .map(|g| {
                [
                    mean[0] + g[2][1],
                    mean[1] - g[2][0],
                    mean[2] + g[1][0] - g[0][1],
                ]
            })
            .collect();
        let divergence_a: Vec<f64> = raw.iter().map(|g| g[0][0] + g[1][1]).collect();
        if !magnetic
            .iter()
            .flatten()
            .chain(&divergence_a)
            .all(|x| x.is_finite())
        {
            return Err("curl/divergence arithmetic overflow".into());
        }
        Ok(Self {
            curvature,
            raw,
            limited: extrapolation,
            magnetic,
            divergence_a,
            gradient_phi: if let Some(c) = compact {
                c.jets(
                    stencil,
                    quadratic.ok_or("compact cleaning requires quadratic fit")?,
                    phi,
                )?
                .iter()
                .map(|j| j.gradient)
                .collect()
            } else if matched {
                quadratic
                    .ok_or("matched cleaning requires quadratic reconstruction")?
                    .jets(phi)?
                    .iter()
                    .map(|j| j.gradient)
                    .collect()
            } else {
                stencil.gradient(phi)?
            },
        })
    }
}

/// Solenoidal material predictor (U1): deliberately omits v * estimated div(B).
/// This local algebra assumes validated q/gradients; predictor outputs are checked.
pub fn material_derivative(eos: IdealGas, q: Primitive, g: PrimitiveGradient) -> [f64; 8] {
    let theta = g[1][0] + g[2][1];
    let current = [g[7][1], -g[7][0], g[6][0] - g[5][1]];
    let force = cross(current, q.magnetic);
    let mut rate = [0.; 8];
    rate[0] = -q.density * theta;
    rate[4] = -eos.gamma() * q.pressure * theta;
    for k in 0..3 {
        rate[1 + k] = (force[k] - if k < 2 { g[4][k] } else { 0. }) / q.density;
        rate[5 + k] =
            g[1 + k][0] * q.magnetic[0] + g[1 + k][1] * q.magnetic[1] - q.magnetic[k] * theta;
    }
    rate
}

/// Offset is the *unwrapped* new evaluation point minus the old cell centroid.
pub fn predict(
    eos: IdealGas,
    q: Primitive,
    g: PrimitiveGradient,
    offset: Vec2,
    dt: f64,
) -> Result<Primitive, String> {
    if !dt.is_finite()
        || dt < 0.
        || !offset
            .iter()
            .chain(g.iter().flatten())
            .all(|x| x.is_finite())
    {
        return Err("invalid predictor data".into());
    }
    q.validate()?;
    let material = material_derivative(eos, q, g);
    let displacement = [
        offset[0] - dt * q.velocity[0],
        offset[1] - dt * q.velocity[1],
    ];
    let old = components(q);
    primitive(std::array::from_fn(|k| {
        old[k] + dot(g[k], displacement) + dt * material[k]
    }))
}

/// Differentiated Voronoi bisector speed; mesh must be validated and face incident.
pub fn face_velocity(
    mesh: &Mesh,
    face: &Face,
    generators_velocity: &[Vec2],
) -> Result<Vec3, String> {
    if generators_velocity.len() != mesh.cells.len() {
        return Err("generator velocity length".into());
    }
    let ri = mesh.generators[face.left];
    let rj: Vec2 = std::array::from_fn(|k| {
        mesh.generators[face.right][k] + f64::from(face.image[k]) * mesh.lengths[k]
    });
    let d: Vec2 = std::array::from_fn(|k| rj[k] - ri[k]);
    let f: Vec2 = std::array::from_fn(|k| face.centroid[k] - 0.5 * (ri[k] + rj[k]));
    let wi = generators_velocity[face.left];
    let wj = generators_velocity[face.right];
    let correction = dot([wi[0] - wj[0], wi[1] - wj[1]], f) / dot(d, d);
    let result = [
        0.5 * (wi[0] + wj[0]) + d[0] * correction,
        0.5 * (wi[1] + wj[1]) + d[1] * correction,
        0.,
    ];
    if !result.iter().all(|x| x.is_finite()) {
        return Err("invalid moving bisector velocity".into());
    }
    Ok(result)
}

pub(crate) struct PotentialStage<'a> {
    pub mesh: &'a Mesh,
    pub face_stencil: &'a Derivatives,
    pub potential: &'a [Vec3],
    pub fit: &'a MagneticFit,
    pub faces: &'a [FaceFlux],
    pub auxiliary: &'a SmoothVelocity,
    pub advection_velocity: &'a [Vec2],
    pub mean: Vec3,
    pub reference_velocity: Vec3,
    pub tau: f64,
    pub centered: bool,
}
impl PotentialStage<'_> {
    /// Paper (69)-(72),(76); numerical EMF must not be replaced by a state product.
    pub fn rate(&self) -> Result<Vec<Vec3>, String> {
        self.mesh
            .cells
            .iter()
            .enumerate()
            .map(|(i, cell)| {
                let aux = self.auxiliary.sample(cell.centroid, self.tau)?;
                let b = [
                    self.advection_velocity[i][0] - aux.velocity[0],
                    self.advection_velocity[i][1] - aux.velocity[1],
                ];
                let perimeter: f64 = cell
                    .faces
                    .iter()
                    .map(|(f, _)| self.mesh.faces[*f].area)
                    .sum();
                // BulkFrameV1 changes the gauge, not the lab-frame fluid fluxes.
                // Substituting A=a+C into the original gauge alone would leave
                // -H^T C; its deliberate omission is documented in the profile.
                let mean_source = cross(
                    std::array::from_fn(|k| aux.velocity[k] - self.reference_velocity[k]),
                    self.mean,
                );
                let mut result: Vec3 = std::array::from_fn(|k| {
                    mean_source[k]
                        - (0..3)
                            .map(|a| aux.jacobian[a][k] * self.potential[i][a])
                            .sum::<f64>()
                        + if k < 2 {
                            self.fit.gradient_phi[i][k]
                        } else {
                            0.
                        }
                });
                for &(f, sign) in &cell.faces {
                    let face = &self.faces[f];
                    let geometry = &self.mesh.faces[f];
                    let weight = if self.centered {
                        geometry.area
                            * sign
                            * dot(geometry.normal, self.mesh.displacement(geometry, i))
                            / (2. * cell.volume)
                    } else {
                        geometry.area / perimeter
                    };
                    let ux_b = cross(aux.velocity, face.magnetic);
                    for k in 0..3 {
                        result[k] += weight * (face.electromotive[k] - ux_b[k]);
                    }
                }
                for sample in &self.face_stencil.samples[i] {
                    let face = &self.mesh.faces[sample.index];
                    let displacement = self.mesh.displacement(face, i);
                    let donor = if dot(b, displacement) < 0. {
                        i
                    } else {
                        self.mesh.neighbour(face, i).0
                    };
                    let donor_offset = self.mesh.displacement(face, donor);
                    for (k, r) in result.iter_mut().enumerate() {
                        let up = self.potential[donor][k]
                            + dot(self.fit.limited[donor][k], donor_offset);
                        let correction = if let Some(h) = &self.fit.curvature {
                            moving_mesh::quadratic::term(h[donor][k], donor_offset)
                                - moving_mesh::quadratic::term(h[i][k], displacement)
                        } else {
                            0.
                        };
                        *r += dot(b, sample.weight)
                            * if self.fit.curvature.is_some() {
                                up - self.potential[i][k] + correction
                            } else {
                                up - self.potential[i][k]
                            };
                    }
                }
                if !result.iter().all(|x| x.is_finite()) {
                    return Err("nonfinite potential rate".into());
                }
                Ok(result)
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::auxiliary::VelocitySample;
    use mhd_core::FluxMethod;
    #[test]
    fn compact_limiter_bounds_complete_face_polynomials_and_phi_is_unlimited() {
        let mesh = Mesh::lattice(12, 9, [1.; 2], 0.15).unwrap();
        let linear = Derivatives::build(&mesh, false).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let compact = Compact::build(&mesh, &linear).unwrap();
        let a: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| {
                [
                    (13. * c.centroid[0]).sin(),
                    if c.centroid[0] < 0.5 { 1. } else { -1. },
                    (9. * c.centroid[1]).cos(),
                ]
            })
            .collect();
        let phi: Vec<_> = a.iter().map(|a| a[1]).collect();
        let fit = MagneticFit::with_stencil(
            &mesh,
            (&linear, Some(&quadratic), Some(&compact), true, true),
            &a,
            &phi,
            [0.; 3],
            true,
        )
        .unwrap();
        let exact = compact.jets(&linear, &quadratic, &phi).unwrap();
        for (i, c) in mesh.cells.iter().enumerate() {
            assert_eq!(fit.gradient_phi[i], exact[i].gradient);
            for k in 0..3 {
                let mut lo = a[i][k];
                let mut hi = lo;
                for &(f, _) in &c.faces {
                    let j = mesh.neighbour(&mesh.faces[f], i).0;
                    lo = lo.min(a[j][k]);
                    hi = hi.max(a[j][k]);
                }
                for &(f, _) in &c.faces {
                    let d = mesh.displacement(&mesh.faces[f], i);
                    let value = a[i][k]
                        + dot(fit.limited[i][k], d)
                        + moving_mesh::quadratic::term(fit.curvature.as_ref().unwrap()[i][k], d);
                    assert!(
                        value >= lo - 1e-12 && value <= hi + 1e-12,
                        "{value} [{lo},{hi}]"
                    );
                }
            }
        }
    }
    #[test]
    fn matched_cleaning_removes_the_mixed_derivative_growing_fourier_mode() {
        let mesh = Mesh::lattice(16, 16, [1.; 2], 0.).unwrap();
        let linear = Derivatives::build(&mesh, false).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let phi: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| (std::f64::consts::TAU * (6. * c.centroid[0] + 5. * c.centroid[1])).sin())
            .collect();
        let a = vec![[0.; 3]; phi.len()];
        let mut coefficients = Vec::new();
        for matched in [false, true] {
            let fit = MagneticFit::with_stencil(
                &mesh,
                (&linear, Some(&quadratic), None, true, matched),
                &a,
                &phi,
                [0.; 3],
                false,
            )
            .unwrap();
            let gx: Vec<_> = fit.gradient_phi.iter().map(|g| g[0]).collect();
            let gy: Vec<_> = fit.gradient_phi.iter().map(|g| g[1]).collect();
            let dx = quadratic.jets(&gx).unwrap();
            let dy = quadratic.jets(&gy).unwrap();
            let lap: Vec<_> = dx
                .iter()
                .zip(&dy)
                .map(|(x, y)| x.gradient[0] + y.gradient[1])
                .collect();
            let curl: Vec<_> = dx
                .iter()
                .zip(&dy)
                .map(|(x, y)| y.gradient[0] - x.gradient[1])
                .collect();
            let norm: f64 = phi.iter().map(|p| p * p).sum();
            let coefficient =
                |v: &[f64]| v.iter().zip(&phi).map(|(v, p)| v * p).sum::<f64>() / norm;
            let lambda = coefficient(&lap);
            let curl_lambda = coefficient(&curl);
            assert!(
                lap.iter()
                    .zip(&phi)
                    .all(|(v, p)| (v - lambda * p).abs() < 1e-9)
            );
            assert!(
                curl.iter()
                    .zip(&phi)
                    .all(|(v, p)| (v - curl_lambda * p).abs() < 1e-9)
            );
            coefficients.push((lambda, curl_lambda));
        }
        // This fixture exposes the semidiscrete defect, independently of timestep size.
        assert!(
            coefficients[0].0 > 60. && coefficients[0].1.abs() > 7.,
            "{coefficients:?}"
        );
        assert!(
            coefficients[1].0 < -10. && coefficients[1].1.abs() < 1e-10,
            "{coefficients:?}"
        );
    }
    #[test]
    fn upwind_donors_and_numerical_emf_use_all_components() {
        let mesh = Mesh::lattice(6, 6, [1.; 2], 0.).unwrap();
        let i = 14; // interior (x index 2, y index 2)
        let mut potential = vec![[0.; 3]; 36];
        for (index, value) in [(i, 0.2), (i - 1, -0.1), (i + 1, 0.9)] {
            potential[index] = [value, 2. * value, -3. * value];
        }
        let mut fit = MagneticFit::build(&mesh, &potential, &vec![0.; 36], [0.; 3], false).unwrap();
        fit.limited.fill([[0.; 2]; 3]); // controlled donor fixture, discontinuous data
        fit.gradient_phi.fill([0.13, -0.12]);
        let u = [0.4, -0.2, 0.3];
        let bfield = [0.2, 0.3, 0.4];
        let mean = [0.3, -0.2, 0.1];
        let emf = [0.03, 0.07, 0.09]; // deliberately different from the face state product
        let flux = FaceFlux {
            fluid: [0.; 5],
            induction: [0.; 3],
            electromotive: emf,
            velocity: [0.; 3],
            magnetic: bfield,
            max_speed: 1.,
            method: FluxMethod::HllFallback,
        };
        let fluxes = vec![flux; mesh.faces.len()];
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| VelocitySample {
                position: c.centroid,
                volume: c.volume,
                velocity: u,
            })
            .collect();
        let aux = SmoothVelocity::build([1.; 2], &samples, [0.; 2]).unwrap();
        let faces = Derivatives::build(&mesh, true).unwrap();
        for (speed, delta) in [(0.7, 0.9 - 0.2), (-0.6, 0.2 - (-0.1))] {
            let w = vec![[u[0] + speed, u[1]]; 36];
            let result = PotentialStage {
                mesh: &mesh,
                face_stencil: &faces,
                potential: &potential,
                fit: &fit,
                faces: &fluxes,
                auxiliary: &aux,
                advection_velocity: &w,
                mean,
                reference_velocity: [0.; 3],
                tau: 0.,
                centered: false,
            }
            .rate()
            .unwrap();
            let ux_b = cross(u, bfield);
            let ux_mean = cross(u, mean);
            for (k, multiplier) in [1., 2., -3.].iter().enumerate() {
                let exact = emf[k] - ux_b[k]
                    + ux_mean[k]
                    + if k < 2 { fit.gradient_phi[i][k] } else { 0. }
                    + speed * 6. * delta * multiplier;
                assert!(
                    (result[i][k] - exact).abs() < 1e-11,
                    "{} != {exact}",
                    result[i][k]
                );
            }
        }
    }
    #[test]
    fn complete_consistent_rate_reproduces_quadratic_a_with_affine_face_source() {
        let mesh = Mesh::lattice(12, 12, [1.; 2], 0.15).unwrap();
        let a = |p: Vec2| {
            let [x, y] = p;
            [
                0.2 + 0.3 * x - 0.2 * y + 0.05 * x * x + 0.07 * x * y - 0.04 * y * y,
                -0.1 + 0.2 * x + 0.4 * y - 0.03 * x * x + 0.02 * x * y + 0.06 * y * y,
                0.4 - 0.25 * x + 0.15 * y + 0.08 * x * x - 0.05 * x * y + 0.09 * y * y,
            ]
        };
        let gradient = |p: Vec2| {
            let [x, y] = p;
            [
                [0.3 + 0.1 * x + 0.07 * y, -0.2 + 0.07 * x - 0.08 * y],
                [0.2 - 0.06 * x + 0.02 * y, 0.4 + 0.02 * x + 0.12 * y],
                [-0.25 + 0.16 * x - 0.05 * y, 0.15 - 0.05 * x + 0.18 * y],
            ]
        };
        let bfield = |p: Vec2| {
            let g = gradient(p);
            [g[2][1], -g[2][0], g[1][0] - g[0][1]]
        };
        let v = [0.7, -0.3, 0.2];
        let u = [0.2, 0.1, -0.1];
        let w = [-0.1, 0.4];
        let adv = [w[0] - u[0], w[1] - u[1]];
        let potential: Vec<_> = mesh.cells.iter().map(|c| a(c.centroid)).collect();
        let phi = vec![0.; potential.len()];
        let neighbours = Derivatives::build(&mesh, false).unwrap();
        let faces = Derivatives::build(&mesh, true).unwrap();
        let quadratic = Quadratic::build(&mesh).unwrap();
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| VelocitySample {
                position: c.centroid,
                volume: c.volume,
                velocity: u,
            })
            .collect();
        let auxiliary = SmoothVelocity::build(mesh.lengths, &samples, [0.; 2]).unwrap();
        let fluxes: Vec<_> = mesh
            .faces
            .iter()
            .map(|f| {
                let b = bfield(f.centroid);
                FaceFlux {
                    fluid: [0.; 5],
                    induction: [0.; 3],
                    electromotive: cross(v, b),
                    velocity: v,
                    magnetic: b,
                    max_speed: 1.,
                    method: FluxMethod::HllFallback,
                }
            })
            .collect();
        let motion = vec![w; potential.len()];
        let mut errors = Vec::new();
        let compact = Compact::build(&mesh, &neighbours).unwrap();
        for (consistent, correction) in [(false, None), (true, None), (true, Some(&compact))] {
            let fit = MagneticFit::with_stencil(
                &mesh,
                (&neighbours, Some(&quadratic), correction, consistent, false),
                &potential,
                &phi,
                [0.; 3],
                false,
            )
            .unwrap();
            let rate = PotentialStage {
                mesh: &mesh,
                face_stencil: &faces,
                potential: &potential,
                fit: &fit,
                faces: &fluxes,
                auxiliary: &auxiliary,
                advection_velocity: &motion,
                mean: [0.; 3],
                reference_velocity: [0.; 3],
                tau: 0.,
                centered: consistent,
            }
            .rate()
            .unwrap();
            let mut worst: f64 = 0.;
            for (i, c) in mesh.cells.iter().enumerate() {
                if !c.centroid.iter().all(|x| (0.3..0.7).contains(x)) {
                    continue;
                }
                let source = cross(std::array::from_fn(|k| v[k] - u[k]), bfield(c.centroid));
                let g = gradient(c.centroid);
                for k in 0..3 {
                    worst = worst.max((rate[i][k] - source[k] - dot(adv, g[k])).abs());
                }
            }
            errors.push(worst);
        }
        assert!(
            errors[0] > 1e-6,
            "uncorrected control unexpectedly exact: {errors:?}"
        );
        assert!(errors[1..].iter().all(|e| *e < 1e-10), "{errors:?}");
    }
    #[test]
    fn live_distortion_transposes_the_full_auxiliary_jacobian() {
        let mesh = Mesh::lattice(8, 8, [1.; 2], 0.15).unwrap();
        let a = [0.2, -0.4, 0.7];
        let potential = vec![a; mesh.cells.len()];
        let fit = MagneticFit::build(&mesh, &potential, &vec![0.; potential.len()], [0.; 3], true)
            .unwrap();
        let samples: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| {
                let x = std::f64::consts::TAU * c.centroid[0];
                let y = std::f64::consts::TAU * c.centroid[1];
                VelocitySample {
                    position: c.centroid,
                    volume: c.volume,
                    velocity: [
                        0.1 * x.sin() + 0.02 * y.cos(),
                        0.2 * x.cos() + 0.03 * y.sin(),
                        0.07 * x.sin() - 0.04 * y.cos(),
                    ],
                }
            })
            .collect();
        let aux = SmoothVelocity::build(mesh.lengths, &samples, [0.; 2]).unwrap();
        let sampled: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| aux.sample(c.centroid, 0.).unwrap())
            .collect();
        let w: Vec<_> = sampled
            .iter()
            .map(|u| [u.velocity[0], u.velocity[1]])
            .collect();
        let fluxes = vec![
            FaceFlux {
                fluid: [0.; 5],
                induction: [0.; 3],
                electromotive: [0.; 3],
                velocity: [0.; 3],
                magnetic: [0.; 3],
                max_speed: 1.,
                method: FluxMethod::HllFallback
            };
            mesh.faces.len()
        ];
        let stencil = Derivatives::build(&mesh, true).unwrap();
        let rate = PotentialStage {
            mesh: &mesh,
            face_stencil: &stencil,
            potential: &potential,
            fit: &fit,
            faces: &fluxes,
            auxiliary: &aux,
            advection_velocity: &w,
            mean: [0.; 3],
            reference_velocity: [0.; 3],
            tau: 0.,
            centered: false,
        }
        .rate()
        .unwrap();
        let mut z_coupling = 0_f64;
        for (r, u) in rate.iter().zip(sampled) {
            let h = u.jacobian;
            let exact = [
                -0.2 * h[0][0] + 0.4 * h[1][0] - 0.7 * h[2][0],
                -0.2 * h[0][1] + 0.4 * h[1][1] - 0.7 * h[2][1],
                0.,
            ];
            for k in 0..3 {
                assert!((r[k] - exact[k]).abs() < 1e-11);
            }
            z_coupling = z_coupling.max(h[2][0].abs()).max(h[2][1].abs());
        }
        assert!(z_coupling > 0.1);
    }
}

}
mod general {
// Serial periodic 2.5D coupled reference with explicitly named gauge profiles.
// See docs/VECTOR_POTENTIAL_REFERENCE.md for sources, engineering choices and gates.
use crate::auxiliary::{SmoothVelocity, VelocitySample};
use crate::gauge::{Cleaning, CleaningStage};
use crate::operators::{
    MagneticFit, PotentialStage, PrimitiveGradient, components, face_velocity, gradients, predict,
};
use mhd_core::{
    Conservative, FaceCompletion, FaceFlux, FluxMethod, IdealGas, Primitive, Vec3, cross,
    riemann_with_completion,
};
use moving_mesh::{
    Derivatives, Mesh, Vec2, dot,
    quadratic::{Compact, Quadratic},
};
use std::{f64::consts::PI, sync::Arc};

#[derive(Clone, Debug)]
pub enum Motion {
    Fixed,
    Rigid(Vec2),
    Fluid,
    /// Persistent cell IDs; velocities held fixed throughout each attempted step.
    Prescribed(Vec<Vec2>),
}
/// Named algorithms: the original paper profile remains the default.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Profile {
    #[default]
    PaperGlobalV2,
    /// Explicit gauge psi=u dot a with A=a+C, Cdot=Vref cross mean_B.
    BulkFrameV1,
    /// Bulk-frame gauge with continuous symmetric-fan A-face completion.
    BulkFrameHllV1,
    /// Optional quadratic A reconstruction; all other completion/stage choices retained.
    BulkFrameHllQuadraticV1,
    /// Quadratic A fit with affine-exact source and quadratic-consistent advection.
    BulkFrameHllConsistentV1,
    /// Consistent-rate profile with the same quadratic derivative for phi and A.
    BulkFrameHllMatchedV1,
    /// Direct-neighbour derivative with quadratic moments removed, for A and phi.
    BulkFrameHllCompactV1,
    /// Compact raw derivative with continuous bounded quadratic-jet projection.
    BulkFrameHllProjectedV1,
}
impl Profile {
    pub fn name(self) -> &'static str {
        match self {
            Self::PaperGlobalV2 => "paper-global-v2",
            Self::BulkFrameV1 => "bulk-frame-v1",
            Self::BulkFrameHllV1 => "bulk-frame-hll-v1",
            Self::BulkFrameHllQuadraticV1 => "bulk-frame-hll-quadratic-v1",
            Self::BulkFrameHllConsistentV1 => "bulk-frame-hll-consistent-v1",
            Self::BulkFrameHllMatchedV1 => "bulk-frame-hll-matched-v1",
            Self::BulkFrameHllCompactV1 => "bulk-frame-hll-compact-v1",
            Self::BulkFrameHllProjectedV1 => "bulk-frame-hll-projected-v1",
        }
    }
    fn quadratic(self) -> bool {
        matches!(
            self,
            Self::BulkFrameHllQuadraticV1
                | Self::BulkFrameHllConsistentV1
                | Self::BulkFrameHllMatchedV1
                | Self::BulkFrameHllCompactV1
                | Self::BulkFrameHllProjectedV1
        )
    }
    fn consistent(self) -> bool {
        matches!(
            self,
            Self::BulkFrameHllConsistentV1
                | Self::BulkFrameHllMatchedV1
                | Self::BulkFrameHllCompactV1
                | Self::BulkFrameHllProjectedV1
        )
    }
    fn matched(self) -> bool {
        matches!(
            self,
            Self::BulkFrameHllMatchedV1
                | Self::BulkFrameHllCompactV1
                | Self::BulkFrameHllProjectedV1
        )
    }
    fn compact(self) -> bool {
        matches!(
            self,
            Self::BulkFrameHllCompactV1 | Self::BulkFrameHllProjectedV1
        )
    }
    fn projected(self) -> bool {
        self == Self::BulkFrameHllProjectedV1
    }
    fn completion(self) -> FaceCompletion {
        match self {
            Self::BulkFrameHllV1
            | Self::BulkFrameHllQuadraticV1
            | Self::BulkFrameHllConsistentV1
            | Self::BulkFrameHllMatchedV1
            | Self::BulkFrameHllCompactV1
            | Self::BulkFrameHllProjectedV1 => FaceCompletion::SymmetricHll,
            _ => FaceCompletion::RiemannState,
        }
    }
}
#[derive(Clone, Debug)]
pub struct Config {
    pub profile: Profile,
    pub gamma: f64,
    pub mean_magnetic: Vec3,
    pub motion: Motion,
    pub cfl: f64,
    pub max_dt: f64,
    pub limited: bool,
    /// Fixed initial field scale for dimensionless divergence diagnostics.
    pub magnetic_scale: f64,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            profile: Profile::PaperGlobalV2,
            gamma: 5. / 3.,
            mean_magnetic: [0.; 3],
            motion: Motion::Fixed,
            cfl: 0.3,
            max_dt: f64::INFINITY,
            limited: true,
            magnetic_scale: 1.,
        }
    }
}
#[derive(Clone, Copy, Debug)]
pub struct Initial {
    pub density: f64,
    pub pressure: f64,
    pub velocity: Vec3,
    pub potential: Vec3,
    pub phi: f64,
}
#[derive(Clone, Debug)]
pub struct State {
    pub mesh: Mesh,
    /// Reduced a; total periodic potential is a + gauge_offset. V2 offset is zero.
    pub potential: Vec<Vec3>,
    pub gauge_offset: Vec3,
    pub phi: Vec<f64>,
    /// Cell-integrated (mass, momentum3, total energy); never a density here.
    pub conserved: Vec<Conservative>,
    pub auxiliary_origin: Vec2,
}
#[derive(Clone, Debug, Default)]
pub struct Counters {
    pub steps: usize,
    pub rejected_geometry: usize,
    pub rejected_state: usize,
    pub rejected_cfl: usize,
    /// Successful HLL face results used by accepted stages.
    pub hll_fallbacks: usize,
    /// All successful HLL results, including discarded/partially failed sweeps.
    pub hll_fallbacks_attempted: usize,
    pub auxiliary_coarsenings: usize,
    pub auxiliary_roots: Vec<usize>,
    pub min_dt: Option<f64>,
    pub max_dt: f64,
    /// Maximum x-characteristic speed in accepted old/predicted/closed cell states.
    pub max_signal_x: f64,
    /// Maximum face-rest fan bound in accepted fluid sweeps.
    pub max_face_signal: f64,
    /// Sum of accepted dt times max(cell x speed, face-rest fan speed);
    /// a seam bound for the fixed-grid Brio strip, not a general lab-frame bound.
    pub integrated_signal_travel: f64,
    /// Max accepted per-step |V1-V0-dt/2*(Vdot0+Vdot1)|/V0.
    pub geometric_conservation_max: f64,
}
#[derive(Clone, Debug)]
pub struct Simulation {
    state: State,
    // Only shared immutable state is exposed; rebuild on every deformation.
    geometry: Arc<Geometry>,
    config: Config,
    time: f64,
    reference_velocity: Vec3,
    counters: Counters,
    pub(crate) initial_totals: Conservative,
    pub(crate) budget_scales: Conservative,
    pub(crate) initial_mean: Vec3,
}
#[derive(Clone, Debug)]
struct Geometry {
    mesh: Mesh,
    neighbours: Derivatives,
    faces: Derivatives,
    quadratic: Option<Quadratic>,
    compact: Option<Compact>,
}
impl Geometry {
    fn new(mesh: Mesh, quadratic: bool, compact: bool) -> Result<Self, String> {
        let neighbours = Derivatives::build(&mesh, false)?;
        let faces = Derivatives::build(&mesh, true)?;
        let quadratic = if quadratic {
            Some(Quadratic::build(&mesh)?)
        } else {
            None
        };
        let compact = if compact {
            Some(Compact::build(&mesh, &neighbours)?)
        } else {
            None
        };
        Ok(Self {
            compact,
            quadratic,
            mesh,
            neighbours,
            faces,
        })
    }
}
struct FluidRate {
    q: Vec<Conservative>,
    fluxes: Vec<FaceFlux>,
    waves: Vec<f64>,
    fallbacks: usize,
    volume_rate: Vec<f64>,
}
struct Prepared {
    geometry: Arc<Geometry>,
    primitive: Vec<Primitive>,
    gradients: Vec<PrimitiveGradient>,
    generator_velocity: Vec<Vec2>,
    auxiliary: SmoothVelocity,
    fluid: FluidRate,
    potential_rate: Vec<Vec3>,
    cleaning: Vec<CleaningStage>,
    sound: Vec<f64>,
    bound: f64,
}
#[derive(Debug)]
enum TrialError {
    Geometry(String),
    State(String),
    Cfl,
}
impl From<String> for TrialError {
    fn from(s: String) -> Self {
        Self::State(s)
    }
}
struct Accepted {
    state: State,
    geometry: Arc<Geometry>,
    fallbacks: usize,
    geometric_error: f64,
    max_signal_x: f64,
    max_face_signal: f64,
}

fn radius(volume: f64) -> f64 {
    (volume / PI).sqrt()
}
fn sound(eos: IdealGas, q: Primitive) -> f64 {
    (eos.gamma() * q.pressure / q.density).sqrt()
}
fn recover(eos: IdealGas, state: &State, fit: &MagneticFit) -> Result<Vec<Primitive>, String> {
    state
        .conserved
        .iter()
        .zip(&state.mesh.cells)
        .zip(&fit.magnetic)
        .map(|((q, c), &b)| eos.recover(q.map(|x| x / c.volume), b))
        .collect()
}
fn fluid_rate(
    physics: (IdealGas, FaceCompletion),
    geometry: &Geometry,
    primitive_data: (&[Primitive], &[PrimitiveGradient]),
    generator_velocity: &[Vec2],
    cell_paths: &[Vec2],
    dt: f64,
    attempted_fallbacks: &mut usize,
) -> Result<FluidRate, String> {
    let (eos, completion) = physics;
    let (old, grad) = primitive_data;
    let mesh = &geometry.mesh;
    let mut q = vec![[0.; 5]; mesh.cells.len()];
    let mut waves = vec![0.; mesh.cells.len()];
    let mut volume_rate = vec![0.; mesh.cells.len()];
    let mut fluxes = Vec::with_capacity(mesh.faces.len());
    let mut fallbacks = 0;
    for face in &mesh.faces {
        let reconstruct = |i| {
            let d = mesh.displacement(face, i);
            predict(
                eos,
                old[i],
                grad[i],
                [cell_paths[i][0] + d[0], cell_paths[i][1] + d[1]],
                dt,
            )
        };
        let wf = face_velocity(mesh, face, generator_velocity)?;
        let volume_flux = face.area * (wf[0] * face.normal[0] + wf[1] * face.normal[1]);
        volume_rate[face.left] += volume_flux;
        volume_rate[face.right] -= volume_flux;
        let flux = riemann_with_completion(
            eos,
            reconstruct(face.left)?,
            reconstruct(face.right)?,
            [face.normal[0], face.normal[1], 0.],
            wf,
            completion,
        )?;
        for k in 0..5 {
            let exchange = face.area * flux.fluid[k];
            q[face.left][k] -= exchange;
            q[face.right][k] += exchange;
        }
        for i in [face.left, face.right] {
            waves[i] += face.area * flux.max_speed;
        }
        let fallback = usize::from(flux.method == FluxMethod::HllFallback);
        fallbacks += fallback;
        *attempted_fallbacks += fallback;
        fluxes.push(flux);
    }
    if !q
        .iter()
        .flatten()
        .chain(&waves)
        .chain(&volume_rate)
        .all(|x| x.is_finite())
    {
        return Err("fluid rate overflow".into());
    }
    Ok(FluidRate {
        q,
        fluxes,
        waves,
        fallbacks,
        volume_rate,
    })
}

struct Bound<'a> {
    geometry: &'a Geometry,
    auxiliary: &'a SmoothVelocity,
    generator_velocity: &'a [Vec2],
    advection_velocity: &'a [Vec2],
    waves: &'a [f64],
    sound: &'a [f64],
    tau: f64,
}
impl Bound<'_> {
    fn value(&self, cfl: f64) -> Result<f64, String> {
        let mut bound = f64::INFINITY;
        let mesh = &self.geometry.mesh;
        for (i, cell) in mesh.cells.iter().enumerate() {
            let r = radius(cell.volume);
            let cleaning = Cleaning::default().bounds(self.sound[i], r)?;
            bound = bound.min(cleaning.hyperbolic).min(cleaning.diffusive);
            if self.waves[i] > 0. {
                bound = bound.min(cell.volume / self.waves[i]);
            }
            let aux = self.auxiliary.sample(cell.centroid, self.tau)?;
            let b = [
                self.advection_velocity[i][0] - aux.velocity[0],
                self.advection_velocity[i][1] - aux.velocity[1],
            ];
            let advection: f64 = self.geometry.faces.samples[i]
                .iter()
                .map(|s| dot(b, s.weight).abs())
                .sum();
            if advection > 0. {
                bound = bound.min(1. / advection);
            }
            let distortion = (0..3)
                .map(|k| (0..3).map(|a| aux.jacobian[a][k].abs()).sum::<f64>())
                .fold(0., f64::max);
            if distortion > 0. {
                bound = bound.min(1. / distortion);
            }
            for &(f, _) in &cell.faces {
                let j = mesh.neighbour(&mesh.faces[f], i).0;
                let relative = (self.generator_velocity[i][0] - self.generator_velocity[j][0])
                    .hypot(self.generator_velocity[i][1] - self.generator_velocity[j][1]);
                if relative > 0. {
                    bound = bound.min(r / relative);
                }
            }
        }
        let result = cfl * bound;
        if !result.is_finite() || result <= 0. {
            return Err("invalid global timestep bound".into());
        }
        Ok(result)
    }
}

type Endpoint = (Arc<Geometry>, Vec<Vec2>, Vec<Vec2>);

/// Preserve winding through generator motion plus changes of centroid offsets.
fn endpoint(old: &Arc<Geometry>, w: &[Vec2], dt: f64, rigid: bool) -> Result<Endpoint, String> {
    let mesh = &old.mesh;
    if rigid {
        // Translation leaves all metric data and LS weights invariant. Translate
        // local images with the left generator and update right-image identities.
        let shift = [dt * w[0][0], dt * w[0][1]];
        if shift == [0.; 2] {
            return Ok((Arc::clone(old), vec![shift; w.len()], w.to_vec()));
        }
        let wrapped: Vec<Vec2> = mesh
            .generators
            .iter()
            .map(|g| std::array::from_fn(|k| (g[k] + shift[k]).rem_euclid(mesh.lengths[k])))
            .collect();
        let local_shift: Vec<Vec2> = wrapped
            .iter()
            .zip(&mesh.generators)
            .map(|(new, old)| [new[0] - old[0], new[1] - old[1]])
            .collect();
        let mut next = (**old).clone();
        next.mesh.generators = wrapped;
        for (cell, s) in next.mesh.cells.iter_mut().zip(&local_shift) {
            for (coordinate, shift) in cell.centroid.iter_mut().zip(s) {
                *coordinate += shift;
            }
        }
        for face in &mut next.mesh.faces {
            let s = local_shift[face.left];
            for (k, shift) in s.iter().enumerate() {
                face.centroid[k] += shift;
                let image = f64::from(face.image[k])
                    + (s[k] - local_shift[face.right][k]) / mesh.lengths[k];
                if !image.is_finite() || image.round().abs() > 1. {
                    return Err("invalid translated periodic image".into());
                }
                face.image[k] = image.round() as i32;
            }
        }
        next.mesh.validate()?;
        return Ok((Arc::new(next), vec![shift; w.len()], w.to_vec()));
    }
    let points = mesh
        .generators
        .iter()
        .zip(w)
        .map(|(g, w)| [g[0] + dt * w[0], g[1] + dt * w[1]])
        .collect();
    let next = Geometry::new(
        Mesh::build(points, mesh.lengths)?,
        old.quadratic.is_some(),
        old.compact.is_some(),
    )?;
    let mut paths = Vec::with_capacity(w.len());
    let mut what = Vec::with_capacity(w.len());
    for (i, wi) in w.iter().enumerate() {
        let delta: Vec2 = std::array::from_fn(|k| {
            (next.mesh.cells[i].centroid[k] - next.mesh.generators[i][k])
                - (mesh.cells[i].centroid[k] - mesh.generators[i][k])
        });
        paths.push(std::array::from_fn(|k| dt * wi[k] + delta[k]));
        what.push(std::array::from_fn(|k| wi[k] + 2. * delta[k] / dt));
    }
    Ok((Arc::new(next), paths, what))
}

impl Simulation {
    pub fn new(
        mesh: Mesh,
        config: Config,
        initial: impl Fn(Vec2) -> Initial,
    ) -> Result<Self, String> {
        mesh.validate()?;
        let eos = IdealGas::new(config.gamma)?;
        if !config.cfl.is_finite()
            || config.cfl <= 0.
            || config.cfl > 0.3
            || config.max_dt.is_nan()
            || config.max_dt <= 0.
            || !config.magnetic_scale.is_finite()
            || config.magnetic_scale <= 0.
            || !config.mean_magnetic.iter().all(|x| x.is_finite())
        {
            return Err("invalid general reference configuration".into());
        }
        let data: Vec<_> = mesh.cells.iter().map(|c| initial(c.centroid)).collect();
        let potential: Vec<_> = data.iter().map(|q| q.potential).collect();
        let phi: Vec<_> = data.iter().map(|q| q.phi).collect();
        let geometry = Arc::new(Geometry::new(
            mesh.clone(),
            config.profile.quadratic(),
            config.profile.compact(),
        )?);
        let fit = MagneticFit::with_projection(
            &mesh,
            (
                &geometry.neighbours,
                geometry.quadratic.as_ref(),
                geometry.compact.as_ref(),
                config.profile.consistent(),
                config.profile.matched(),
            ),
            &potential,
            &phi,
            config.mean_magnetic,
            config.limited,
            config.profile.projected(),
        )?;
        let primitive: Vec<_> = data
            .iter()
            .zip(&fit.magnetic)
            .map(|(q, &b)| Primitive {
                density: q.density,
                pressure: q.pressure,
                velocity: q.velocity,
                magnetic: b,
            })
            .collect();
        let conserved: Vec<Conservative> = primitive
            .iter()
            .zip(&mesh.cells)
            .map(|(&q, c)| eos.conservative(q).map(|v| v.map(|x| x * c.volume)))
            .collect::<Result<_, _>>()?;
        let volume: f64 = mesh.cells.iter().map(|c| c.volume).sum();
        let initial_totals: Conservative =
            std::array::from_fn(|k| conserved.iter().map(|q| q[k]).sum());
        let reference_velocity: Vec3 = match config.profile {
            Profile::PaperGlobalV2 => [0.; 3],
            Profile::BulkFrameV1
            | Profile::BulkFrameHllV1
            | Profile::BulkFrameHllQuadraticV1
            | Profile::BulkFrameHllConsistentV1
            | Profile::BulkFrameHllMatchedV1
            | Profile::BulkFrameHllCompactV1
            | Profile::BulkFrameHllProjectedV1 => {
                std::array::from_fn(|k| initial_totals[k + 1] / initial_totals[0])
            }
        };
        if !reference_velocity.iter().all(|v| v.is_finite()) {
            return Err("nonfinite gauge reference velocity".into());
        }
        let rho = primitive.iter().map(|q| q.density).fold(0., f64::max);
        let speed = primitive
            .iter()
            .map(|q| {
                q.velocity[0]
                    .hypot(q.velocity[1])
                    .hypot(q.velocity[2])
                    .max(sound(eos, *q))
            })
            .fold(0., f64::max);
        let energy = conserved
            .iter()
            .zip(&mesh.cells)
            .map(|(q, c)| q[4] / c.volume)
            .fold(0., f64::max);
        let scales = [rho, rho * speed, rho * speed, rho * speed, energy];
        let budget_scales = std::array::from_fn(|k| {
            conserved
                .iter()
                .map(|q| q[k].abs())
                .sum::<f64>()
                .max(volume * scales[k])
                .max(1e-30)
        });
        let initial_mean = std::array::from_fn(|k| {
            fit.magnetic
                .iter()
                .zip(&mesh.cells)
                .map(|(b, c)| b[k] * c.volume)
                .sum::<f64>()
                / volume
        });
        let result = Self {
            geometry,
            state: State {
                mesh,
                potential,
                phi,
                conserved,
                auxiliary_origin: [0.; 2],
                gauge_offset: [0.; 3],
            },
            config,
            time: 0.,
            reference_velocity,
            counters: Counters::default(),
            initial_totals,
            budget_scales,
            initial_mean,
        };
        result.generator_velocities(&primitive)?;
        Ok(result)
    }
    pub fn state(&self) -> &State {
        &self.state
    }
    pub fn config(&self) -> &Config {
        &self.config
    }
    /// Fixed initial mass-weighted velocity, used only by the gauge comparator.
    pub fn reference_velocity(&self) -> Vec3 {
        self.reference_velocity
    }
    pub fn total_potential(&self) -> Vec<Vec3> {
        self.state
            .potential
            .iter()
            .map(|a| std::array::from_fn(|k| a[k] + self.state.gauge_offset[k]))
            .collect()
    }
    pub fn time(&self) -> f64 {
        self.time
    }
    pub fn counters(&self) -> &Counters {
        &self.counters
    }
    pub fn quadratic_condition(&self) -> Option<f64> {
        self.geometry.quadratic.as_ref().map(|q| q.worst_condition)
    }
    pub fn magnetic_fit(&self) -> Result<MagneticFit, String> {
        MagneticFit::with_projection(
            &self.geometry.mesh,
            (
                &self.geometry.neighbours,
                self.geometry.quadratic.as_ref(),
                self.geometry.compact.as_ref(),
                self.config.profile.consistent(),
                self.config.profile.matched(),
            ),
            &self.state.potential,
            &self.state.phi,
            self.config.mean_magnetic,
            self.config.limited,
            self.config.profile.projected(),
        )
    }
    pub fn primitives(&self) -> Result<Vec<Primitive>, String> {
        recover(
            IdealGas::new(self.config.gamma)?,
            &self.state,
            &self.magnetic_fit()?,
        )
    }
    fn generator_velocities(&self, q: &[Primitive]) -> Result<Vec<Vec2>, String> {
        let n = self.state.mesh.cells.len();
        let w = match &self.config.motion {
            Motion::Fixed => vec![[0.; 2]; n],
            Motion::Rigid(v) => vec![*v; n],
            Motion::Fluid => q.iter().map(|q| [q.velocity[0], q.velocity[1]]).collect(),
            Motion::Prescribed(v) => v.clone(),
        };
        if w.len() != n || !w.iter().flatten().all(|x| x.is_finite()) {
            return Err("invalid generator velocities".into());
        }
        Ok(w)
    }
    fn prepare(&self, attempted: &mut usize) -> Result<Prepared, String> {
        let eos = IdealGas::new(self.config.gamma)?;
        let geometry = Arc::clone(&self.geometry);
        let fit = MagneticFit::with_projection(
            &geometry.mesh,
            (
                &geometry.neighbours,
                geometry.quadratic.as_ref(),
                geometry.compact.as_ref(),
                self.config.profile.consistent(),
                self.config.profile.matched(),
            ),
            &self.state.potential,
            &self.state.phi,
            self.config.mean_magnetic,
            self.config.limited,
            self.config.profile.projected(),
        )?;
        let primitive = recover(eos, &self.state, &fit)?;
        let gradients = gradients(
            &geometry.mesh,
            &geometry.neighbours,
            &primitive.iter().map(|q| components(*q)).collect::<Vec<_>>(),
            self.config.limited,
        )?;
        let generator_velocity = self.generator_velocities(&primitive)?;
        let samples: Vec<_> = primitive
            .iter()
            .zip(&geometry.mesh.cells)
            .map(|(q, c)| VelocitySample {
                position: c.centroid,
                volume: c.volume,
                velocity: q.velocity,
            })
            .collect();
        let auxiliary =
            SmoothVelocity::build(geometry.mesh.lengths, &samples, self.state.auxiliary_origin)?;
        let fluid = fluid_rate(
            (eos, self.config.profile.completion()),
            &geometry,
            (&primitive, &gradients),
            &generator_velocity,
            &vec![[0.; 2]; primitive.len()],
            0.,
            attempted,
        )?;
        let potential_rate = PotentialStage {
            mesh: &geometry.mesh,
            face_stencil: &geometry.faces,
            potential: &self.state.potential,
            fit: &fit,
            faces: &fluid.fluxes,
            auxiliary: &auxiliary,
            advection_velocity: &generator_velocity,
            mean: self.config.mean_magnetic,
            reference_velocity: self.reference_velocity,
            tau: 0.,
            centered: self.config.profile.consistent(),
        }
        .rate()?;
        let sound: Vec<_> = primitive.iter().map(|&q| sound(eos, q)).collect();
        let cleaning = (0..primitive.len())
            .map(|i| {
                Cleaning::default().begin(
                    self.state.phi[i],
                    fit.divergence_a[i],
                    sound[i],
                    radius(geometry.mesh.cells[i].volume),
                )
            })
            .collect::<Result<_, _>>()?;
        let bound = Bound {
            geometry: &geometry,
            auxiliary: &auxiliary,
            generator_velocity: &generator_velocity,
            advection_velocity: &generator_velocity,
            waves: &fluid.waves,
            sound: &sound,
            tau: 0.,
        }
        .value(self.config.cfl)?;
        Ok(Prepared {
            geometry,
            primitive,
            gradients,
            generator_velocity,
            auxiliary,
            fluid,
            potential_rate,
            cleaning,
            sound,
            bound,
        })
    }
    fn trial(
        &self,
        old: &Prepared,
        dt: f64,
        attempted: &mut usize,
    ) -> Result<Accepted, TrialError> {
        let eos = IdealGas::new(self.config.gamma)?;
        let rigid = matches!(self.config.motion, Motion::Fixed | Motion::Rigid(_));
        let (geometry, paths, what) = endpoint(&old.geometry, &old.generator_velocity, dt, rigid)
            .map_err(TrialError::Geometry)?;
        let star: Vec<Vec3> = self
            .state
            .potential
            .iter()
            .zip(&old.potential_rate)
            .map(|(a, r)| std::array::from_fn(|k| a[k] + dt * r[k]))
            .collect();
        let phi_star = old
            .cleaning
            .iter()
            .map(|c| c.predicted_phi(dt))
            .collect::<Result<Vec<_>, _>>()?;
        let fit = MagneticFit::with_projection(
            &geometry.mesh,
            (
                &geometry.neighbours,
                geometry.quadratic.as_ref(),
                geometry.compact.as_ref(),
                self.config.profile.consistent(),
                self.config.profile.matched(),
            ),
            &star,
            &phi_star,
            self.config.mean_magnetic,
            self.config.limited,
            self.config.profile.projected(),
        )
        .map_err(TrialError::State)?;
        let fluid = fluid_rate(
            (eos, self.config.profile.completion()),
            &geometry,
            (&old.primitive, &old.gradients),
            &old.generator_velocity,
            &paths,
            dt,
            attempted,
        )?;
        let rate = PotentialStage {
            mesh: &geometry.mesh,
            face_stencil: &geometry.faces,
            potential: &star,
            fit: &fit,
            faces: &fluid.fluxes,
            auxiliary: &old.auxiliary,
            advection_velocity: &what,
            mean: self.config.mean_magnetic,
            reference_velocity: self.reference_velocity,
            tau: dt,
            centered: self.config.profile.consistent(),
        }
        .rate()?;
        let predicted = old
            .primitive
            .iter()
            .enumerate()
            .map(|(i, &q)| predict(eos, q, old.gradients[i], paths[i], dt))
            .collect::<Result<Vec<_>, _>>()?;
        let mut sound_bound: Vec<_> = predicted
            .iter()
            .enumerate()
            .map(|(i, &q)| sound(eos, q).max(old.sound[i]))
            .collect();
        let bound = |cs: &[f64]| {
            Bound {
                geometry: &geometry,
                auxiliary: &old.auxiliary,
                generator_velocity: &old.generator_velocity,
                advection_velocity: &what,
                waves: &fluid.waves,
                sound: cs,
                tau: dt,
            }
            .value(self.config.cfl)
        };
        if dt > bound(&sound_bound)? * (1. + 1e-12) {
            return Err(TrialError::Cfl);
        }
        let potential = self
            .state
            .potential
            .iter()
            .enumerate()
            .map(|(i, a)| {
                std::array::from_fn(|k| a[k] + 0.5 * dt * (old.potential_rate[i][k] + rate[i][k]))
            })
            .collect();
        let phi = old
            .cleaning
            .iter()
            .enumerate()
            .map(|(i, c)| c.finish_phi(dt, radius(geometry.mesh.cells[i].volume)))
            .collect::<Result<_, _>>()?;
        let conserved = self
            .state
            .conserved
            .iter()
            .enumerate()
            .map(|(i, q)| {
                std::array::from_fn(|k| q[k] + 0.5 * dt * (old.fluid.q[i][k] + fluid.q[i][k]))
            })
            .collect();
        let offset_rate = cross(self.reference_velocity, self.config.mean_magnetic);
        let next = State {
            mesh: geometry.mesh.clone(),
            potential,
            phi,
            conserved,
            auxiliary_origin: old.auxiliary.advanced_origin(dt)?,
            gauge_offset: std::array::from_fn(|k| self.state.gauge_offset[k] + dt * offset_rate[k]),
        };
        if !next.gauge_offset.iter().all(|x| x.is_finite())
            || next
                .potential
                .iter()
                .any(|a| (0..3).any(|k| !(a[k] + next.gauge_offset[k]).is_finite()))
        {
            return Err(TrialError::State(
                "total potential/gauge offset overflow".into(),
            ));
        }
        let final_fit = MagneticFit::with_projection(
            &next.mesh,
            (
                &geometry.neighbours,
                geometry.quadratic.as_ref(),
                geometry.compact.as_ref(),
                self.config.profile.consistent(),
                self.config.profile.matched(),
            ),
            &next.potential,
            &next.phi,
            self.config.mean_magnetic,
            self.config.limited,
            self.config.profile.projected(),
        )?;
        let closed = recover(eos, &next, &final_fit)?;
        for (i, &q) in closed.iter().enumerate() {
            sound_bound[i] = sound_bound[i].max(sound(eos, q));
        }
        if dt > bound(&sound_bound)? * (1. + 1e-12) {
            return Err(TrialError::Cfl);
        }
        let geometric_error = next
            .mesh
            .cells
            .iter()
            .enumerate()
            .map(|(i, c)| {
                let v0 = self.state.mesh.cells[i].volume;
                (c.volume - v0 - 0.5 * dt * (old.fluid.volume_rate[i] + fluid.volume_rate[i])).abs()
                    / v0
            })
            .fold(0., f64::max);
        if !geometric_error.is_finite() {
            return Err(TrialError::Geometry(
                "nonfinite geometric conservation error".into(),
            ));
        }
        let max_signal_x = old
            .primitive
            .iter()
            .chain(&predicted)
            .chain(&closed)
            .map(|&q| q.velocity[0].abs() + eos.fast_speed(q, [1., 0., 0.]))
            .fold(0., f64::max);
        let max_face_signal = old
            .fluid
            .fluxes
            .iter()
            .chain(&fluid.fluxes)
            .map(|f| f.max_speed)
            .fold(0., f64::max);
        Ok(Accepted {
            max_signal_x,
            max_face_signal,
            state: next,
            geometry,
            fallbacks: fluid.fallbacks,
            geometric_error,
        })
    }
    pub fn advance_to(&mut self, target: f64) -> Result<(), String> {
        if !target.is_finite() || target < self.time {
            return Err("invalid target time".into());
        }
        while self.time < target {
            let mut attempted = 0;
            let preparation = self.prepare(&mut attempted);
            self.counters.hll_fallbacks_attempted += attempted;
            let old = preparation?;
            let mut dt = old.bound.min(self.config.max_dt).min(target - self.time);
            let mut accepted = None;
            let mut last_error = String::new();
            for _ in 0..16 {
                if !dt.is_finite()
                    || dt <= 0.
                    || self.time + dt == self.time
                    || self.counters.steps >= 1_000_000
                {
                    return Err("timestep underflow or step limit".into());
                }
                let mut attempted = 0;
                let trial = self.trial(&old, dt, &mut attempted);
                self.counters.hll_fallbacks_attempted += attempted;
                match trial {
                    Ok(next) => {
                        accepted = Some(next);
                        break;
                    }
                    Err(e) => {
                        last_error = match e {
                            TrialError::Geometry(s) => {
                                self.counters.rejected_geometry += 1;
                                s
                            }
                            TrialError::State(s) => {
                                self.counters.rejected_state += 1;
                                s
                            }
                            TrialError::Cfl => {
                                self.counters.rejected_cfl += 1;
                                "endpoint CFL bound".into()
                            }
                        };
                        dt *= 0.5;
                    }
                }
            }
            let next =
                accepted.ok_or_else(|| format!("step failed at t={}: {last_error}", self.time))?;
            self.counters.max_signal_x = self.counters.max_signal_x.max(next.max_signal_x);
            self.counters.max_face_signal = self.counters.max_face_signal.max(next.max_face_signal);
            self.counters.integrated_signal_travel +=
                dt * next.max_signal_x.max(next.max_face_signal);
            self.state = next.state;
            self.geometry = next.geometry;
            self.time = (self.time + dt).min(target);
            self.counters.steps += 1;
            self.counters.min_dt = Some(self.counters.min_dt.map_or(dt, |d| d.min(dt)));
            self.counters.max_dt = self.counters.max_dt.max(dt);
            self.counters.geometric_conservation_max = self
                .counters
                .geometric_conservation_max
                .max(next.geometric_error);
            self.counters.hll_fallbacks += old.fluid.fallbacks + next.fallbacks;
            self.counters
                .auxiliary_roots
                .push(old.auxiliary.intervals());
            self.counters.auxiliary_coarsenings += old.auxiliary.coarsenings;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::TAU;
    fn initial(_: Vec2) -> Initial {
        Initial {
            density: 1.,
            pressure: 1.,
            velocity: [0.2, -0.1, 0.3],
            potential: [0.1, -0.2, 0.4],
            phi: 0.,
        }
    }
    #[test]
    fn endpoint_winding_topology_and_rejected_trial_are_consistent() {
        let mesh = Mesh::lattice(6, 6, [1.; 2], 0.).unwrap();
        let w: Vec<_> = mesh
            .generators
            .iter()
            .map(|p| [0.1 * (TAU * p[1]).sin(), 0.1 * (TAU * p[0]).cos()])
            .collect();
        let sim = Simulation::new(
            mesh.clone(),
            Config {
                motion: Motion::Prescribed(w.clone()),
                ..Config::default()
            },
            initial,
        )
        .unwrap();
        let old = sim.prepare(&mut 0).unwrap();
        let (end, _, _) = endpoint(&old.geometry, &w, 0.04, false).unwrap();
        assert_ne!(old.geometry.mesh.faces.len(), end.mesh.faces.len());
        let before = format!("{:?}", sim.state);
        let auxiliary_before = format!("{:?}", old.auxiliary);
        assert!(sim.trial(&old, 1., &mut 0).is_err());
        assert_eq!(before, format!("{:?}", sim.state));
        assert_eq!(auxiliary_before, format!("{:?}", old.auxiliary));
        // A later good trial remains possible from exactly the same old data.
        assert!(sim.trial(&old, 0.1 * old.bound, &mut 0).is_ok());
        let rigid = vec![[200., -300.]; mesh.cells.len()];
        let (end, paths, what) = endpoint(&old.geometry, &rigid, 0.017, true).unwrap();
        for i in 0..paths.len() {
            assert!((paths[i][0] - 3.4).abs() < 1e-12);
            assert!((paths[i][1] + 5.1).abs() < 1e-12);
            assert_eq!(what[i], rigid[i]);
            for k in 0..2 {
                let residual = (end.mesh.generators[i][k] - mesh.generators[i][k] - paths[i][k]
                    + 0.5)
                    .rem_euclid(1.)
                    - 0.5;
                assert!(residual.abs() < 1e-12);
            }
        }
    }
    #[test]
    fn bulk_gauge_offset_and_geometry_survive_rejected_trial() {
        let mut sim = Simulation::new(
            Mesh::lattice(6, 6, [1.; 2], 0.15).unwrap(),
            Config {
                profile: Profile::BulkFrameV1,
                mean_magnetic: [0.3, 0.2, 0.1],
                max_dt: 0.001,
                ..Config::default()
            },
            initial,
        )
        .unwrap();
        sim.advance_to(0.002).unwrap();
        assert_ne!(sim.state.gauge_offset, [0.; 3]);
        let old = sim.prepare(&mut 0).unwrap();
        let before = format!("{:?}", sim);
        assert!(sim.trial(&old, 1., &mut 0).is_err());
        assert_eq!(before, format!("{:?}", sim));
        assert!(Arc::ptr_eq(&old.geometry, &sim.geometry));
        let dt = 0.1 * old.bound;
        let accepted = sim.trial(&old, dt, &mut 0).unwrap();
        let rate = cross(sim.reference_velocity, sim.config.mean_magnetic);
        for (k, rate) in rate.iter().enumerate() {
            assert_eq!(
                accepted.state.gauge_offset[k],
                sim.state.gauge_offset[k] + dt * rate
            );
        }
    }

    #[test]
    fn cached_geometry_matches_rebuilt_clipping_evolution() {
        for jitter in [0., 0.15] {
            for motion in [
                Motion::Fixed,
                Motion::Rigid([2., -1.]),
                Motion::Rigid([0.2, -0.1]),
                Motion::Fluid,
            ] {
                let mesh = Mesh::lattice(6, 8, [1.3, 0.7], jitter).unwrap();
                let original =
                    Mesh::build_all_pairs(mesh.generators.clone(), mesh.lengths).unwrap();
                let config = Config {
                    motion: motion.clone(),
                    max_dt: 0.0005,
                    ..Config::default()
                };
                let data = |x: Vec2| Initial {
                    velocity: [0.2 + 0.03 * (TAU * x[1] / 0.7).sin(), -0.1, 0.04],
                    potential: [
                        0.001 * (TAU * x[1] / 0.7).sin(),
                        0.001 * (TAU * x[0] / 1.3).cos(),
                        0.001 * (TAU * x[0] / 1.3).sin(),
                    ],
                    phi: 0.0001 * (TAU * x[0] / 1.3).sin(),
                    ..initial(x)
                };
                let mut fast = Simulation::new(mesh, config.clone(), data).unwrap();
                let mut reference = Simulation::new(original, config, data).unwrap();
                for step in 1..=6 {
                    // Reproduce the old preparation path, rebuilding stencils every step.
                    reference.geometry = Arc::new(
                        Geometry::new(reference.state.mesh.clone(), false, false).unwrap(),
                    );
                    let target = step as f64 * 0.0005;
                    fast.advance_to(target).unwrap();
                    reference.advance_to(target).unwrap();
                    for (a, b) in fast
                        .state
                        .conserved
                        .iter()
                        .flatten()
                        .zip(reference.state.conserved.iter().flatten())
                    {
                        assert!(
                            (a - b).abs() < 1e-11,
                            "jitter={jitter} motion={motion:?} step={step} a={a:e} b={b:e} error={:e}",
                            (a - b).abs()
                        );
                    }
                    for (a, b) in fast
                        .state
                        .potential
                        .iter()
                        .flatten()
                        .chain(&fast.state.phi)
                        .zip(
                            reference
                                .state
                                .potential
                                .iter()
                                .flatten()
                                .chain(&reference.state.phi),
                        )
                    {
                        assert!(
                            (a - b).abs() < 1e-11,
                            "jitter={jitter} motion={motion:?} step={step} a={a:e} b={b:e} error={:e}",
                            (a - b).abs()
                        );
                    }
                    for (a, b) in fast
                        .magnetic_fit()
                        .unwrap()
                        .magnetic
                        .iter()
                        .flatten()
                        .zip(reference.magnetic_fit().unwrap().magnetic.iter().flatten())
                    {
                        assert!(
                            (a - b).abs() < 1e-11,
                            "jitter={jitter} motion={motion:?} step={step} a={a:e} b={b:e} error={:e}",
                            (a - b).abs()
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn face_exchanges_cancel_at_both_geometries() {
        let mesh = Mesh::lattice(6, 6, [1.; 2], 0.15).unwrap();
        let mut sim = Simulation::new(
            mesh,
            Config {
                motion: Motion::Fluid,
                ..Config::default()
            },
            |x| Initial {
                density: 1. + 0.01 * (TAU * x[0]).sin(),
                velocity: [0.2 + 0.02 * (TAU * x[1]).cos(), -0.1, 0.3],
                ..initial(x)
            },
        )
        .unwrap();
        let old = sim.prepare(&mut 0).unwrap();
        for k in 0..5 {
            assert!(old.fluid.q.iter().map(|q| q[k]).sum::<f64>().abs() < 1e-12);
        }
        let next = sim.trial(&old, 0.1 * old.bound, &mut 0).unwrap();
        for k in 0..5 {
            let a: f64 = sim.state.conserved.iter().map(|q| q[k]).sum();
            let b: f64 = next.state.conserved.iter().map(|q| q[k]).sum();
            assert!((a - b).abs() < 1e-12);
        }
        sim.advance_to(0.002).unwrap();
        assert!(
            sim.diagnostics()
                .unwrap()
                .normalized_budget
                .iter()
                .all(|x| x.abs() < 1e-12)
        );
    }
}

#[cfg(test)]
mod endpoint_cleaning_test {
    use super::*;
    use std::f64::consts::TAU;
    #[test]
    fn endpoint_uses_phi_star_but_frozen_initial_cleaning_source() {
        let mesh = Mesh::lattice(8, 8, [1.; 2], 0.).unwrap();
        let sim = Simulation::new(mesh, Config::default(), |x| Initial {
            density: 1.,
            pressure: 0.6,
            velocity: [0.; 3],
            potential: [0.; 3],
            phi: 0.001 * (TAU * x[0]).sin(),
        })
        .unwrap();
        let old = sim.prepare(&mut 0).unwrap();
        let dt = 0.001;
        let next = sim.trial(&old, dt, &mut 0).unwrap();
        let damping = 0.15 / radius(1. / 64.); // cs=1
        let keff = (TAU / 8.).sin() * 8.;
        for (i, c) in sim.state.mesh.cells.iter().enumerate() {
            let x = TAU * c.centroid[0];
            let expected_a = dt * (1. - 0.5 * dt * damping) * 0.001 * keff * x.cos();
            let expected_phi = 0.001 * x.sin() * (1. - dt * damping + 0.5 * (dt * damping).powi(2));
            assert!((next.state.potential[i][0] - expected_a).abs() < 1e-14);
            assert!((next.state.phi[i] - expected_phi).abs() < 1e-14);
        }
    }
}

#[cfg(test)]
mod fallback_accounting_test {
    use super::*;
    #[test]
    fn partial_failed_sweep_keeps_successful_hll_counts() {
        let geometry =
            Geometry::new(Mesh::lattice(4, 4, [1.; 2], 0.).unwrap(), false, false).unwrap();
        let n = geometry.mesh.cells.len();
        let first = &geometry.mesh.faces[0];
        let q = Primitive {
            density: 1.,
            pressure: 1e-6,
            velocity: [0.; 3],
            magnetic: [first.normal[0], first.normal[1], 0.],
        };
        let mut primitive = vec![q; n];
        let invalid = (0..n)
            .rev()
            .find(|&i| i != first.left && i != first.right)
            .unwrap();
        primitive[invalid].pressure = -1.;
        let mut attempted = 0;
        let result = fluid_rate(
            (IdealGas::new(1.4).unwrap(), FaceCompletion::RiemannState),
            &geometry,
            (&primitive, &vec![[[0.; 2]; 8]; n]),
            &vec![[0.; 2]; n],
            &vec![[0.; 2]; n],
            0.,
            &mut attempted,
        );
        assert!(result.is_err());
        assert!(
            attempted > 0,
            "first face is the degenerate parallel-field HLL fixture"
        );
    }
}

use std::fmt::Write as _;
fn review_sim(n:usize,parallel:f64,boost:[f64;3],limited:bool)->Simulation{
 let config=Config{profile:Profile::BulkFrameHllProjectedV1,mean_magnetic:[1.,0.,0.],motion:Motion::Rigid([boost[0],boost[1]]),limited,..Config::default()};
 Simulation::new(Mesh::lattice(n,n,[1.;2],0.).unwrap(),config,|p|{let x=std::f64::consts::TAU*p[0];Initial{density:1.,pressure:0.1,velocity:[parallel+boost[0],0.1*x.sin()+boost[1],0.1*x.cos()+boost[2]],potential:[0.,0.1/std::f64::consts::TAU*x.sin(),0.1/std::f64::consts::TAU*x.cos()],phi:0.}}).unwrap()
}
fn review_flat(state:&State)->Vec<f64>{let n=state.mesh.cells.len();let mut x=vec![0.;9*n];for i in 0..n{for k in 0..5{x[k*n+i]=state.conserved[i][k]/state.mesh.cells[i].volume;}for k in 0..3{x[(5+k)*n+i]=state.potential[i][k];}x[8*n+i]=state.phi[i];}x}
fn review_rate(s:&Simulation,p:&Prepared)->Vec<f64>{let n=s.state.mesh.cells.len();let mut x=vec![0.;9*n];for i in 0..n{for k in 0..5{x[k*n+i]=p.fluid.q[i][k]/s.state.mesh.cells[i].volume;}for k in 0..3{x[(5+k)*n+i]=p.potential_rate[i][k];}x[8*n+i]=p.cleaning[i].initial_rate();}x}

fn dir_norm(x:&[f64])->f64{x.iter().map(|v|v*v).sum::<f64>().sqrt()}
fn dir_dot(a:&[f64],b:&[f64])->f64{a.iter().zip(b).map(|(x,y)|x*y).sum()}
fn dir_mat(path:&str)->Vec<Vec<f64>>{std::fs::read_to_string(path).unwrap().lines().map(|r|r.split(',').map(|x|x.parse::<f64>().unwrap()).collect()).collect()}
fn dir_product(m:&[Vec<f64>],x:&[f64])->Vec<f64>{m.iter().map(|r|dir_dot(r,x)).collect()}
fn dir_difference(a:&[f64],b:&[f64],factor:f64)->Vec<f64>{a.iter().zip(b).map(|(x,y)|(x-y)*factor).collect()}
fn dir_physical(s:&Simulation,state:&State)->Vec<[f64;8]>{let g=&s.geometry;let fit=MagneticFit::with_projection(&state.mesh,(&g.neighbours,g.quadratic.as_ref(),g.compact.as_ref(),s.config.profile.consistent(),s.config.profile.matched()),&state.potential,&state.phi,s.config.mean_magnetic,s.config.limited,s.config.profile.projected()).unwrap();recover(IdealGas::new(s.config.gamma).unwrap(),state,&fit).unwrap().iter().map(|q|[q.density,q.pressure,q.velocity[0],q.velocity[1],q.velocity[2],q.magnetic[0],q.magnetic[1],q.magnetic[2]]).collect()}
fn dir_physical_norm(a:&[[f64;8]],b:&[[f64;8]],vol:&[f64])->[f64;4]{let groups=[(0,1),(1,2),(2,5),(5,8)];groups.map(|(start,end)|a.iter().zip(b).zip(vol).map(|((x,y),v)|v*(start..end).map(|k|(x[k]-y[k]).powi(2)).sum::<f64>()).sum::<f64>().sqrt())}
fn evolution_save(out:&str,name:&str,s:&Simulation){let physical=dir_physical(s,&s.state);let mut csv=String::from("id,time,volume,rho,mx,my,mz,energy,ax,ay,az,phi,recovered_rho,p,vx,vy,vz,bx,by,bz\n");for(i,c)in s.state.mesh.cells.iter().enumerate(){let mut v=vec![s.time,c.volume];v.extend(s.state.conserved[i].map(|x|x/c.volume));v.extend(s.state.potential[i]);v.push(s.state.phi[i]);v.extend(physical[i]);writeln!(&mut csv,"{i},{}",v.iter().map(|v|format!("{v:.17e}")).collect::<Vec<_>>().join(",")).unwrap();}std::fs::write(format!("{out}/{name}_t{}.csv",s.time),csv).unwrap();}
fn evolution_norm(base:&Simulation,s:&Simulation)->[f64;6]{let a=dir_physical(base,&base.state);let b=dir_physical(s,&s.state);let mut physical=0.;let mut bn=0.;let mut vn=0.;let mut an=0.;let mut pn=0.;let mut en=0.;for(i,c)in base.state.mesh.cells.iter().enumerate(){let dv=(2..5).map(|k|(a[i][k]-b[i][k]).powi(2)).sum::<f64>();let db=(5..8).map(|k|(a[i][k]-b[i][k]).powi(2)).sum::<f64>();physical+=c.volume*(a[i][0]*dv+db);bn+=c.volume*db;vn+=c.volume*dv;an+=c.volume*(0..3).map(|k|(s.state.potential[i][k]-base.state.potential[i][k]).powi(2)).sum::<f64>();pn+=c.volume*(s.state.phi[i]-base.state.phi[i]).powi(2);en+=c.volume*(s.state.conserved[i][4]/c.volume-base.state.conserved[i][4]/c.volume).powi(2);}[physical,bn,vn,an,pn,en].map(f64::sqrt)}
pub fn audit_evolution(out:&str){let n=8;let nc=n*n;let times=[0.,0.0002,0.01,0.05,0.1,0.25,0.5,1.];let mut summary=String::from("direction,limited,amplitude,sign,time,physical_Bv_norm,B_norm,v_norm,A_norm,phi_norm,energy_density_norm,physical_gain,B_gain,v_gain,A_gain,phi_gain,energy_gain,steps,rejected_cfl,rejected_state,rejected_geometry,dt_min,dt_max,rho_min,p_min,budget_absolute_max\n");
for limited in [true]{let mut original=review_sim(n,1.,[0.;3],limited);original.config.max_dt=0.0002;let mut bases=Vec::new();let mut baseline=original.clone();for t in times{baseline.advance_to(t).unwrap();assert_eq!(baseline.counters.rejected_cfl+baseline.counters.rejected_state+baseline.counters.rejected_geometry,0);evolution_save(out,&format!("base_limited{limited}"),&baseline);bases.push(baseline.clone());}
for name in ["rate_limitedtrue_mode0_real","rate_limitedtrue_mode6_imag"]{let data=dir_mat(&format!("{out}/{name}.csv"));let max=data.iter().map(|r|r[0].abs()).fold(0.,f64::max);let v:Vec<_>=data.iter().map(|r|r[0]/max).collect();for amplitude in [1e-6,1e-8]{for sign in [1.,-1.]{let mut s=original.clone();for i in 0..nc{for k in 0..5{s.state.conserved[i][k]+=sign*amplitude*v[k*nc+i]*s.state.mesh.cells[i].volume;}for k in 0..3{s.state.potential[i][k]+=sign*amplitude*v[(k+5)*nc+i];}s.state.phi[i]+=sign*amplitude*v[8*nc+i];}let initial:[f64;5]=std::array::from_fn(|k|s.state.conserved.iter().map(|q|q[k]).sum());s.initial_totals=initial;let initial_norm=evolution_norm(&bases[0],&s);
for (base,t)in bases.iter().zip(times){s.advance_to(t).unwrap();assert_eq!(s.counters.rejected_cfl+s.counters.rejected_state+s.counters.rejected_geometry,0,"fixed-cap control unexpectedly rejected");let norms=evolution_norm(base,&s);let mut values=norms.to_vec();values.extend((0..6).map(|k|if initial_norm[k]>1e-25{norms[k]/initial_norm[k]}else{0.}));let physical=dir_physical(&s,&s.state);let rho=physical.iter().map(|q|q[0]).fold(f64::INFINITY,f64::min);let pressure=physical.iter().map(|q|q[1]).fold(f64::INFINITY,f64::min);assert!(rho>0.&&pressure>0.);let budget=(0..5).map(|k|(s.state.conserved.iter().map(|q|q[k]).sum::<f64>()-initial[k]).abs()).fold(0.,f64::max);writeln!(&mut summary,"{name},{limited},{amplitude:.17e},{sign},{t:.17e},{},{},{},{},{},{:.17e},{:.17e},{rho:.17e},{pressure:.17e},{budget:.17e}",values.iter().map(|v|format!("{v:.17e}")).collect::<Vec<_>>().join(","),s.counters.steps,s.counters.rejected_cfl,s.counters.rejected_state,s.counters.rejected_geometry,s.counters.min_dt.unwrap_or(0.),s.counters.max_dt).unwrap();evolution_save(out,&format!("evolution_{name}_limited{limited}_e{amplitude}_sign{sign}"),&s);std::fs::write(format!("{out}/evolution.csv"),&summary).unwrap();}
println!("evolution {name} limited{limited} epsilon{amplitude} sign{sign} complete");}}}}
}

}
fn main(){general::audit_evolution("/Users/arm2arm/orca/workspaces/openmhd-rs-/M0/results/review_resume/openmhd_projected_hll_standing_ai");}
