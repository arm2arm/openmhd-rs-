//! Prospective A-face completion invariants, including the archived collapsed fan.
use mhd_core::{
    FaceCompletion, FaceFlux, FluxMethod, IdealGas, Primitive, Vec3, cross, riemann,
    riemann_with_completion,
};

fn solve(l: Primitive, r: Primitive, n: Vec3, w: Vec3) -> FaceFlux {
    riemann_with_completion(
        IdealGas::new(5. / 3.).unwrap(),
        l,
        r,
        n,
        w,
        FaceCompletion::HllAverage,
    )
    .unwrap()
}
fn source(f: FaceFlux, u: Vec3) -> Vec3 {
    let ub = cross(u, f.magnetic);
    std::array::from_fn(|k| f.electromotive[k] - ub[k])
}
fn close(a: Vec3, b: Vec3) {
    for k in 0..3 {
        assert!((a[k] - b[k]).abs() <= 1e-11, "{a:?} != {b:?}");
    }
}
fn state(vx: f64, by: f64, vy: f64) -> Primitive {
    Primitive {
        density: 1.,
        pressure: 1.,
        velocity: [vx, vy, 0.04],
        magnetic: [0., by, -0.004562414995177748],
    }
}
fn rotate(v: Vec3) -> Vec3 {
    // A proper non-axis-aligned rotation, with an out-of-plane component.
    let (s, c) = 0.37_f64.sin_cos();
    [v[2], c * v[0] - s * v[1], s * v[0] + c * v[1]]
}
#[test]
fn completion_is_continuous_covariant_and_preserves_conservative_fluxes() {
    let n = [0., -1., 0.];
    let w = [0.2, -0.1, 0.];
    let aux = [0.21, -0.1, 0.04];
    let boost = [2., -1., 0.8];
    let base = source(
        solve(
            state(0.20168128073437985, 0., -0.1),
            state(0.19831871926562015, 0., -0.1),
            n,
            w,
        ),
        aux,
    );
    for bn in [-1e-8, -1e-14, -1e-18, 0., 1e-18, 1e-14, 1e-8, 0.3] {
        for vn in [-1e-8, -1e-16, 0., 1e-16, 1e-8, 0.2] {
            for contrast in [false, true] {
                let l = state(0.20168128073437985, bn, -0.1 + vn);
                let mut r = state(0.19831871926562015, bn, -0.1 + vn);
                if contrast {
                    r.density = 0.3;
                    r.pressure = 0.7;
                    r.magnetic[0] = 0.2;
                }
                let f = solve(l, r, n, w);
                let s = source(f, aux);
                let old = riemann(IdealGas::new(5. / 3.).unwrap(), l, r, n, w).unwrap();
                assert_eq!(f.fluid, old.fluid);
                assert_eq!(f.induction, old.induction);
                assert_eq!(f.method, old.method);
                assert_eq!(f.max_speed, old.max_speed);
                let reversed = solve(r, l, n.map(|v| -v), w);
                close(s, source(reversed, aux));
                close(f.magnetic, reversed.magnetic);
                for k in 0..5 {
                    assert!((f.fluid[k] + reversed.fluid[k]).abs() < 1e-11);
                }
                let boosted = |mut q: Primitive| {
                    q.velocity = std::array::from_fn(|k| q.velocity[k] + boost[k]);
                    q
                };
                close(
                    s,
                    source(
                        solve(
                            boosted(l),
                            boosted(r),
                            n,
                            std::array::from_fn(|k| w[k] + boost[k]),
                        ),
                        std::array::from_fn(|k| aux[k] + boost[k]),
                    ),
                );
                let rotated = |mut q: Primitive| {
                    q.velocity = rotate(q.velocity);
                    q.magnetic = rotate(q.magnetic);
                    q
                };
                close(
                    rotate(s),
                    source(
                        solve(rotated(l), rotated(r), rotate(n), rotate(w)),
                        rotate(aux),
                    ),
                );
                let mut ulp = l;
                ulp.velocity[1] = f64::from_bits(ulp.velocity[1].to_bits() + 1);
                ulp.magnetic[1] = f64::from_bits(ulp.magnetic[1].to_bits() + 1);
                close(s, source(solve(ulp, r, n, w), aux));
                if !contrast && bn.abs() <= 1e-14 && vn.abs() <= 1e-16 {
                    close(s, base);
                }
            }
        }
    }
}

#[test]
fn uniform_upwind_rotational_and_fallback_controls() {
    let n = [1., 0., 0.];
    let w = [0.2, -0.1, 0.3];
    for (v, b, p) in [
        ([0.2, -0.1, 0.3], [1., 0., 0.], 1e-6),
        ([4., 0.2, 0.1], [0.3, 0.2, 0.1], 1.),
        ([-4., 0.2, 0.1], [0.3, 0.2, 0.1], 1.),
        ([0.2, 0.3, -0.1], [0.3, 0.2, 0.1], 1.),
    ] {
        let q = Primitive {
            density: 1.,
            pressure: p,
            velocity: v,
            magnetic: b,
        };
        let f = solve(q, q, n, w);
        close(f.magnetic, b);
        close(f.electromotive, cross(v, b));
        close(source(f, v), [0.; 3]);
        if p == 1e-6 {
            assert_eq!(f.method, FluxMethod::HllFallback);
        }
    }
    // Finite normal field rotational discontinuity: numerical tangential EMF
    // is retained, even though the HLL completion is a different state.
    let l = Primitive {
        density: 1.,
        pressure: 0.1,
        velocity: [0., 0.1, 0.],
        magnetic: [1., 0.1, 0.],
    };
    let r = Primitive {
        velocity: [0., 0., 0.1],
        magnetic: [1., 0., 0.1],
        ..l
    };
    let old = riemann(IdealGas::new(5. / 3.).unwrap(), l, r, n, [0.; 3]).unwrap();
    let new = solve(l, r, n, [0.; 3]);
    assert_eq!(new.fluid, old.fluid);
    assert_eq!(new.induction, old.induction);
    for k in 1..3 {
        assert_eq!(new.electromotive[k], old.electromotive[k]);
    }
}
