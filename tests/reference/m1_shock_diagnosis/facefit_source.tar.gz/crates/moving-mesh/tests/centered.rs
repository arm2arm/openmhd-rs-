use moving_mesh::{Derivatives, Mesh};
use std::f64::consts::TAU;

#[test]
fn centered_fit_reproduces_affine_fields_and_annihilates_constants() {
    for (nx, ny, lengths) in [(12, 12, [1., 1.]), (64, 4, [2., 0.125])] {
        let mesh = Mesh::lattice(nx, ny, lengths, 0.15).unwrap();
        let stencil = Derivatives::build_centered(&mesh).unwrap();
        let values: Vec<_> = mesh
            .cells
            .iter()
            .map(|c| 0.7 + 2. * c.centroid[0] - 3. * c.centroid[1])
            .collect();
        let g = stencil.gradient(&values).unwrap();
        for (i, c) in mesh.cells.iter().enumerate() {
            if c.centroid
                .iter()
                .zip(lengths)
                .all(|(&x, l)| x > 0.3 * l && x < 0.7 * l)
            {
                assert!((g[i][0] - 2.).abs() < 1e-10 && (g[i][1] + 3.).abs() < 1e-10);
            }
        }
        assert!(
            stencil
                .gradient(&vec![7.; mesh.cells.len()])
                .unwrap()
                .iter()
                .all(|g| *g == [0.; 2])
        );
    }
}

#[test]
fn centered_periodic_gradient_converges_on_both_mesh_families() {
    for jitter in [0., 0.15] {
        let mut errors = Vec::new();
        for n in [8, 16, 32] {
            let mesh = Mesh::lattice(n, n, [1.; 2], jitter).unwrap();
            let values: Vec<_> = mesh
                .cells
                .iter()
                .map(|c| (TAU * c.centroid[0]).sin() * (TAU * c.centroid[1]).sin())
                .collect();
            let gradient = Derivatives::build_centered(&mesh)
                .unwrap()
                .gradient(&values)
                .unwrap();
            errors.push(
                mesh.cells
                    .iter()
                    .zip(gradient)
                    .map(|(c, g)| {
                        let [x, y] = c.centroid.map(|x| TAU * x);
                        c.volume
                            * (g[0] - TAU * x.cos() * y.sin()).hypot(g[1] - TAU * x.sin() * y.cos())
                    })
                    .sum::<f64>(),
            );
        }
        for pair in errors.windows(2) {
            assert!(
                (pair[0] / pair[1]).log2() > if jitter == 0. { 1.8 } else { 0.7 },
                "{jitter}: {errors:?}"
            );
        }
    }
}
