# Jittered-shock closure investigation

The registered spline physics study failed all six jittered Brio evolutions.
The unchanged M0 thresholds, historical profiles and raw failures are retained.
No pressure floor, entropy switch, energy reset or explicit resistivity is
authorized as a substitute for passing that conservative packet.

## Observations before a numerical change

The nx256, ny4, jitter=.15 case stops near t=.00343 in cell 253, adjacent to
the periodic seam, although the requested final time is .1. All five existing
profiles fail. Reducing the spline timestep cap to 1e-5 and 1e-6 yields failure
times .00343412 and .00343445. This is not resolved by timestep refinement.

An observational energy-rate diagnostic evaluates, on fixed/rigid geometry,
`dK=v dot d(momentum)-|v|² d(rho)/2`, `dM=B dot curl(dA)`, and
`dp=(gamma-1)*(dE-dK-dM)`. For comparison it also computes `B dot dB_FV`
from the same oriented Riemann induction fluxes, without evolving that field.
At initialization in cell 253, dE=-42.28159, dM=-7.40085 and dK=0,
so dp=-34.88074. The independent finite-volume magnetic rate is -39.76889.
Thermal energy subsequently approaches zero. Tracing leaves every physical
snapshot, history, summary and timestep identical to the frozen baseline.
This demonstrates a discrete fluid/curl energy mismatch in that cell; it is
not a proof that the gradient stencil alone causes all instabilities.

## Prospective reconstruction comparator

Test `bulk-frame-heun-centered-v1` separately. Retain the spline auxiliary
projection, Heun stages, fluxes, primitive gradients, limiter, budgets and
failure policy. Change only the A/phi derivative fit used for the raw curl,
potential extrapolation, div(A) and grad(phi): minimize the face-area-weighted
residuals `A_j-A_i-G dot (c_j-c_i)` with the intercept anchored to the target
cell. Use the same scaled conditioning rejection. Cache the stencil on the
fixed/rigid geometry. The paper profile remains its prescribed free-intercept,
target-excluding fit. The new comparator is an engineering amendment, not a
correction attributed to the paper.

Before larger runs: verify affine reproduction, constant annihilation,
periodic manufactured convergence, observer passivity, analytic energy-rate
identities and temporal finite differences; reproduce the failing short
shock with baseline and comparator, plus regular and joint-boost controls.
If the short case improves, run the registered shock ladder on REANA and
report all existing profile/state/diagnostic/boost gates. A stable evolution
alone does not resolve the strict Bx diagnostic or the full M1 wave gates.
Reject an unsuccessful comparator rather than changing acceptance thresholds.
