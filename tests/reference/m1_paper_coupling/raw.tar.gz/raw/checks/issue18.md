Checkpoint published on the development branch; main is unchanged.

- [4c5341a](https://github.com/arm2arm/openmhd-rs-/commit/4c5341a): Riemann completion experiments and tests.
- [76470eb](https://github.com/arm2arm/openmhd-rs-/commit/76470eb): mesh derivatives and deterministic threading.
- [b5bea83](https://github.com/arm2arm/openmhd-rs-/commit/b5bea83): M1 solver profiles, diagnostics and tests.
- [5175240](https://github.com/arm2arm/openmhd-rs-/commit/5175240): bounded validation, measurement and REANA tooling.
- [e17cf9b](https://github.com/arm2arm/openmhd-rs-/commit/e17cf9b): retained/rejected source archives, numeric evidence, plots and resumed handoff.

The [paper audit evidence](https://github.com/arm2arm/openmhd-rs-/tree/e17cf9b337d2dd3a4c9228d0cbe45e85df34ec4e/tests/reference/m1_paper_audit) is now published with the exact hashes in the reports. All 126 files referenced by study archive manifests verify. A credential-pattern scan of 3,726 plain/compressed members found no matches. Numerical source matches the last tested retained archive; only the handoff text differs.

Fresh verification: 127 release Rust tests across all targets, 41 Python tests, 13 M0 checks, formatting, strict all-target/all-feature Clippy and pinned-reference integrity pass. The working tree was clean at the checkpoint; new diagnostic work under #19/#20 begins after it. Historical failed numerical gates remain failures.

The user resumed local development on 2026-11-09. All four long REANA workflows remain stopped. Closing only this checkpoint task; #7 and numerical blockers #19–#22 remain open.
