//! Experimental shared-vertex Az interpolation, separate from the raw cell curl.
use moving_mesh::{Mesh, Vec2, dot};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug)]
pub(crate) struct FaceNormal {
    endpoints: Vec<[usize; 2]>,
    weights: Vec<Vec<(usize, f64)>>,
}

fn root(parent: &[usize], mut i: usize) -> usize {
    while parent[i] != i {
        i = parent[i];
    }
    i
}

fn endpoint(mesh: &Mesh, f: usize, end: usize) -> Vec2 {
    let f = &mesh.faces[f];
    let distance = if end == 0 { -0.5 } else { 0.5 } * f.area;
    [
        f.centroid[0] - distance * f.normal[1],
        f.centroid[1] + distance * f.normal[0],
    ]
}

fn periodic_delta(a: Vec2, b: Vec2, lengths: Vec2) -> Vec2 {
    std::array::from_fn(|k| {
        let d = a[k] - b[k];
        d - lengths[k] * (d / lengths[k]).round()
    })
}

// Minimize sum_i (a_i - intercept - gradient dot d_i)^2. The returned
// intercept weights reproduce constants and affine data at d=0.
fn intercept_weights(offsets: &[Vec2]) -> Result<Vec<f64>, String> {
    if offsets.len() < 3 {
        return Err("vertex needs at least three incident cell centres".into());
    }
    let count = offsets.len() as f64;
    let scale = offsets
        .iter()
        .map(|d| dot(*d, *d))
        .fold(0., f64::max)
        .sqrt();
    if !scale.is_finite() || scale <= 0. {
        return Err("invalid vertex interpolation scale".into());
    }
    let d: Vec<_> = offsets.iter().map(|d| d.map(|x| x / scale)).collect();
    let mean: Vec2 = std::array::from_fn(|k| d.iter().map(|d| d[k]).sum::<f64>() / count);
    let centered: Vec<Vec2> = d.iter().map(|d| [d[0] - mean[0], d[1] - mean[1]]).collect();
    let xx = centered.iter().map(|d| d[0] * d[0]).sum::<f64>() / count;
    let xy = centered.iter().map(|d| d[0] * d[1]).sum::<f64>() / count;
    let yy = centered.iter().map(|d| d[1] * d[1]).sum::<f64>() / count;
    let det = xx * yy - xy * xy;
    if !det.is_finite() || det <= 1e-10 * (xx + yy).powi(2) {
        return Err("ill-conditioned vertex interpolation".into());
    }
    let weights: Vec<_> = centered
        .iter()
        .map(|d| {
            (1. - (mean[0] * (yy * d[0] - xy * d[1]) + mean[1] * (xx * d[1] - xy * d[0])) / det)
                / count
        })
        .collect();
    if !weights.iter().all(|w| w.is_finite()) {
        return Err("nonfinite vertex interpolation".into());
    }
    Ok(weights)
}

impl FaceNormal {
    pub(crate) fn build(mesh: &Mesh) -> Result<Self, String> {
        let mut parent: Vec<_> = (0..2 * mesh.faces.len()).collect();
        let tolerance = 1e-9 * mesh.lengths[0].max(mesh.lengths[1]);
        for (i, cell) in mesh.cells.iter().enumerate() {
            let mut faces = cell.faces.clone();
            faces.sort_by(|&(a, _), &(b, _)| {
                let a = mesh.displacement(&mesh.faces[a], i);
                let b = mesh.displacement(&mesh.faces[b], i);
                a[1].atan2(a[0]).total_cmp(&b[1].atan2(b[0]))
            });
            for k in 0..faces.len() {
                let (a, sa) = faces[k];
                let (b, sb) = faces[(k + 1) % faces.len()];
                let ea = usize::from(sa > 0.);
                let eb = usize::from(sb < 0.);
                let d = periodic_delta(endpoint(mesh, a, ea), endpoint(mesh, b, eb), mesh.lengths);
                if d[0].hypot(d[1]) > tolerance {
                    return Err(format!("disconnected vertex in cell {i}: {d:?}"));
                }
                let ra = root(&parent, 2 * a + ea);
                let rb = root(&parent, 2 * b + eb);
                parent[ra.max(rb)] = ra.min(rb);
            }
        }
        let mut incidents: BTreeMap<usize, BTreeSet<usize>> = BTreeMap::new();
        for (f, face) in mesh.faces.iter().enumerate() {
            for end in 0..2 {
                incidents
                    .entry(root(&parent, 2 * f + end))
                    .or_default()
                    .extend([face.left, face.right]);
            }
        }
        let ids: BTreeMap<_, _> = incidents.keys().enumerate().map(|(i, &r)| (r, i)).collect();
        let endpoints = (0..mesh.faces.len())
            .map(|f| std::array::from_fn(|e| ids[&root(&parent, 2 * f + e)]))
            .collect();
        let weights = incidents
            .iter()
            .map(|(&r, cells)| {
                let vertex = endpoint(mesh, r / 2, r % 2);
                let offsets: Vec<_> = cells
                    .iter()
                    .map(|&i| periodic_delta(mesh.cells[i].centroid, vertex, mesh.lengths))
                    .collect();
                Ok(cells
                    .iter()
                    .copied()
                    .zip(intercept_weights(&offsets)?)
                    .collect())
            })
            .collect::<Result<_, String>>()?;
        Ok(Self { endpoints, weights })
    }

    pub(crate) fn normals(&self, mesh: &Mesh, az: &[f64], mean: Vec2) -> Result<Vec<f64>, String> {
        if az.len() != mesh.cells.len() || !az.iter().chain(&mean).all(|a| a.is_finite()) {
            return Err("invalid vertex potential data".into());
        }
        let vertices: Vec<_> = self
            .weights
            .iter()
            .map(|samples| {
                let base = az[samples[0].0];
                base + samples
                    .iter()
                    .map(|&(i, w)| w * (az[i] - base))
                    .sum::<f64>()
            })
            .collect();
        let result: Vec<_> = self
            .endpoints
            .iter()
            .zip(&mesh.faces)
            .map(|(v, f)| dot(mean, f.normal) + (vertices[v[1]] - vertices[v[0]]) / f.area)
            .collect();
        if !result.iter().all(|b| b.is_finite()) {
            return Err("nonfinite face-normal field".into());
        }
        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::TAU;

    #[test]
    fn vertex_intercept_reproduces_affine_data_and_rejects_singular_geometry() {
        let d = [[-0.7, -0.1], [0.2, -0.3], [0.4, 0.8], [-0.3, 0.5]];
        let w = intercept_weights(&d).unwrap();
        let value: f64 = w
            .iter()
            .zip(d)
            .map(|(w, d)| w * (2. + 3. * d[0] - 4. * d[1]))
            .sum();
        assert!((value - 2.).abs() < 1e-14);
        assert!(intercept_weights(&[[0., 0.], [1., 0.], [2., 0.]]).is_err());
    }

    #[test]
    fn shared_vertex_flux_telescopes_on_regular_jittered_and_thin_periodic_meshes() {
        for (nx, ny, lengths, jitter) in [
            (8, 8, [1.; 2], 0.),
            (8, 8, [1.; 2], 0.15),
            (256, 4, [2., 0.125], 0.15),
        ] {
            let mesh = Mesh::lattice(nx, ny, lengths, jitter).unwrap();
            let stencil = FaceNormal::build(&mesh).unwrap();
            let az: Vec<_> = (0..mesh.cells.len())
                .map(|i| (i as f64 * 1.37).sin())
                .collect();
            let b = stencil.normals(&mesh, &az, [0.75, 0.3]).unwrap();
            for cell in &mesh.cells {
                let sum: f64 = cell
                    .faces
                    .iter()
                    .map(|&(f, s)| s * mesh.faces[f].area * b[f])
                    .sum();
                assert!(sum.abs() < 2e-12, "{sum}");
            }
            let uniform = stencil
                .normals(&mesh, &vec![0.4; az.len()], [0.75, 0.3])
                .unwrap();
            for (b, f) in uniform.iter().zip(&mesh.faces) {
                assert!((b - dot([0.75, 0.3], f.normal)).abs() < 1e-14);
            }
        }
    }

    #[test]
    fn smooth_face_normal_field_converges() {
        let mut errors = Vec::new();
        for n in [8, 16, 32] {
            let mesh = Mesh::lattice(n, n, [1.; 2], 0.15).unwrap();
            let a = |x: Vec2| (TAU * x[0]).sin() * (TAU * x[1]).cos();
            let az: Vec<_> = mesh.cells.iter().map(|c| a(c.centroid)).collect();
            let stencil = FaceNormal::build(&mesh).unwrap();
            let b = stencil.normals(&mesh, &az, [0.; 2]).unwrap();
            let mut error = 0.;
            let mut length = 0.;
            for (f, face) in mesh.faces.iter().enumerate() {
                let exact = (a(endpoint(&mesh, f, 1)) - a(endpoint(&mesh, f, 0))) / face.area;
                error += face.area * (b[f] - exact).abs();
                length += face.area;
            }
            errors.push(error / length);
        }
        for pair in errors.windows(2) {
            assert!(pair[0] / pair[1] > 1.4, "{errors:?}");
        }
    }
}
