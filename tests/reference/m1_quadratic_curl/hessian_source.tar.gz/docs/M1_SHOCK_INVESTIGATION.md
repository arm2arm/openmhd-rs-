# Jittered-shock closure investigation

## Current development loop: short tests first

At the user's request on 2026-11-08, all four long original/candidate/spline/
physics workflows are stopped. Preserve their partial records and raw remote
workspaces. Hold new long submissions during this development phase.

Use the bounded four-case runner for each proposed fix:

```sh
python3 scripts/run_shock_repro.py --output-dir results/shock_short_fresh
```

It runs nx256 x ny4 to t=.01 on regular/jittered meshes, each base and jointly
boosted. The default cap is 30 wall seconds per case, at most four serial
workers. Timeouts and aborted evolutions fail the screen. It saves exact
source/binary hashes, a source archive, commands, timings, snapshots, logs,
positivity/budget checks, the unchanged short-time Brio diagnostics and boost
comparisons. Add `--trace-energy` only when an accepted-step energy trace is
needed; `--dt` supports a separate smaller-step check. A fresh directory is
required each time.

The first four-case screen took **0.87 wall seconds** after a cached build:
both regular cases completed; both jittered cases reproduced the t=.0034298
failure. This is an expected failed screen, not a successful stability test.
Source and measurements are under `results/shock_short_screen_20261108/`.
Small algebra/unit checks and this reproduction form the immediate iteration
loop. Candidates that fail it do not justify another full matrix.

A passing short screen is only the first development check. Medium-duration
shock/refinement controls and the original full-time M1 matrix are still
required before acceptance or merging. The short runner never submits jobs
or marks full M1 acceptance. Report a passing candidate before considering
resumption of longer validation.

The registered spline physics study failed all six jittered Brio evolutions.
The unchanged M0 thresholds, historical profiles and raw failures are retained.
No pressure floor, entropy switch, energy reset or explicit resistivity is
authorized as a substitute for passing that conservative packet.

## Observations before a numerical change

### Prospective quadratic-curl trial

Test `bulk-frame-heun-quadratic-v1` as a separate engineering comparator.
Retain spline/Heun, the projected comoving induction-rate coupling, conservative
fluid exchanges, initial analytic A samples and all acceptance thresholds.
Replace only the A/phi derivative stencil by a free-intercept quadratic fit
over distinct first/second-neighbour periodic images (excluding the central
image). Use inverse Euclidean distance weights, isotropic coordinate scaling
by sqrt(cell volume), column normalization and twice-orthogonalized QR. Reject
rank-deficient or badly conditioned fits rather than silently falling back.
Take the linear coefficients as the raw curl/cleaning/advection derivatives;
use the identical new curl and its transpose in the rate projection. Fluid
primitive gradients and independent divergence diagnostics retain their
existing operators. This is not the complete concurrent-Hessian method of
paper Eq. (62): it isolates the effect of the higher-order A derivative.

First require constant/affine/quadratic reproduction, periodic-image controls,
smooth x-only and genuinely two-dimensional convergence. Measure initial
Brio/smooth errors on the existing nx256/512/1024, ny4 ladder without claiming
isotropic convergence. Then run the existing uniform/boost/permutation/time
controls and the four-case t=.01 screen, with the same wall limits. Preserve
the exact source and every failure. No full matrix, energy reset, pressure
floor, directional field overwrite or threshold change is part of this trial.
Retain a solver candidate only if its bounded results justify further work.

The first quadratic screen completes all four cases but retains a jittered
Bx error .0566374. Before choosing a disposition, test a second separately
named `bulk-frame-heun-hessian-v1` variant: obtain the magnetic face slopes
from the symmetric Hessians of the same quadratic A fit, using
`grad(Bx)=(Az_xy,Az_yy)`, `grad(By)=(-Az_xx,-Az_xy)` and
`grad(Bz)=(Ay_xx-Ax_xy,Ay_xy-Ax_yy)`. Apply the existing component limiter
to these slopes. The raw trace cancels algebraically; independently measured
divergence operators and all acceptance gates remain unchanged. All other
quadratic/projected choices are identical. Require quadratic Hessian
reproduction and the same bounded evolution controls before the four-case
screen. This tests spatial reconstruction consistency, not a claim that
zero trace alone repairs the shock.

### Prospective initial Bx reconstruction audit

The projected candidate's remaining Bx error exists at initialization. Audit
the existing raw free-intercept neighbour curl before changing it. At fixed
nx256/512/1024, ny4 on regular and jitter=.15 meshes, evaluate the registered
piecewise-linear Brio Az and a smooth periodic one-dimensional Az control.
For every cell, record the derivatives, stencil condition, whether neighbour
samples cross a Brio slope discontinuity, and the Bx-error decomposition
`Dy Az = sum_j D_yj [Az_j - Az_i - gx_exact_i*(x_j-x_i)]`, retaining the
implementation's first-sample baseline subtraction. This checks whether the
transverse derivative is generated by non-affine stencil data.

Independently solve the weighted free-intercept affine fit in high-precision
Decimal arithmetic for the worst Brio Bx cell in each family, using exported
centroid offsets, face weights and potential samples. Check affine/constant
controls and the explicit coefficient formula against production derivatives.
Do not evolve states, alter initialization, replace curl components by known
answers or change the Bx gate. These are bounded reconstruction diagnostics,
not a new candidate or a claim that the full-time gate is impossible.

Measured result: all 12 initial reconstructions complete in **2.29 seconds**.
The independent 70-digit normal-equation fits agree with production gradients
to a worst absolute difference of **2.23e-16**. Constant
derivatives vanish, affine controls agree within 3.56e-15, and the nonlinear
residual decomposition reproduces the transverse gradient within 3.89e-16.

| nx, ny=4 | Initial jittered Brio max Bx error | Initial smooth 1D max Bx error | Brio mixed stencils |
| --- | ---: | ---: | ---: |
| 256 | .160355 | .00484205 | 29 |
| 512 | .149907 | .00246816 | 39 |
| 1024 | .284451 | .00231862 | 49 |

For Brio, stencils whose neighbour values stay on one affine branch have
Bx error <=3.34e-16; the large errors occur where the fitted samples span a
slope change. Regular-mesh maximum Bx error is <=1.39e-17 across these probes.
The smooth control also develops a spurious transverse derivative on jittered
meshes, so an interface-specific correction would not establish general 1D
preservation. This diagnoses a limitation of the chosen affine reconstruction,
not roundoff or a mismatch between its formula and this Rust implementation.
It does not establish that the entire solver is free of programming errors.

No evolution algorithm, initial data, mesh or acceptance threshold changed.
The projected profile remains the partial short-time stability improvement;
the Bx gate and full M1 acceptance remain open. Exact source, every initial
cell, worst-cell fit samples and independent checks are in the
[initial curl audit archive](../tests/reference/m1_curl_audit/README.md).
Reproduce with:

```sh
mkdir results/fresh_curl_audit
cargo run --release --locked -p mhd-vector-pot --example shock-curl-audit -- results/fresh_curl_audit/cells > results/fresh_curl_audit/summary.csv
python3 scripts/check_shock_curl_audit.py results/fresh_curl_audit
```

The example requires its `cells` directory not to exist yet. No remote jobs
are submitted. Format, strict Clippy, all 118 Rust tests (release/all targets),
41 Python tests, 13 M0 algebra checks and pinned-reference checks pass. SHA-256
comparison confirms all production source files and the packet are unchanged
from the retained projected-rate candidate.

### Root-cause interpretation: two separate errors

The pressure failure and the initial Bx error have different local examples.
Cell 640 has the largest initial Bx error at nx256; cell 253 is the cell that
first loses pressure and initially has the correct B. Neither observation
alone establishes that all other implementation details are correct.

For the reconstruction, the implemented fit minimizes
`sum_j area_j * (Az_j - a - gx*dx_j - gy*dy_j)^2` over the neighbours.
With weighted centred moments `Sxx,Sxy,Syy` of the offsets and cross moments
`Tx,Ty` with Az, its transverse slope is

```text
gy = (Sxx*Ty - Sxy*Tx) / (Sxx*Syy - Sxy*Sxy).
```

If Az is affine in x, the numerator cancels. For a kink or curved x-only
function on scattered samples, the unmodelled x variation can correlate with
y. Minimizing this objective can then prefer a nonzero gy. A minimal exact
example samples `Az=abs(x)` at `(-1,0)`, `(1,0)` and `(0.5,1)`. The unique
plane through the three values is `Az_fit=1-0.5*y`: it invents a transverse
slope despite every input being a sample of an x-only function. This is an
analytical counterexample, not a replacement mesh or solver experiment.

For the actual cell 640, `(x,y)=(1.003813608,0.070116266)`, the independent
fit gives `(a,gx,gy)=(-.9894218013,.1142891742,-.1603550179)`. The centred
2x2 covariance has spectral condition number **1.463785**, so this particular
error does not require an ill-conditioned matrix. Allowing the false gy
reduces the weighted squared fitting residual by **49.25%** relative to the
best plane constrained to gy=0. This constrained fit is an explanatory
comparison only; it is not used by the solver.

Subtract the exact local right-branch affine field from each neighbour value.
The remaining kink residuals, multiplied by the existing y-derivative
coefficients, give the following decomposition:

| Neighbour | Kink residual in Az | Contribution to Dy Az |
| --- | ---: | ---: |
| 382 | .022185746 | -.277299585 |
| 385 | 0 | 0 |
| 638 | .022284247 | -.052058226 |
| 639 | .008409950 | +.169002793 |
| 641 | 0 | 0 |
| Sum | | **-.160355018** |

Hence Bx is `.75-.160355018=.589644982`, a 21.38% error in that component.
Both this sum and the implementation's first-sample baseline subtraction
agree with the independent fit within 1e-12. The problem is approximation
of nonlinear samples by a plane, not a failure to minimize the stated fit.
More generally, a fixed linear derivative on a stencil with distinct x
coordinates cannot annihilate *every* x-only function while differentiating
y exactly: an interpolating polynomial in x can take the same values as y
at those finitely many points. Stronger accuracy or symmetry claims therefore
need a specified function class, geometric structure or additional information.
This observation does not prove that the final-time Brio gate is impossible.

For the pressure failure, with gamma=2 and mu0=1,
`p=E-K-M`, `M=|B|^2/2`. Cell 253 starts with thermal energy .1, magnetic
energy .78125 and zero kinetic energy. Its initial rates are
`dE=-42.281594`, `dK=0`, and `dM=-7.400853`, giving `dp=-34.880741`.
Using the induction flux from the very same Riemann faces gives a comparison
magnetic-energy rate `-39.768890`, and thus a pressure-rate comparison
`-2.512704`. This comparison is not an accepted alternative solution, nor is
a negative instantaneous pressure derivative itself unphysical. The actual
trajectory exhausts the thermal energy at t≈.00343, and timestep refinement
does not remove it. The demonstrated failure mechanism is that total energy
leaves the cell faster than the curl-based magnetic energy and kinetic energy
can account for, with the thermal remainder absorbing the difference.
Global conservation of total energy does not ensure positive local pressure.

The initial compatibility probe makes this spatial mismatch explicit: on the
jittered nx256 mesh, even the converged least-squares projection of the FV
induction rate onto the existing curl range leaves a **.4718 relative weighted
L2 magnetic-rate residual**. This is not a 47% energy error. The regular-mesh
projection reaches roundoff. This explains why a better time integrator or
more CPU cores cannot by itself make these spatial operators compatible.
The projected-rate candidate reduces the mismatch enough to complete the
short shock, but has neither passed the Bx gate nor established long-time
stability or profile accuracy.

The registered nx256/512/1024 ladder keeps ny=4. Nominal generator spacing
ratios `dy/dx` are 4, 8 and 16; this is not isotropic refinement of the
jittered geometry. These ratios are not measurements of individual Voronoi
cell aspect ratios. The nonmonotone maximum Bx error cannot establish a
multidimensional convergence rate. A separate isotropic reconstruction study
would help characterize this limitation, without replacing the registered
gate or authorizing another long evolution.

Source cross-check: [paper §4.2.1, Eqs. (51)–(61)](https://arxiv.org/html/2609.35989v1#S4.SS2.SSS1)
specifies neighbour-only, free-intercept, face-area-weighted fits and an
unlimited curl. That matches the audited choice. Section 6.2 reports constant
Bx for its stationary shock setup but does not establish the same result for
our jitter family. Section 4.7 describes an optional low-beta entropy closure
that resets energy and records the conservation error. We have not established
that it was used for the published Brio result; it is outside our current
conservative packet. This audit diagnoses our discrete implementation and
validation assumptions, not a failure of the continuum ideal-MHD equations
or proof that the paper's implementation shares this failure.

![Actual stencil contributions and the separate pressure-failure cell](images/m1_completion/shock_error_mechanism.png)

The new explanatory figure uses only archived measurements. Reproduce it with
Matplotlib installed:

```sh
python3 scripts/plot_shock_mechanism.py results/shock_curl_audit_20261108 results/shock_diagnosis_20261108/traced/energy_trace.csv --output docs/images/m1_completion/shock_error_mechanism.png --report results/shock_deep_dive_20261108/mechanism.json
```

The report records the input/script SHA-256 hashes, covariance, fit residuals,
all five contributions and the initial/final failing-cell data. Executed
checks verify the covariance formula, both contribution sums and the full
gamma=2 pressure-rate trace identity. No production code, initial state,
acceptance threshold or numerical evolution changed for this explanation.

### Prospective compatibility probe

Before adding another evolution profile, test whether the initial finite-volume
induction rate can be represented by the existing raw neighbour curl. On the
fixed Brio meshes, v=u=0 and phi=0 initially, so the baseline Az rate is exactly
the face-area average of the numerical EMF. Assemble that rate and the
conservative induction rate from the same reconstructed Riemann problems;
check agreement with `Simulation::energy_rates()` before interpreting results.

For the planar rate operator `C a = (Dy a, -Dx a)`, minimize the volume-weighted
residual `sum_i V_i |C(a_dot_baseline + delta)_i - B_dot_FV_i|²` by solving
the normal equations with conjugate gradients, starting delta=0. Report
convergence/residuals and the implied initial pressure rate; do not evolve,
overwrite B or adjust energy. Test the true transpose against the exact
implemented constant-baseline derivative, including its target subtraction,
and recover a known compatible manufactured rate up to curl accuracy. Compare
regular/jittered nx64/128/256 controls. A reduced initial mismatch alone is not
a stability result, a fix, a new physical gate, or permission for long runs.

The six initial-state probes complete in .73 seconds. At nx256 the regular
rate residual falls from .5714 to 6.59e-14, but the jittered residual only
falls from .8007 to .4718. The independently recomputed normal-equation
relative residual is 9.54e-12; operator assembly agrees with the production
energy diagnostic to 1.53e-15. Thus the remaining residual is not an unfinished
iterative solve. In cell 253 the projected initial pressure rate improves
from -34.8807 to -15.0369; it remains negative.

### Prospective projected-rate evolution trial

Test `bulk-frame-heun-projected-v1`, retaining the spline Heun algorithm and
all gas fluxes, stored energies, raw curl, diagnostic operators and thresholds.
After forming the baseline A rate at each stage, add a correction minimizing
`sum_i V_i |curl(A_dot + delta)_i - target_i|²`. Use the full planar 3-component
curl and its exact weighted transpose. The target is the oriented divergence
of the Riemann induction flux in the rigid mesh frame: add `Bn*w` to the
existing ALE induction flux before summation. This explicit engineering
choice removes the boost-dependent `w*div_face(B)` term in the target when
the face sum is nonzero. It is not a Powell source in the fluid equations,
an overwrite of B, or a total-energy reset. The default method is unchanged.

The 3-component boost control caught an incomplete frame definition in the
first draft (w_z=0): density agreement failed at the unchanged 1e-10 tolerance.
For the 2.5D target use `w=(mesh_wx,mesh_wy,Vref_z)`, with the same fixed initial
mass-weighted reference velocity as the bulk-frame gauge. The z component
adds no positional motion; it removes the out-of-plane boost times the
discrete normal-field divergence. Preserve the first draft and failure record.

Use diagonal-preconditioned conjugate gradients with relative normal residual
1e-11, independently checked at 1e-9 and capped at 8 times the scalar unknown
count. Never silently accept a failed solve. Validate transpose, manufactured
compatible/incompatible targets and bounded uniform/boost/permutation/time
controls before the four-case short shock screen, capped at 30 seconds per
case. Reject if it cannot complete this screen; do not launch long runs.

Measured disposition: the corrected projected-rate candidate completes all
four t=.01 shock cases in **2.62 wall seconds**, compared with baseline
jittered failure at t=.0034298. Both jittered cases take 82 accepted steps,
zero state rejections and end with minimum p=.0675525. Both boost pairs pass
(largest reported relative L1 difference 6.80e-15); every periodic fluid budget
residual is below 1.77e-15. The two operator checks and four Heun controls pass.

This is a retained experimental **stability improvement**, not a passed short
screen: the jittered final Bx maximum error is **.112966**, above the unchanged
1e-8 gate (initial error .160355). The existing raw curl and initial state are
unchanged. The actual screen exits 1 with `short_screen_passed=false` and
`full_m1_accepted=false`. No medium/full runs, waveform/reference agreement,
or convergence acceptance is inferred. The projection is global and has no
new proven positivity/CFL bound. Long jobs remain stopped and M1 unmerged.

Reproduce the initial-state probe and retained candidate separately:

```sh
cargo run --release --locked -p mhd-vector-pot --example shock-compatibility -- results/fresh_compatibility
python3 scripts/run_shock_repro.py --profile bulk-frame-heun-projected-v1 --output-dir results/fresh_projected
```

The second command is expected to report a failed overall screen because of
Bx, despite successful evolution. Exact sources, all six initial-state
probes, all four shock evolutions and the first draft's boost-test failure are
preserved in the [projected-rate archive](../tests/reference/m1_projected_rate/README.md).

Final verification: formatting, strict Clippy, all 117 Rust tests across all
targets, 38 Python tests, the 13 M0 algebra checks and reference-hash checks
pass. A bounded one-step 1/4/24-thread comparison is bit-identical. All ten
historical profile/wave/loop cases retain byte-identical physical snapshots,
histories and summaries against the frozen pre-experiment binary outputs.

![Initial compatibility and positive short-shock pressure](images/m1_completion/shock_projected_rate.png)

The nx256, ny4, jitter=.15 case stops near t=.00343 in cell 253, adjacent to
the periodic seam, although the requested final time is .1. All five existing
profiles fail. Reducing the spline timestep cap to 1e-5 and 1e-6 yields failure
times .00343412 and .00343445. This is not resolved by timestep refinement.

An observational energy-rate diagnostic evaluates, on fixed/rigid geometry,
`dK=v dot d(momentum)-|v|² d(rho)/2`, `dM=B dot curl(dA)`, and
`dp=(gamma-1)*(dE-dK-dM)`. For comparison it also computes `B dot dB_FV`
from the same oriented Riemann induction fluxes, without evolving that field.
At initialization in cell 253, dE=-42.28159, dM=-7.40085 and dK=0,
so dp=-34.88074. The independent finite-volume magnetic rate is -39.76889.
Thermal energy subsequently approaches zero. Tracing leaves every physical
snapshot, history, summary and timestep identical to the frozen baseline.
This demonstrates a discrete fluid/curl energy mismatch in that cell; it is
not a proof that the gradient stencil alone causes all instabilities.

## Prospective reconstruction comparator

Test `bulk-frame-heun-centered-v1` separately. Retain the spline auxiliary
projection, Heun stages, fluxes, primitive gradients, limiter, budgets and
failure policy. Change only the A/phi derivative fit used for the raw curl,
potential extrapolation, div(A) and grad(phi): minimize the face-area-weighted
residuals `A_j-A_i-G dot (c_j-c_i)` with the intercept anchored to the target
cell. Use the same scaled conditioning rejection. Cache the stencil on the
fixed/rigid geometry. The paper profile remains its prescribed free-intercept,
target-excluding fit. The new comparator is an engineering amendment, not a
correction attributed to the paper.

Before larger runs: verify affine reproduction, constant annihilation,
periodic manufactured convergence, observer passivity, analytic energy-rate
identities and temporal finite differences; reproduce the failing short
shock with baseline and comparator, plus regular and joint-boost controls.
If the short case improves, run the registered shock ladder on REANA and
report all existing profile/state/diagnostic/boost gates. A stable evolution
alone does not resolve the strict Bx diagnostic or the full M1 wave gates.
Reject an unsuccessful comparator rather than changing acceptance thresholds.

The centered comparator passes affine/constant/convergence and bounded
uniform/boost/time-order tests, but the short jittered shock still fails near
t=.00334879. It is rejected as the shock fix; exact source and results are
retained under `results/shock_diagnosis_20261108/`.

## Second prospective comparator: face-source location

The historical area-weighted face-source average does not generally reproduce
an affine electric field at a skewed cell centroid: its first spatial moment
is nonzero. Test `bulk-frame-heun-facefit-v1`, retaining the historical raw
curl and spline Heun choices. Replace only the face-source average by the
free-intercept least-squares value evaluated at the cell centroid. If
`m=sum_f(a_f/perimeter)*(f-c)` and `D_f` are the existing face derivative
coefficients, use source weights `a_f/perimeter - m dot D_f`. They sum to one
and have zero first moment. Apply them to the whole `EMF_f-u_i cross B_f`
source; keep advection, mean-field and gauge terms unchanged. This is another
explicit engineering comparator, not a claim about the published method.

First verify affine-source reproduction and uniform/boost/time-order
regressions, then repeat the same regular/jittered nx256 short shock controls.
Preserve all failures. The original M1 gates and resistivity/energy policy
remain unchanged.

## Disposition and retained development

### Prospective shared face-normal field experiment

Next test `bulk-frame-heun-vertex-v1` as a separate engineering comparator.
The current Riemann solver takes the arithmetic common normal component of
two independently reconstructed cell fields. This shared normal field need
not have zero oriented face sum in each cell. Construct instead one Az value
at each geometrically shared Voronoi vertex, using an affine-exact unweighted
least-squares intercept from its incident cell-centre values. For a face with
tangent `t=(-n_y,n_x)` and endpoints `v_minus,v_plus`, use
`Bn = mean_B dot n + (Az(v_plus)-Az(v_minus))/area`. The vertex differences
telescope around a cell. This identity applies only to this face-sum operator,
not to the historical cell-centred curl or its independent divergence tests.
Preserve gas pressure and tangential B when supplying the common Bn to both
Riemann states. Keep all other spline/Heun choices, conservative exchanges,
curl-based recovery and original acceptance gates unchanged.

Recover vertex topology by joining consecutive oriented face endpoints around
each cell, validating their geometric coincidence including periodic images.
Do not independently interpolate an endpoint for every face. First test
constant/affine reproduction, periodic telescoping, smooth convergence,
uniform states, boost/permutation and time order. Then use the four-case short
screen. Reject and archive a failed candidate; do not launch a full matrix.
This prospective description is recorded before candidate measurements.

Measured disposition: all three operator tests and four uniform/boost/
permutation/time-order controls pass. Initial maximum absolute divergence of
the actual Riemann face-normal field falls from **23.6786 to 2.22e-13**; in
cell 253 it falls from 1.07469 to -3.91e-14. Nevertheless that cell's initial
pressure rate remains -34.8306 (baseline -34.8807), with dE=-42.4052 and
B dot curl(dA)=-7.57460. Both jittered cases fail at t=.0033337193, slightly
earlier than the baseline t=.0034298036. Both regular cases complete t=.01
and pass their boost comparison. The four-case screen takes .85 seconds.

The candidate is rejected and removed; its exact source, seven tests, all
four traced runs and initial-state measurements are preserved in the
[shared-vertex probe archive](../tests/reference/m1_face_normal_probe/README.md).
This shows that making this face-normal flux sum cancel is insufficient to
repair the observed fluid/curl energy mismatch. It does not rule out other
coupling treatments or establish cell-curl solenoidality. Long jobs remain
stopped; the next numerical work concerns the compatibility of the discrete
curl evolution with the spatial energy flux, not a rerun of these long cases.
After removing the candidate, the four touched solver/driver/test files match
their pre-trial bytes exactly. Format, strict Clippy, all 107 Rust tests,
38 Python tests, the 13 M0 algebra checks and pinned reference verification
pass. The new evidence archive is excluded from minimal REANA source uploads.

The face-source comparator passes affine reproduction and bounded
uniform/boost/time-order checks, but still fails the jittered shock at
t=.00350419. Both alternative reconstructions are rejected as fixes and
removed from the working solver. Their exact source, tests and failed runs
are preserved in the [investigation archive](../tests/reference/m1_shock_diagnosis/README.md).
No new scientific gate is claimed.

![Measured failing-cell energy traces](images/m1_completion/shock_energy_failure.png)

At initialization, the failing cell itself has exactly B=(.75,-1,0) and
p=.1. Its pressure collapse cannot be attributed solely to an incorrect
initial B in that cell. The incompatible spatial transfer of magnetic and
total energy remains the demonstrated failure mechanism. The FV induction
curve is an independent comparison, not a separately accepted solution or
a proposal to overwrite the curl-derived field.

Retained changes are observational: `--trace-energy` writes every accepted
cell's thermal/kinetic/magnetic energies and instantaneous rates, without
introducing checkpoint times; `advance_to_observed` exposes accepted states;
closure errors identify the cell, location and Heun stage. Fixed/rigid meshes
only are supported for energy-rate interpretation. The trace can be reproduced:

```sh
cargo run --release --locked -p openmhd --bin vector-potential -- \
  --case brio-wu --profile bulk-frame-heun-spline-v1 --n 256 --jitter .15 \
  --time .005 --trace-energy --output results/shock_trace
```

This command is expected to fail with the preserved positivity error.
All five historical profiles retain byte-identical initial/final CSVs,
histories and summaries in ten boosted jittered wave/loop comparisons with
tracing enabled. The traced failing shock also matches its frozen baseline.
Format, Clippy, all 107 Rust tests, 36 Python tests and both M0 checks pass.
The new rate tests check uniform zero rates, temporal finite differences,
joint boosts, integrated energy conservation and observer passivity.

The remaining work is a justified coupling treatment that keeps the
curl-derived magnetic energy and conservative fluid fluxes compatible on
irregular shocks, followed by the unchanged full M1 gates. The current
investigation does not establish such a treatment. M1 remains unmerged.
