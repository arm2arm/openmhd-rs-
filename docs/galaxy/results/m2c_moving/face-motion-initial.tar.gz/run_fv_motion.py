"""Run one exact S-CDOT selection from the verified REANA build."""
import hashlib
import json
from pathlib import Path
import subprocess

def digest(data):
    return hashlib.sha256(data).hexdigest()

case = json.loads(Path("case.json").read_bytes())
binary = Path("face-motion-tests")
args = ["--exact", case["selector"], "--nocapture", "--test-threads=1"]
if digest(binary.read_bytes()) != case["sha256"] or args != case["args"]:
    raise ValueError("frozen executable or selector changed")
binary.chmod(0o755)
done = subprocess.run([str(binary.resolve()), *args], capture_output=True, timeout=1750)
Path("stdout.txt").write_bytes(done.stdout)
Path("stderr.txt").write_bytes(done.stderr)
out = done.stdout.decode()
passed = (done.returncode == 0 and "running 1 test\n" in out
          and f'test {case["selector"]} ...' in out
          and 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 8 filtered out;' in out)
result = dict(selector=case["selector"], parent=case["parent"], sha256=case["sha256"],
              argv=args, returncode=done.returncode, stdout_sha256=digest(done.stdout),
              stderr_sha256=digest(done.stderr), passed=passed)
Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
if not passed:
    raise SystemExit(1)

