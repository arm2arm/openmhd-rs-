import json
import os
from pathlib import Path
import subprocess
import sys

connection = json.loads((Path.home()/'.config/openmhd/reana-p4n.json').read_text())
environment = dict(os.environ)
environment['REANA_SERVER_URL'] = connection['server_url']
environment['REANA_ACCESS_TOKEN'] = connection['access_token']
command = [str(Path.home()/'.local/bin/uv'), 'tool', 'run', '--python', '3.11',
           '--from', 'reana-client', 'reana-client', *sys.argv[1:]]
result = subprocess.run(command, env=environment, capture_output=True, text=True)
for stream, destination in ((result.stdout, sys.stdout), (result.stderr, sys.stderr)):
    destination.write(stream.replace(connection['access_token'], '[REDACTED]'))
sys.exit(result.returncode)
