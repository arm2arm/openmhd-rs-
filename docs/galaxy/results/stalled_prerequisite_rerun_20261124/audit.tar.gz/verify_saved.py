"""Offline revalidation of actual replacement outputs and retained operation receipts."""
import hashlib,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
FROZEN=ROOT/'results/branch_integration216_execution_20261123_attempt01/frozen_original216_host_tools'
sys.path.insert(0,str(FROZEN))
import collect_metadata_reana_results as collector
job=collector.job
release=job.parse((HERE/'release.json').read_bytes());snapshot_bytes=(HERE/'0123/snapshot.json').read_bytes();snapshot=job.parse(snapshot_bytes)
command=['/usr/bin/python3',str(ROOT/'tools/galaxy_python_evidence/reana_metadata_readonly_adapter.py')]
collector.pinned_tools(snapshot,command)
output=HERE/'acquisition-a01';manifest=job.parse((output/'files.sha256.json').read_bytes())['files']
actual={p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file() and p.name!='files.sha256.json'}
if actual!=set(manifest):raise ValueError('Acquisition file inventory')
for name,r in manifest.items():
 raw=(output/name).read_bytes()
 if job.digest(raw)!=r['sha256'] or len(raw)!=r['bytes']:raise ValueError('Changed captured body')
summary=job.parse((output/'summary.json').read_bytes());rows=[]
for r in release['cases']:
 case=HERE/r['directory'];original=Path(release['original_plan_path']).parent/r['directory']
 for side,pins in [(original,r['original_file_sha256']),(case,r['replacement_file_sha256'])]:
  if any(job.digest((side/n).read_bytes())!=h for n,h in pins.items()):raise ValueError('Changed original/replacement input')
 entry={k:r[k] for k in ('directory','workflow','specification')};entry.update(payload_sha256=r['replacement_file_sha256']['payload.json'],workflow_sha256=r['replacement_file_sha256']['reana.yaml'])
 path=output/r['directory'];buffers={n:(path/n).read_bytes() for n in collector.file_names(path)}
 derived=collector.case_row(buffers,snapshot,snapshot_bytes,entry,dict(status='submitted'),command)
 saved=next(s for s in summary['cases'] if s['directory']==r['directory'])
 if any(saved[k]!=v for k,v in derived.items()) or derived['status']!='passed':raise ValueError('Saved strict verdict')
 transport=job.parse(buffers['transport.json'])
 if len(transport['attempts'])!=10:raise ValueError('Transport count')
 for attempt in transport['attempts']:
  diagnostic=job.parse(buffers[attempt['stdout']['path']])
  if diagnostic['workflow_ids']!=[saved['replacement_uuid']] or diagnostic['outcome']!='success' or diagnostic['workflow']!=r['workflow']:raise ValueError('UUID/transport diagnostic link')
 raw=job.parse(buffers['artifacts/child_raw.bin'])
 if raw['tests_run']!=1 or not raw['passed'] or any(raw[n]!=0 for n in ('errors','failures','skipped','expected_failures','unexpected_successes')):raise ValueError('Exact clean leaf')
 rows.append(dict(directory=r['directory'],original_uuid=r['original_uuid'],workflow=r['workflow'],uuid=saved['replacement_uuid'],status='passed',tests_run=1,errors=0,failures=0,skipped=0,transports=10,artifacts=8))
for receipt in sorted((HERE/'commands').glob('*/command.json')):
 if receipt.parent.name=='offline-verify-a01':continue
 c=job.parse(receipt.read_bytes())
 if c['returncode']!=0 or c['outcome']!='success':raise ValueError('Unsuccessful host operation')
 for stream in ('stdout','stderr'):
  raw=(receipt.parent/(stream+'.txt')).read_bytes()
  if job.digest(raw)!=c[stream]['sha256'] or len(raw)!=c[stream]['bytes']:raise ValueError('Host log digest')
value=dict(schema='openmhd.stalled-replacement-offline-verification.v1',cases=rows,passed=3,failed=0,transports=30,artifacts=24,component_accepted=False,errors=[])
with (HERE/'offline_verification.json').open('x') as f:json.dump(value,f,indent=2)
print(json.dumps(dict(passed=3,artifacts=24,successful_transports=30,errors=[])))
