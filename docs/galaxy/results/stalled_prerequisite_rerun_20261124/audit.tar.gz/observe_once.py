"""One finite GET-only inventory of the three released replacement identities."""
from datetime import datetime,timezone
import hashlib,importlib.util,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
release=json.loads((here/'release.json').read_text())
adapter=here.parent.parent/'tools/galaxy_python_evidence/reana_metadata_readonly_adapter.py'
if hashlib.sha256(adapter.read_bytes()).hexdigest()!='09a7f0cbaaa657eb6d84668dced7693c57c9784e78135adc86e72737ded79c4a':raise ValueError('Adapter changed')
spec=importlib.util.spec_from_file_location('rerun_get',adapter); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.Client(*m.settings_from_private());rows=[]
for r in release['cases']:
 first=c.scan(r['workflow'][:-2]);second=c.scan(r['workflow'][:-2])
 if first!=second or len(second)!=1 or second[0]['workflow']!=r['workflow']:raise ValueError('Nonunique or changed replacement')
 rows.append(dict(directory=r['directory'],original_uuid=r['original_uuid'],**second[0]))
c.remaining()
value=dict(schema='openmhd.stalled-replacement-inventory.v1',observed_utc=datetime.now(timezone.utc).isoformat(),cases=rows)
with (here/sys.argv[1]).open('x') as f:json.dump(value,f,indent=2)
print(json.dumps(value))
