"""Submit exactly the three explicitly released replacements, retaining originals."""
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
WRAPPER = Path('/Users/arm2arm/orca/workspaces/openmhd-rs-/m1-run-alfv-n-wave-and-field-loop-benchmarks/results/limiter_campaign_tools_20261113/reana-command.py')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

release_path = HERE/'release.json'
if sha(release_path) != '7982e7eaa253a133f60b022beed54ac3ff75c5930ff396eb9958fda29cd29206':
    raise ValueError('Changed release')
release = json.loads(release_path.read_text())
if sha(Path(release['original_plan_path'])) != release['original_plan_sha256']:
    raise ValueError('Changed original plan')
adapter_path = ROOT/'tools/galaxy_python_evidence/reana_metadata_readonly_adapter.py'
if sha(adapter_path) != '09a7f0cbaaa657eb6d84668dced7693c57c9784e78135adc86e72737ded79c4a':
    raise ValueError('Changed approved GET adapter')
if sha(HERE/'log_command.py') != 'cb73b5673cc5a36ee8d5a0bb388afaed97ea3d66fa47cb5347eae1c711e08781':
    raise ValueError('Changed host logger')
for row in release['cases']:
    for filename, digest in row['replacement_file_sha256'].items():
        if sha(HERE/row['directory']/filename) != digest:
            raise ValueError('Changed released input')
adapter = load_module('rerun_get', adapter_path)
client = adapter.Client(*adapter.settings_from_private())
observations = []
for row in release['cases']:
    old1 = client.scan(row['original_workflow'][:-2])
    old2 = client.scan(row['original_workflow'][:-2])
    new1 = client.scan(row['workflow'][:-2])
    new2 = client.scan(row['workflow'][:-2])
    observations.append(dict(original_workflow=row['original_workflow'], original_first=old1,
                             original_second=old2, replacement_workflow=row['workflow'],
                             replacement_first=new1, replacement_second=new2))
    if old1 != old2 or len(old2) != 1 or old2[0]['id'] != row['original_uuid'] or old2[0]['status'] not in ('queued','pending'):
        raise ValueError('Original no longer uniquely stalled; no replacement submitted')
    if new1 or new2:
        raise ValueError('Replacement name already exists; no implicit duplicate')
client.remaining()
with (HERE/'pre_submit_server_guard.json').open('x') as f:
    json.dump(dict(schema='openmhd.stalled-replacement-server-guard.v1', observed_utc=datetime.now(timezone.utc).isoformat(),
                   adapter_sha256=sha(adapter_path), observations=observations, errors=[]),f,indent=2)
# Exclusive durable marker precedes every mutation. An interrupted launch is never repeated automatically.
with (HERE/'submission_started.json').open('x') as f:
    json.dump(dict(started_utc=datetime.now(timezone.utc).isoformat(), release_sha256=sha(release_path),
                   workflows=[r['workflow'] for r in release['cases']], automatic_retry=False),f,indent=2)
logger = load_module('rerun_logger', HERE/'log_command.py')
def submit(row):
    case = HERE/row['directory']
    for filename, digest in row['replacement_file_sha256'].items():
        if sha(case/filename) != digest:
            raise ValueError('Changed released input before mutation')
    code = logger.run('submit-'+row['directory'], ['/usr/bin/python3','-B',str(WRAPPER),'run','--workflow',row['workflow'][:-2]],case,300)
    return dict(original_workflow=row['original_workflow'], original_uuid=row['original_uuid'],
                workflow=row['workflow'], returncode=code,
                submission_status='submitted' if code == 0 else 'submission uncertain')
results = []
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for future in concurrent.futures.as_completed([pool.submit(submit,r) for r in release['cases']]):
        results.append(future.result())
with (HERE/'submission.json').open('x') as f:
    json.dump(dict(schema='openmhd.stalled-replacement-submission.v1', finished_utc=datetime.now(timezone.utc).isoformat(),
                   cases=sorted(results,key=lambda r:r['workflow']), original_submission_modified=False),f,indent=2)
print(json.dumps(dict(submitted=sum(r['returncode']==0 for r in results), uncertain=sum(r['returncode']!=0 for r in results))))
