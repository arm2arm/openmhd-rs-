"""GET-only acquisition of three replacement cases using the original pinned validators."""
from datetime import datetime,timezone
import hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
FROZEN=ROOT/'results/branch_integration216_execution_20261123_attempt01/frozen_original216_host_tools'
release=json.loads((HERE/'release.json').read_text())
if hashlib.sha256((HERE/'release.json').read_bytes()).hexdigest()!='7982e7eaa253a133f60b022beed54ac3ff75c5930ff396eb9958fda29cd29206':raise ValueError('Release pin')
# These inert modules validate captured source and actual server outputs; no test method is imported or run on this host.
sys.path.insert(0,str(FROZEN))
import collect_metadata_reana_results as collector
job=collector.job
snapshot_bytes=(HERE/'0123/snapshot.json').read_bytes(); snapshot=job.parse(snapshot_bytes)
command=['/usr/bin/python3',str(ROOT/'tools/galaxy_python_evidence/reana_metadata_readonly_adapter.py')]
tools=collector.pinned_tools(snapshot,command)
source={name:(HERE/'0123'/name).read_bytes() for name in collector.SHARED}
collector.validate_source(source)
for r in release['cases']:
 for name,digest in r['replacement_file_sha256'].items():
  if job.digest((HERE/r['directory']/name).read_bytes())!=digest:raise ValueError('Changed released case')
adapter_spec=importlib.util.spec_from_file_location('rerun_acquire_get',command[1]); adapter=importlib.util.module_from_spec(adapter_spec);adapter_spec.loader.exec_module(adapter)
client=adapter.Client(*adapter.settings_from_private()); states=[]
for r in release['cases']:
 first=client.scan(r['workflow'][:-2]);second=client.scan(r['workflow'][:-2])
 if first!=second or len(second)!=1 or second[0]['workflow']!=r['workflow'] or second[0]['status']!='finished':raise ValueError('All replacements must be uniquely finished before acquisition')
 states.extend(second)
client.remaining()
output=HERE/'acquisition-a01';output.mkdir()
(output/'terminal_guard.json').write_bytes(job.encode(dict(observed_utc=datetime.now(timezone.utc).isoformat(),cases=states,errors=[])))
rows=[]
submission=json.loads((HERE/'submission.json').read_text())
for r in release['cases']:
 entry={k:r[k] for k in ('directory','specification','workflow')}
 entry.update(payload_sha256=r['replacement_file_sha256']['payload.json'],workflow_sha256=r['replacement_file_sha256']['reana.yaml'])
 destination=output/r['directory']; collector.observe_case(destination,command,entry)
 buffers={n:(destination/n).read_bytes() for n in collector.file_names(destination)}
 submitted=next(s for s in submission['cases'] if s['workflow']==r['workflow'])
 row=collector.case_row(buffers,snapshot,snapshot_bytes,entry,dict(status=submitted['submission_status']),command)
 row.update(original_workflow=r['original_workflow'],original_uuid=r['original_uuid'],replacement_uuid=next(s['id'] for s in states if s['workflow']==r['workflow']))
 rows.append(row)
 (output/'summary.json').write_bytes(job.encode(dict(schema='openmhd.three-stalled-replacement-results.v1',cases=rows,complete=len(rows)==3,component_accepted=False)))
if collector.pinned_tools(snapshot,command)!=tools:raise ValueError('Changed frozen validation tools')
for r in release['cases']:
 for name,digest in r['replacement_file_sha256'].items():
  if job.digest((HERE/r['directory']/name).read_bytes())!=digest:raise ValueError('Changed released case at closure')
files={p.relative_to(output).as_posix():dict(sha256=job.digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(output.rglob('*')) if p.is_file()}
(output/'files.sha256.json').write_bytes(job.encode(dict(files=files)))
print(json.dumps(dict(passed=sum(r['status']=='passed' for r in rows),cases=[dict(directory=r['directory'],status=r['status'],classification=r['classification']) for r in rows],component_accepted=False)))
sys.exit(0 if all(r['status']=='passed' for r in rows) else 1)
