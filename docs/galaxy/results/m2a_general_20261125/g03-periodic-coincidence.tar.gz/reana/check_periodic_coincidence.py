"""Run the repaired binary on two periodic images of the same wrapped generator position."""
from hashlib import sha256
import json
import os
from pathlib import Path
import sys

directory=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(directory/'tools/m1_evidence'))
import galaxy_test_case as launcher
import reana_metadata_job as supervisor

binary_hash='51136bbb690fc37bb634face4217f90e915732327ba2028f8042a5767c01ae15'
input_hash='b2cf9f5547174575e21cc20aefb9178402c3e8e7a162dcba9adbc3eaf524b61b'
build_uuid='d49a95f4-6aad-4ae6-ac0b-1f0644b2a516'
expected=(b'geometry3 candidate export rejected: 3D geometry rejected: CoincidentGenerators '
          b'{ first: CellId(EntityId { namespace: 73, counter: 11 }), second: CellId(EntityId { namespace: 73, counter: 12 }) }\n')

def require(value, reason):
    if not value:
        raise ValueError(reason)

def describe(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())

def main():
    out=(directory/'outputs').absolute()
    out.mkdir(exist_ok=False)
    work=out/'work';work.mkdir()
    original=(directory/'geometry.bin').read_bytes()
    literal=(directory/'input.txt').read_bytes()
    require(sha256(original).hexdigest()==binary_hash and sha256(literal).hexdigest()==input_hash,'Original released words and Rust executable')
    exe=work/'geometry3-case';exe.write_bytes(original);exe.chmod(0o700)
    fixture=work/'input.txt';fixture.write_bytes(literal)
    env=dict(os.environ,RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    links=dict(build_uuid=build_uuid,binary_sha256=binary_hash,input_sha256=input_hash)
    result=dict(schema='openmhd.m2a.periodic-coincidence-output.v1',passed=False,links=links)
    try:
        command=launcher.launch_native(supervisor,[str(exe),str(fixture)],work,env,out,240,links)
        stdout=(out/'stdout.txt').read_bytes();stderr=(out/'stderr.txt').read_bytes()
        cleanup=command['cleanup']
        require(exe.read_bytes()==original==(directory/'geometry.bin').read_bytes() and fixture.read_bytes()==literal==(directory/'input.txt').read_bytes(),'Source and input stability')
        require(cleanup['writers_settled'] and cleanup['direct_child_reaped'] and cleanup['leader_held_until_group_close']
                and not cleanup['group_authority_lost'],'Native process settled')
        result.update(returncode=command['returncode'],stdout=describe(stdout),stderr=describe(stderr))
        require(command['outcome']=='nonzero' and command['returncode']==1 and stdout==b'' and stderr==expected,'Exact typed rejection of the two distinct IDs')
        result.update(passed=True,variant='CoincidentGenerators')
    finally:
        (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':
    main()
