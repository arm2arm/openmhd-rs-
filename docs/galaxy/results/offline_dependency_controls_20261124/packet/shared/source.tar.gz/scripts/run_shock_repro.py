#!/usr/bin/env python3
"""Four bounded shock-development checks; never a substitute for full M1 validation."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import math
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

from run_m1_physics import AMENDMENT, BOOST, PROFILE, boost_comparison, bx_gate, load_json, validate_run
from run_m1_wave_loop import ROOT, dump, read_cells, sha

from run_m1_wave_loop import RIEMANN_SOLVERS, with_riemann, riemann_arguments
from run_m1_wave_loop import POTENTIAL_LIMITERS, limiter_arguments, limiter_matches
from run_m1_wave_loop import step_arguments, step_matches, projection_matches

def configurations(profile, riemann='hlld'):
    configs = {f'j{jitter}_{label}': dict(name=f'j{jitter}_{label}', case='brio-wu',
             n=256, ny=4, jitter=jitter, boost=list(boost), time=.01, profile=profile)
            for jitter in (0., .15) for label, boost in (('base', (0.,0.,0.)), ('boost', BOOST))}
    return with_riemann(configs,riemann)


def assess(configs, runs, pairs):
    complete = len(configs) == 4 and set(runs) == set(configs) and all(
        r['status'] == 'completed' for r in runs.values())
    stability = complete and all(r['positive_and_conservative'] for r in runs.values())
    boost = len(pairs) == 2 and all(p['status'] == 'pass' for p in pairs)
    diagnostics = complete and all(r['diagnostic_checks_passed'] for r in runs.values())
    return dict(completed_cases=sum(r['status']=='completed' for r in runs.values()),
                expected_cases=4, complete=complete, stability_and_budget=stability,
                boost_checks=boost, short_diagnostic_checks=diagnostics,
                short_screen_passed=stability and boost and diagnostics,
                full_m1_accepted=False,
                scope='Short t=.01 development screen only. Bx is gated on the regular mesh and diagnostic on planar jitter (benchmarks/m1/shock-bx-amendment.json). Full t=.1 shock, convergence, wave/loop/vortex and M1 gates remain required; no long jobs are submitted.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--profile', default=PROFILE)
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--timeout', type=float, default=30., help='Wall seconds per case; a timeout is incomplete, never a pass')
    parser.add_argument('--dt', type=float, help='Optional smaller timestep cap, for a separate investigation')
    parser.add_argument('--trace-energy', action='store_true')
    parser.add_argument('--accelerated-projection', action='store_true', help='Cached projection solve; projected-rate profiles only')
    parser.add_argument('--projection-screening', type=float, default=0., help='Opt-in damping kappa of the projected-rate correction')
    parser.add_argument('--riemann',choices=RIEMANN_SOLVERS,default='hlld')
    parser.add_argument('--potential-limiter',choices=tuple(POTENTIAL_LIMITERS),
                        help='Explicit opt-in A-advection limiter (issue #26); omitted keeps the registered default')
    parser.add_argument('--trial-step-fraction',type=float,
                        help='Explicit opt-in first-trial fraction of the CFL bound in (0, 1); omitted keeps the historical controller')
    args=parser.parse_args()
    if not math.isfinite(args.projection_screening) or args.projection_screening<0:parser.error('projection screening must be >= 0')
    try:step_arguments(args.trial_step_fraction)
    except ValueError as error:parser.error(str(error))
    if not 1<=args.jobs<=4:parser.error('jobs must be 1..4')
    if not math.isfinite(args.timeout) or not 0<args.timeout<=120:parser.error('timeout must be in (0,120] seconds')
    if args.dt is not None and (not math.isfinite(args.dt) or args.dt<=0):parser.error('dt must be finite and positive')
    output=args.output_dir.resolve()
    if output.exists():parser.error('Use a fresh output directory')
    output.mkdir(parents=True)
    paths=sorted({*ROOT.glob('crates/**/*.rs'), *ROOT.glob('apps/**/*.rs'),
                  *ROOT.glob('crates/*/Cargo.toml'), *ROOT.glob('apps/*/Cargo.toml'),
                  ROOT/'Cargo.toml', ROOT/'Cargo.lock', ROOT/'rust-toolchain.toml',
                  Path(__file__).resolve(), ROOT/'scripts/run_m1_physics.py', ROOT/'scripts/run_m1_wave_loop.py',
                  ROOT/'scripts/physics_projection.py', ROOT/'benchmarks/m0/packet.json', AMENDMENT,
                  ROOT/'docs/M1_SHOCK_INVESTIGATION.md'})
    sources={str(p.relative_to(ROOT)):sha(p) for p in paths}
    with tarfile.open(output/'source.tar.gz','w:gz') as archive:
        for p in paths:archive.add(p,arcname=str(p.relative_to(ROOT)))
    cargo=shutil.which('cargo') or str(Path.home()/'.cargo/bin/cargo')
    subprocess.run([cargo,'build','--release','--locked','-p','openmhd','--bin','vector-potential'],cwd=ROOT,check=True)
    binary=ROOT/'target/release/vector-potential'
    provenance=dict(created_utc=datetime.now(timezone.utc).isoformat(), source_sha256=sources,
                    binary_sha256=sha(binary), source_archive_sha256=sha(output/'source.tar.gz'),
                    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                    rustc=subprocess.check_output([str(Path(cargo).with_name('rustc')),'-Vv'],text=True),
                    jobs=args.jobs, threads_per_case=1, timeout_seconds=args.timeout,
                    dt_cap=args.dt, trace_energy=args.trace_energy,
                    accelerated_projection=args.accelerated_projection,
                    projection_screening=args.projection_screening)
    configs=configurations(args.profile,args.riemann);packet=load_json(ROOT/'benchmarks/m0/packet.json')
    if args.riemann != 'hlld':provenance['riemann_solver']=args.riemann
    if args.potential_limiter is not None:provenance['potential_limiter']=args.potential_limiter
    if args.trial_step_fraction is not None:provenance['trial_step_fraction']=args.trial_step_fraction
    dump(output/'manifest.json',configs);dump(output/'provenance.json',provenance)

    def run(c):
        dest=output/c['name'];dest.mkdir()
        command=[str(binary),'--case',c['case'],'--profile',c['profile'],'--n',str(c['n']),
                 '--jitter',str(c['jitter']),'--time',str(c['time']),'--motion','rigid',
                 '--mesh-x',str(c['boost'][0]),'--mesh-y',str(c['boost'][1]),
                 '--boost-x',str(c['boost'][0]),'--boost-y',str(c['boost'][1]),'--output',str(dest)]
        command+=riemann_arguments(c)
        command+=limiter_arguments(args.potential_limiter)
        command+=step_arguments(args.trial_step_fraction)
        if args.dt is not None:command+=['--dt',str(args.dt)]
        if args.trace_energy:command+=['--trace-energy']
        if args.accelerated_projection:command+=['--accelerated-projection']
        if args.projection_screening:command+=['--projection-screening',str(args.projection_screening)]
        record=dict(config=c,command=command,status='failed');start=time.monotonic()
        try:
            with (dest/'run.log').open('w') as log:
                done=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=args.timeout)
            record['returncode']=done.returncode
            summary=load_json(dest/'summary.json');record['summary']=summary
            if done.returncode or not summary['completed']:
                failure=dest/'failure.txt'
                raise ValueError(failure.read_text() if failure.exists() else 'failed evolution; inspect run.log')
            history=load_json(dest/'history.json');physics=load_json(dest/'physics.json')
            initial=read_cells(dest/'initial.csv');cells=read_cells(dest/'final.csv')
            validate_run(c,summary,history,physics,load_json(dest/'geometry.json'),initial,cells)
            if not limiter_matches(summary,args.potential_limiter):raise ValueError('potential limiter configuration mismatch')
            if not step_matches(summary,args.trial_step_fraction) or not projection_matches(summary,args.accelerated_projection):
                raise ValueError('step or projection solver configuration mismatch')
            positive=all(h['diagnostics']['rho_min']>0 and h['diagnostics']['p_min']>0
                         and max(map(abs,h['diagnostics']['normalized_budget']))<=packet['solver']['budget_tolerance'] for h in history)
            gate=packet['cases']['brio-wu']['gate']
            bx=bx_gate(c,initial,cells)
            diagnostics=dict(bx_max_error=bx['final']['max'],bx=bx,signal_travel_x=physics['signal_travel_x'])
            checks=dict(seam=physics['signal_tracking'] and 0<=diagnostics['signal_travel_x']<gate['seam_max_signal_travel'])
            # Amended rule: planar-jitter Bx is a recorded diagnostic, not a gate.
            if bx['gate_applies']:checks['bx']=bx['passed']
            record.update(status='completed',positive_and_conservative=positive,
                          diagnostic_values=diagnostics,diagnostic_checks=checks,diagnostic_checks_passed=all(checks.values()))
        except subprocess.TimeoutExpired:
            record.update(status='timeout',error='Wall-time cap reached; incomplete execution')
        except (OSError,ValueError,KeyError) as error:
            record['error']=str(error)
        record['seconds']=time.monotonic()-start
        record['files_sha256']={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
        return c['name'],record

    runs={};started=time.monotonic()
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in as_completed([pool.submit(run,c) for c in configs.values()]):
            name,r=future.result();runs[name]=r;dump(output/'runs.json',runs)
            print(f'{name}: {r["status"]} in {r["seconds"]:.2f}s; t={r.get("summary",{}).get("time", "incomplete")}',flush=True)
    pairs=[]
    for jitter in (0.,.15):
        names=[f'j{jitter}_base',f'j{jitter}_boost'];pair=dict(names=names,status='unexecuted')
        if all(runs[n]['status']=='completed' for n in names):
            pair.update(boost_comparison(*(read_cells(output/n/'final.csv') for n in names),configs[names[0]],runs[names[0]]['summary']))
            pair['status']='pass' if pair['passed'] else 'fail'
        pairs.append(pair)
    summary=assess(configs,runs,pairs);summary.update(boost_pairs=pairs,wall_seconds=time.monotonic()-started)
    if args.riemann != 'hlld':summary['riemann_solver']=args.riemann
    if args.potential_limiter is not None:summary['potential_limiter']=args.potential_limiter
    if args.trial_step_fraction is not None:summary['trial_step_fraction']=args.trial_step_fraction
    unchanged=sources=={str(p.relative_to(ROOT)):sha(p) for p in paths} and sha(binary)==provenance['binary_sha256']
    summary['source_and_binary_unchanged']=unchanged
    summary['short_screen_passed'] &= unchanged
    dump(output/'summary.json',summary)
    provenance['results_sha256']={n:sha(output/n) for n in ('manifest.json','runs.json','summary.json')};dump(output/'provenance.json',provenance)
    print(f'Short screen: {"PASS" if summary["short_screen_passed"] else "FAIL"}; {summary["wall_seconds"]:.2f}s. Full M1 acceptance: not evaluated.')
    return 0 if summary['short_screen_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
